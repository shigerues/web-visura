<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$id = (int)current_user()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $do = $_POST['do'] ?? '';

    if ($do === 'name') {
        $name = trim($_POST['name'] ?? '');
        if ($name === '' || mb_strlen($name) > 80) {
            flash_set('error', 'Nama wajib diisi (maksimal 80 karakter).');
        } else {
            $pdo->prepare('UPDATE users SET name = ? WHERE id = ?')->execute([$name, $id]);
            $_SESSION['user']['name'] = $name;
            flash_set('success', 'Profil diperbarui.');
        }
    } elseif ($do === 'password') {
        $old = $_POST['old'] ?? ''; $new = $_POST['new'] ?? ''; $confirm = $_POST['confirm'] ?? '';
        $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?'); $st->execute([$id]);
        if (!password_verify($old, (string)$st->fetchColumn())) {
            flash_set('error', 'Kata sandi lama salah.');
        } elseif (strlen($new) < 8) {
            flash_set('error', 'Kata sandi baru minimal 8 karakter.');
        } elseif ($new !== $confirm) {
            flash_set('error', 'Konfirmasi kata sandi tidak sama.');
        } else {
            $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_BCRYPT), $id]);
            session_regenerate_id(true);
            flash_set('success', 'Kata sandi berhasil diganti.');
        }
    } elseif ($do === 'reveal') {   // tampilkan kode tersimpan setelah konfirmasi kata sandi
        $st = $pdo->prepare('SELECT password_hash, recovery_enc FROM users WHERE id = ?'); $st->execute([$id]);
        $row = $st->fetch();
        if (!password_verify($_POST['pw'] ?? '', (string)($row['password_hash'] ?? ''))) {
            flash_set('error', 'Kata sandi salah, kode pemulihan tidak ditampilkan.');
        } elseif (($code = decrypt_code($row['recovery_enc'] ?? null)) === null) {
            flash_set('error', 'Kode tersimpan tidak bisa dibaca. Buat kode baru.');
        } else {
            $_SESSION['reveal_code'] = $code;   // tampil sekali pada halaman berikutnya
        }
    } elseif ($do === 'recovery') {   // perbarui kode pemulihan
        $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?'); $st->execute([$id]);
        if (!password_verify($_POST['pw'] ?? '', (string)$st->fetchColumn())) {
            flash_set('error', 'Kata sandi salah, kode pemulihan tidak dibuat.');
        } else {
            $_SESSION['popup_code'] = set_recovery_code($pdo, $id);   // ditampilkan sekali sebagai pop up
            header('Location: ' . BASE_URL . '/profile.php'); exit;
        }
    }
    header('Location: ' . BASE_URL . '/profile.php'); exit;
}

$st = $pdo->prepare('SELECT name, username, role, created_at, (recovery_hash IS NOT NULL) AS has_code, (recovery_enc IS NOT NULL) AS can_reveal FROM users WHERE id = ?'); $st->execute([$id]);
$prof = $st->fetch();
$cnt = $pdo->prepare('SELECT (SELECT COUNT(*) FROM media WHERE user_id = :a) AS photos,
                             (SELECT COUNT(*) FROM reviews WHERE user_id = :b) AS reviews,
                             (SELECT COUNT(*) FROM favorites WHERE user_id = :c) AS favs');
$cnt->execute([':a' => $id, ':b' => $id, ':c' => $id]);
$n = $cnt->fetch();

$revealCode = $_SESSION['reveal_code'] ?? null;
unset($_SESSION['reveal_code']);   // hanya tampil sekali per permintaan
$popupCode = $_SESSION['popup_code'] ?? null;
unset($_SESSION['popup_code']);   // hanya tampil sekali

$pageTitle = 'Profil';
include __DIR__ . '/includes/header.php';
?>
<?php
$isAdminP = $prof['role'] === 'admin';
$stats = user_stats_map($pdo, [$id])[$id];
$t = title_for($stats);
$hue = ($id * 47) % 360;
$q = $pdo->prepare('SELECT m.id, m.thumb_path, m.kind, d.name AS dest FROM media m JOIN destinations d ON d.id = m.destination_id WHERE m.user_id = ? ORDER BY m.id DESC LIMIT 6');
$q->execute([$id]); $myPhotos = $q->fetchAll();
$q = $pdo->prepare('SELECT d.name, d.slug, d.region FROM favorites f JOIN destinations d ON d.id = f.destination_id WHERE f.user_id = ? ORDER BY d.name LIMIT 6');
$q->execute([$id]); $myFavs = $q->fetchAll();
$q = $pdo->prepare('SELECT r.rating, r.comment, r.created_at, d.name AS dest, d.slug FROM reviews r JOIN destinations d ON d.id = r.destination_id WHERE r.user_id = ? ORDER BY r.id DESC LIMIT 3');
$q->execute([$id]); $myRev = $q->fetchAll();
$openTab = $revealCode ? 'pulih' : 'profil';
?>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/profile.css?v=<?= @filemtime(__DIR__ . '/assets/css/profile.css') ?>">

<section class="pf-hero" style="--tc:<?= e($isAdminP ? '#0f172a' : $t['color']) ?>;--h:<?= $hue ?>">
    <div class="pf-cover"></div>
    <div class="pf-hero-body">
        <div class="pf-avatar">
            <?= e(mb_strtoupper(mb_substr($prof['name'], 0, 1))) ?>
            <?php if (!$isAdminP): ?><span class="pf-lvl" title="<?= e($t['name']) ?>"><?= e($t['icon']) ?></span><?php endif; ?>
        </div>
        <div class="pf-id">
            <p class="pf-hello"><?= greeting() ?>,</p>
            <h1><?= e($prof['name']) ?></h1>
            <p class="pf-meta">
                <span>@<?= e($prof['username']) ?></span>
                <?php if ($isAdminP): ?><span class="pf-chip adm">🛡️ Admin</span>
                <?php else: ?><?= render_title_badge($t) ?><?php endif; ?>
                <span class="pf-chip">📅 Bergabung <?= e(tgl_id($prof['created_at'])) ?></span>
            </p>
        </div>
        <?php if (!$isAdminP): ?>
        <div class="pf-actions">
            <a class="btn" href="<?= BASE_URL ?>/gallery.php?mine=1">📷 Foto saya</a>
            <a class="btn ghost" href="<?= BASE_URL ?>/?fav=1">♥ Favorit</a>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php if (!$isAdminP): ?>
<section class="pf-stats">
    <a class="pf-stat" href="<?= BASE_URL ?>/gallery.php?mine=1&amp;kind=photo"><i>📷</i><strong><?= (int)$stats['photos'] ?></strong><span>Foto</span></a>
    <a class="pf-stat" href="<?= BASE_URL ?>/gallery.php?mine=1&amp;kind=video"><i>🎬</i><strong><?= (int)$stats['videos'] ?></strong><span>Video</span></a>
    <div class="pf-stat"><i>⭐</i><strong><?= (int)$stats['reviews'] ?></strong><span>Ulasan</span></div>
    <a class="pf-stat" href="<?= BASE_URL ?>/?fav=1"><i>❤️</i><strong><?= (int)$stats['favs'] ?></strong><span>Favorit</span></a>
    <div class="pf-stat"><i>📍</i><strong><?= (int)$stats['places'] ?></strong><span>Tempat dikunjungi</span></div>
</section>

<section class="pf-level" style="--tc:<?= e($t['color']) ?>">
    <div class="pf-lv-top">
        <div class="pf-lv-ic"><?= e($t['icon']) ?></div>
        <div class="pf-lv-main">
            <p class="pf-lv-label">Level <?= (int)$t['level'] ?> dari <?= (int)$t['levels'] ?></p>
            <h2><?= e($t['name']) ?></h2>
            <div class="pf-bar" role="progressbar" aria-valuenow="<?= (int)$t['pct'] ?>" aria-valuemin="0" aria-valuemax="100"><i style="--w:<?= (int)$t['pct'] ?>%"></i></div>
            <p class="pf-hint"><?php if ($t['max']): ?>🎉 Kamu sudah mencapai level tertinggi!<?php else: ?>Butuh <strong><?= (int)$t['need'] ?> poin</strong> lagi menuju <strong><?= e($t['next']['icon'] . ' ' . $t['next']['name']) ?></strong><?php endif; ?></p>
        </div>
        <div class="pf-pts"><strong><?= (int)$t['points'] ?></strong><span>poin</span></div>
    </div>

    <ol class="pf-steps" aria-label="Tingkatan level">
        <?php foreach (TITLE_LEVELS as $num => $lv):
            $cls = $num < $t['level'] ? 'done' : ($num === $t['level'] ? 'now' : 'lock'); ?>
        <li class="<?= $cls ?>" style="--c:<?= e($lv['color']) ?>" title="Level <?= $num ?> · mulai <?= (int)$lv['min'] ?> poin">
            <span class="pf-dot"><?= e($lv['icon']) ?></span>
            <span class="pf-sname"><?= e($lv['name']) ?></span>
        </li>
        <?php endforeach; ?>
    </ol>

    <div class="pf-earn">
        <strong>Cara dapat poin:</strong>
        <span>📷 Foto <b>+<?= TITLE_POINTS['photos'] ?></b></span>
        <span>🎬 Video <b>+<?= TITLE_POINTS['videos'] ?></b></span>
        <span>⭐ Ulasan <b>+<?= TITLE_POINTS['reviews'] ?></b></span>
        <span>📍 Tempat baru <b>+<?= TITLE_POINTS['places'] ?></b></span>
        <span>❤️ Favorit <b>+<?= TITLE_POINTS['favs'] ?></b></span>
    </div>
</section>

<section class="pf-activity">
    <div class="pf-card pf-photos">
        <div class="pf-card-head"><h3>Foto & video terbaru</h3><a href="<?= BASE_URL ?>/gallery.php?mine=1">Lihat semua →</a></div>
        <?php if ($myPhotos): ?>
        <div class="pf-thumbs">
            <?php foreach ($myPhotos as $p): ?>
            <a href="<?= BASE_URL ?>/gallery.php?mine=1" title="<?= e($p['dest']) ?>">
                <img src="<?= BASE_URL ?>/uploads/<?= e($p['thumb_path']) ?>" alt="<?= e($p['dest']) ?>" loading="lazy">
                <?php if ($p['kind'] === 'video'): ?><span class="pf-play">▶</span><?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <p class="pf-empty">Belum ada foto. <a href="<?= BASE_URL ?>/gallery.php#unggah">Bagikan kunjunganmu pertama →</a></p>
        <?php endif; ?>
    </div>

    <div class="pf-card">
        <div class="pf-card-head"><h3>Tempat favorit</h3><a href="<?= BASE_URL ?>/?fav=1">Semua →</a></div>
        <?php if ($myFavs): ?>
        <ul class="pf-list">
            <?php foreach ($myFavs as $f): ?>
            <li><a href="<?= BASE_URL ?>/detail.php?slug=<?= e($f['slug']) ?>"><span class="pf-heart">♥</span><b><?= e($f['name']) ?></b><small><?= e($f['region']) ?></small></a></li>
            <?php endforeach; ?>
        </ul>
        <?php else: ?>
        <p class="pf-empty">Belum ada favorit. <a href="<?= BASE_URL ?>/">Jelajahi katalog →</a></p>
        <?php endif; ?>
    </div>

    <div class="pf-card">
        <div class="pf-card-head"><h3>Ulasan terakhir</h3></div>
        <?php if ($myRev): ?>
        <ul class="pf-list rev">
            <?php foreach ($myRev as $r): ?>
            <li>
                <a href="<?= BASE_URL ?>/detail.php?slug=<?= e($r['slug']) ?>">
                    <b><?= e($r['dest']) ?></b>
                    <span class="pf-stars" aria-label="<?= (int)$r['rating'] ?> dari 5"><?= str_repeat('★', (int)$r['rating']) . str_repeat('☆', 5 - (int)$r['rating']) ?></span>
                </a>
                <?php if ($r['comment']): ?><p>“<?= e($r['comment']) ?>”</p><?php endif; ?>
                <small><?= e(tgl_id($r['created_at'])) ?></small>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php else: ?>
        <p class="pf-empty">Belum ada ulasan. Tulis ulasan pertamamu di halaman sebuah tempat.</p>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<section class="pf-settings">
    <h2>Pengaturan akun</h2>
    <div class="pf-tabs" role="tablist">
        <button type="button" role="tab" data-tab="profil" class="<?= $openTab === 'profil' ? 'on' : '' ?>">👤 Ubah profil</button>
        <button type="button" role="tab" data-tab="sandi">🔒 Kata sandi</button>
        <button type="button" role="tab" data-tab="pulih" class="<?= $openTab === 'pulih' ? 'on' : '' ?>">🔑 Kode pemulihan</button>
    </div>

    <div class="pf-panel<?= $openTab === 'profil' ? ' on' : '' ?>" id="tab-profil">
        <form class="form pf-form" method="post">
            <?= csrf_field() ?><input type="hidden" name="do" value="name">
            <label>Username <input value="<?= e($prof['username']) ?>" disabled></label>
            <label>Nama <input name="name" required maxlength="80" value="<?= e($prof['name']) ?>"></label>
            <button class="btn" type="submit">Simpan perubahan</button>
        </form>
    </div>

    <div class="pf-panel" id="tab-sandi">
        <form class="form pf-form" method="post">
            <?= csrf_field() ?><input type="hidden" name="do" value="password">
            <label>Kata sandi lama <input class="pw" type="password" name="old" required autocomplete="current-password"></label>
            <label>Kata sandi baru (min. 8 karakter) <input class="pw" type="password" name="new" required minlength="8" autocomplete="new-password"></label>
            <label>Ulangi kata sandi baru <input class="pw" type="password" name="confirm" required minlength="8" autocomplete="new-password"></label>
            <label class="check">
                <input type="checkbox" onchange="this.form.querySelectorAll('.pw').forEach(i => i.type = this.checked ? 'text' : 'password')">
                Tampilkan kata sandi
            </label>
            <button class="btn" type="submit">Ganti kata sandi</button>
        </form>
    </div>

    <div class="pf-panel<?= $openTab === 'pulih' ? ' on' : '' ?>" id="tab-pulih">
        <form class="form pf-form" method="post">   <!-- kode pemulihan -->
            <?= csrf_field() ?>
            <?php if ($revealCode): ?>
                <p class="muted">Kode pemulihanmu:</p>
                <div id="rcInline" class="pf-code"><?= e($revealCode) ?></div>
                <p><button class="btn" type="button" onclick="var b=this;navigator.clipboard.writeText(document.getElementById('rcInline').textContent.trim()).then(function(){b.textContent='Tersalin ✓'})">Salin kode</button></p>
                <p class="muted">Simpan di tempat aman. Kode akan disembunyikan lagi saat halaman ini dibuka ulang.</p>
            <?php elseif ($prof['can_reveal']): ?>
                <p class="muted">Kode pemulihanmu tersimpan terenkripsi di akun ini. Masukkan kata sandimu untuk melihatnya kapan saja.</p>
            <?php elseif ($prof['has_code']): ?>
                <p class="muted">Kodemu dibuat sebelum fitur penyimpanan ada, jadi tidak bisa ditampilkan. Buat kode baru agar tersimpan dan bisa dilihat di sini.</p>
            <?php else: ?>
                <p class="muted">Akunmu belum punya kode pemulihan. Buat sekarang agar bisa mengatur ulang kata sandi jika lupa.</p>
            <?php endif; ?>
            <label>Masukkan kata sandimu untuk konfirmasi <input class="pw2" type="password" name="pw" required autocomplete="new-password"></label>
            <label class="check">
                <input type="checkbox" onchange="this.form.querySelector('.pw2').type = this.checked ? 'text' : 'password'">
                Tampilkan kata sandi
            </label>
            <div class="pf-btns">
            <?php if ($prof['can_reveal']): ?>
                <button class="btn" type="submit" name="do" value="reveal">Lihat kode pemulihan</button>
            <?php endif; ?>
            <button class="btn<?= $prof['can_reveal'] ? ' ghost' : '' ?>" type="submit" name="do" value="recovery"
                    <?= $prof['has_code'] ? "onclick=\"return confirm('Kode lama akan tidak berlaku. Lanjutkan?')\"" : '' ?>><?= $prof['has_code'] ? 'Buat kode baru' : 'Buat kode pemulihan' ?></button>
            </div>
        </form>
    </div>
</section>
<script>
(function () {
    var tabs = [].slice.call(document.querySelectorAll('.pf-tabs button')), panels = [].slice.call(document.querySelectorAll('.pf-panel'));
    function show(id) {
        tabs.forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === id); });
        panels.forEach(function (p) { p.classList.toggle('on', p.id === 'tab-' + id); });
    }
    tabs.forEach(function (b) { b.addEventListener('click', function () { show(b.getAttribute('data-tab')); }); });
    // setelah kirim formulir halaman dimuat ulang: kembali ke tab yang tadi dipakai
    panels.forEach(function (p) { p.addEventListener('submit', function () { try { sessionStorage.setItem('pfTab', p.id.replace('tab-', '')); } catch (e) {} }); });
    try { var s = sessionStorage.getItem('pfTab'); sessionStorage.removeItem('pfTab'); if (s && !document.getElementById('rcInline') && document.getElementById('tab-' + s)) show(s); } catch (e) {}
})();
</script>
<?php if ($popupCode): ?>
<style>
    .rc-overlay { position: fixed; inset: 0; background: rgba(15, 30, 40, .6); display: flex; align-items: center; justify-content: center; padding: 16px; z-index: 1000; }
    .rc-modal { background: #fff; border-radius: 14px; max-width: 440px; width: 100%; padding: 28px; box-shadow: 0 20px 50px rgba(0,0,0,.3); text-align: center; }
    .rc-modal h2 { margin: 0 0 8px; }
    .rc-modal p { margin: 8px 0; color: #555; font-size: .95rem; }
    .rc-code { font-family: monospace; font-size: 1.5rem; font-weight: 700; letter-spacing: 2px; background: #f3f6f8; border: 2px dashed #0f6b82; border-radius: 10px; padding: 16px 8px; margin: 16px 0; user-select: all; word-break: break-all; }
    .rc-actions { display: flex; gap: 8px; justify-content: center; flex-wrap: wrap; margin-top: 16px; }
</style>
<div class="rc-overlay" id="rcOverlay" role="dialog" aria-modal="true" aria-labelledby="rcTitle">
    <div class="rc-modal">
        <h2 id="rcTitle">Simpan kode pemulihanmu</h2>
        <p>Kode ini dipakai untuk mengatur ulang kata sandi jika kamu lupa.</p>
        <div class="rc-code" id="rcCode"><?= e($popupCode) ?></div>
        <p><strong>Kode hanya tampil sekali.</strong> Catat di tempat aman. Kode berlaku satu kali pakai.</p>
        <div class="rc-actions">
            <button class="btn ghost" type="button" id="rcCopy">Salin kode</button>
            <button class="btn" type="button" id="rcClose">Saya sudah menyimpannya</button>
        </div>
    </div>
</div>
<script>
    document.getElementById('rcCopy').addEventListener('click', function () {
        var t = document.getElementById('rcCode').textContent.trim(), b = this;
        (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () {
            b.textContent = 'Tersalin ✓';
        }).catch(function () {
            var r = document.createRange(); r.selectNodeContents(document.getElementById('rcCode'));
            var sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
            b.textContent = 'Tekan Ctrl+C';
        });
    });
    document.getElementById('rcClose').addEventListener('click', function () {
        document.getElementById('rcOverlay').remove();
    });
</script>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>