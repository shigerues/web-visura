<?php
// POST: laporkan foto yang tidak pantas
require_once __DIR__ . '/includes/functions.php';
require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . '/'); exit; }
csrf_check();

$st = $pdo->prepare('SELECT m.id, m.user_id, d.slug FROM media m JOIN destinations d ON d.id = m.destination_id WHERE m.id = ?');
$st->execute([(int)($_POST['media_id'] ?? 0)]);
$m = $st->fetch();
if (!$m) { flash_set('error', 'Foto tidak ditemukan.'); header('Location: ' . BASE_URL . '/'); exit; }

$back = BASE_URL . '/detail.php?slug=' . urlencode($m['slug']);
$reason = $_POST['reason'] ?? '';
if ((int)$m['user_id'] === (int)current_user()['id']) {
    flash_set('error', 'Kamu tidak perlu melaporkan fotomu sendiri. Hapus saja jika tidak ingin ditampilkan.');
} elseif (!in_array($reason, REPORT_REASONS, true)) {
    flash_set('error', 'Pilih alasan laporan.');
} else {
    // Satu laporan per pengguna per foto; kirim ulang = perbarui alasan
    $pdo->prepare("INSERT INTO reports (media_id, user_id, reason, status) VALUES (?, ?, ?, 'open')
                   ON DUPLICATE KEY UPDATE reason = VALUES(reason), status = 'open'")
        ->execute([$m['id'], current_user()['id'], $reason]);
    flash_set('success', 'Laporan terkirim. Admin akan memeriksanya.');
}
header('Location: ' . $back); exit;
