Visura — Katalog Wisata Jakarta

Stack: PHP 8+ (ekstensi gd, fileinfo, pdo_mysql; exif disarankan), MySQL/MariaDB, HTML/CSS/JS.

Cara menjalankan (XAMPP / Laragon)

Salin folder visura ke htdocs (XAMPP) atau www (Laragon).

Buka phpMyAdmin → Import database.sql (membuat database visura + data contoh).

Sesuaikan config.php (DB_USER, DB_PASS, BASE_URL).

Buka http://localhost/visura/

Admin: admin@visura.test / admin123 → ganti segera.

Catatan Database & Migrasi (Untuk Pengguna Lain)

Langsung pakai data contoh (disarankan): Cukup import database.sql. File ini sudah berisi skema tabel terbaru beserta data destinasi wisata Jakarta dan media bawaan di folder uploads/.

Bangun struktur dari nol (bertahap): Jika tidak memakai database.sql, jalankan file migrasi secara berurutan dari migration1.sql → migration2.sql → migration3.sql → migration4.sql → migration5.sql → migration6.sql.

Buat akun admin (jika memakai migrasi kosong): Jalankan buat_admin.php melalui browser, lalu hapus file tersebut setelah selesai demi keamanan.

Sinkronisasi gambar medium: Jika mengimpor data foto lama yang belum memiliki salinan ukuran sedang, jalankan backfill_mid.php untuk mengisi uploads/mid/.

Izin folder unggahan: Pastikan folder uploads/media/, uploads/mid/, uploads/thumb/, dan uploads/video/ memiliki izin tulis (write permission).

Fitur

Katalog + pencarian langsung, filter kategori & wilayah, pagination

Detail: alamat (tautan peta), jam buka, harga, fasilitas, ulasan & rating

Galeri pengunjung + "Foto saya"

Unggah foto: validasi MIME + magic bytes, maks 5 MB, resize bikubik, watermark, kompresi WebP, thumbnail, SHA-256 (tolak duplikat), baca EXIF

Login/daftar (bcrypt, CSRF, session aman), panel admin

REST API: /api/destinations.php?q=&category=&region=&page=&per_page=