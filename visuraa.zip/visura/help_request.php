<?php
// ALUR 1: pengguna yang lupa kata sandi (dan tak punya kode pemulihan) meminta bantuan admin.
require_once __DIR__ . '/includes/functions.php';
if (current_user()) { header('Location: ' . BASE_URL . '/profile.php'); exit; }

$err = ''; $sent = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = substr(strtolower(trim($_POST['username'] ?? '')), 0, 30);
    $note = mb_substr(trim($_POST['note'] ?? ''), 0, 300);

    if (throttle_wait($pdo, 'help', $username) > 0) {
        $err = 'Terlalu banyak permintaan. Coba lagi beberapa menit lagi.';
    } elseif (!preg_match('/^[a-z0-9_]{3,30}$/', $username)) {
        $err = 'Username 3–30 karakter: huruf kecil, angka, atau garis bawah (_).';
    } else {
        throttle_fail($pdo, 'help', $username);   // setiap kiriman dihitung agar tidak bisa dibanjiri
        $st = $pdo->prepare('SELECT id FROM users WHERE username = ?'); $st->execute([$username]);
        $uid = $st->fetchColumn();
        if ($uid) {   // hanya simpan untuk akun yang ada; tampilan tetap sama agar username tidak bisa ditebak
            $dup = $pdo->prepare("SELECT 1 FROM help_requests WHERE user_id = ? AND status = 'open'");
            $dup->execute([$uid]);
            if (!$dup->fetchColumn()) {
                $pdo->prepare('INSERT INTO help_requests (username, user_id, note, ip) VALUES (?,?,?,?)')
                    ->execute([$username, $uid, $note, client_ip()]);
            }
        }
        $sent = true;
    }
}

$pageTitle = 'Minta bantuan admin';
include __DIR__ . '/includes/header.php';
?>
<section class="auth">
    <div class="auth-side">
        <h2>Butuh bantuan admin?</h2>
        <p>Kalau kamu lupa kata sandi dan tidak punya kode pemulihan, admin bisa membuatkan kata sandi sementara.</p>
        <ul class="auth-points">
            <li>Kirim username-mu, admin akan menerima permintaannya</li>
            <li>Admin menyampaikan kata sandi sementara kepadamu</li>
            <li>Saat masuk, kamu wajib menggantinya dan mendapat kode pemulihan baru</li>
        </ul>
    </div>
    <?php if ($sent): ?>
    <div class="auth-form">
        <h1>Permintaan terkirim</h1>
        <div class="alert success">Jika username tersebut terdaftar, admin akan segera memprosesnya.</div>
        <p class="sub">Kata sandi sementara disampaikan langsung oleh admin. Setelah menerimanya, masuk dan ikuti petunjuk untuk membuat kata sandi baru.</p>
        <p class="alt"><a href="<?= BASE_URL ?>/login.php">← Kembali ke halaman masuk</a></p>
    </div>
    <?php else: ?>
    <form class="auth-form" method="post">
        <h1>Minta bantuan admin</h1>
        <p class="sub">Masukkan username akunmu.</p>
        <?php if ($err): ?><div class="alert error"><?= e($err) ?></div><?php endif; ?>
        <?= csrf_field() ?>
        <label>Username <input name="username" required maxlength="30" autocomplete="username" value="<?= e($_POST['username'] ?? '') ?>"></label>
        <label>Catatan untuk admin (opsional, agar admin yakin ini kamu)
            <textarea name="note" rows="3" maxlength="300"><?= e($_POST['note'] ?? '') ?></textarea></label>
        <button class="btn" type="submit">Kirim permintaan</button>
        <p class="alt"><a href="<?= BASE_URL ?>/forgot_password.php">Punya kode pemulihan? Atur ulang di sini</a></p>
    </form>
    <?php endif; ?>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
