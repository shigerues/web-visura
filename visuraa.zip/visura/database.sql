-- ============================================================================
--  Visura — skema database TERKINI (gabungan database.sql lama + migration 2–6)
--  Untuk instalasi BARU dari nol. Database lama cukup dipakai apa adanya.
--  Akun admin TIDAK dibuat di sini (agar tidak ada kata sandi bawaan yang bocor).
--  Setelah mengimpor, buat admin lewat terminal:   php buat_admin.php
-- ============================================================================
CREATE DATABASE IF NOT EXISTS visura CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE visura;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  username VARCHAR(30) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  recovery_hash VARCHAR(255) NULL,                 -- hash kode pemulihan (untuk memeriksa kode)
  recovery_enc  VARCHAR(255) NULL,                 -- kode pemulihan terenkripsi AES-256-GCM (agar bisa ditampilkan di profil)
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE destinations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT NOT NULL,
  name VARCHAR(150) NOT NULL,
  slug VARCHAR(160) NOT NULL UNIQUE,
  region VARCHAR(40) NOT NULL,
  address VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  open_hours VARCHAR(100) NOT NULL,
  ticket_price INT NOT NULL DEFAULT 0,             -- 0 = gratis
  facilities VARCHAR(255) DEFAULT '',
  cover_media_id INT NULL,                         -- foto sampul pilihan admin (FK ditambahkan setelah tabel media)
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id),
  INDEX (region)
);

CREATE TABLE media (                               -- foto & video kunjungan pengguna
  id INT AUTO_INCREMENT PRIMARY KEY,
  destination_id INT NOT NULL,
  user_id INT NOT NULL,
  kind ENUM('photo','video') NOT NULL DEFAULT 'photo',
  file_path VARCHAR(120) NOT NULL,                 -- foto: file WebP; video: file MP4 hasil kompresi
  thumb_path VARCHAR(120) NOT NULL,                -- foto: thumbnail; video: gambar poster
  caption VARCHAR(200) DEFAULT '',
  width INT, height INT,
  duration DECIMAL(7,2) NULL,                      -- detik (khusus video)
  original_size INT NOT NULL,                      -- ukuran sebelum kompresi (byte)
  file_size INT NOT NULL,                          -- ukuran sesudah kompresi (byte)
  sha256 CHAR(64) NOT NULL UNIQUE,                 -- integritas + deteksi duplikat
  visited_at DATE NOT NULL,
  clahe TINYINT(1) NOT NULL DEFAULT 0,             -- perbaikan kontras CLAHE dipakai atau tidak
  contrast_before DECIMAL(5,2) NULL,               -- simpangan baku luminans sebelum / sesudah
  contrast_after  DECIMAL(5,2) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

ALTER TABLE destinations
  ADD CONSTRAINT fk_dest_cover FOREIGN KEY (cover_media_id) REFERENCES media(id) ON DELETE SET NULL;

CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  destination_id INT NOT NULL,
  user_id INT NOT NULL,
  rating TINYINT NOT NULL,
  comment VARCHAR(500) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (destination_id, user_id),
  FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE favorites (                           -- tombol ♥ pada tempat wisata
  user_id INT NOT NULL,
  destination_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, destination_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE CASCADE
);

CREATE TABLE reports (                             -- laporan foto dari pengguna
  id INT AUTO_INCREMENT PRIMARY KEY,
  media_id INT NOT NULL,
  user_id INT NOT NULL,                            -- pelapor
  reason VARCHAR(60) NOT NULL,
  status ENUM('open','done') NOT NULL DEFAULT 'open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_report (media_id, user_id),        -- satu laporan per pengguna per foto (dipakai ON DUPLICATE KEY)
  INDEX idx_status (status, media_id),
  FOREIGN KEY (media_id) REFERENCES media(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE login_attempts (                      -- pembatas percobaan gagal (login / pemulihan)
  id INT AUTO_INCREMENT PRIMARY KEY,
  kind ENUM('login','recover') NOT NULL,
  username VARCHAR(30) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user (kind, username, ip, created_at),
  INDEX idx_ip (kind, ip, created_at)
);

CREATE TABLE reset_requests (                      -- permintaan reset kata sandi ke admin
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  username VARCHAR(30) NOT NULL,
  note VARCHAR(300) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  status ENUM('pending','approved','rejected','invalid') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  handled_by INT NULL,
  handled_at TIMESTAMP NULL,
  INDEX idx_status (status, created_at),
  INDEX idx_ip (ip, created_at),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

INSERT INTO categories (name) VALUES
('Museum'), ('Taman & Alam'), ('Sejarah & Budaya'), ('Kuliner'), ('Seni');

-- Data contoh. Harga & jam buka PERLU diverifikasi ulang sebelum dipakai.
INSERT INTO destinations (category_id, name, slug, region, address, description, open_hours, ticket_price, facilities) VALUES
(1,'Museum Nasional Indonesia','museum-nasional','Jakarta Pusat','Jl. Medan Merdeka Barat No.12, Gambir','Museum terbesar di Indonesia dengan koleksi arkeologi, etnografi, dan keramik dari seluruh nusantara.','08:00–16:00 (Senin tutup)',10000,'Toilet, Musala, Kafe, Aksesibel kursi roda'),
(3,'Museum Fatahillah (Kota Tua)','museum-fatahillah','Jakarta Barat','Jl. Taman Fatahillah No.2, Pinangsia','Bekas balai kota Batavia yang kini menyimpan sejarah Jakarta, berhadapan dengan lapangan Kota Tua.','09:00–15:00 (Senin tutup)',5000,'Toilet, Musala, Penyewaan sepeda'),
(3,'Monumen Nasional (Monas)','monas','Jakarta Pusat','Jl. Medan Merdeka, Gambir','Tugu setinggi 132 meter dengan museum sejarah di dasar dan pelataran puncak untuk melihat kota.','08:00–16:00',15000,'Toilet, Musala, Taman, Area piknik'),
(2,'Taman Mini Indonesia Indah','tmii','Jakarta Timur','Jl. Raya Taman Mini, Ceger, Cipayung','Taman budaya dengan anjungan rumah adat 34 provinsi, museum, dan taman bermain keluarga.','08:00–17:00',20000,'Parkir luas, Toilet, Musala, Kuliner'),
(2,'Taman Margasatwa Ragunan','ragunan','Jakarta Selatan','Jl. Harsono RM No.1, Ragunan, Pasar Minggu','Kebun binatang dengan area hijau luas, cocok untuk wisata keluarga akhir pekan.','07:00–16:00',4000,'Parkir, Toilet, Musala, Penyewaan sepeda'),
(2,'Taman Impian Jaya Ancol','ancol','Jakarta Utara','Jl. Lodan Timur No.7, Pademangan','Kawasan wisata tepi pantai dengan taman rekreasi, pantai, dan area kuliner.','06:00–22:00',25000,'Parkir, Toilet, Musala, Restoran'),
(5,'Museum MACAN','museum-macan','Jakarta Barat','AKR Tower, Jl. Perjuangan No.1, Kebon Jeruk','Museum seni modern dan kontemporer dengan pameran bergilir dari seniman Indonesia dan internasional.','10:00–18:00 (Senin tutup)',100000,'Toilet, Kafe, Toko suvenir'),
(3,'Pelabuhan Sunda Kelapa','sunda-kelapa','Jakarta Utara','Jl. Maritim Raya, Penjaringan','Pelabuhan tua tempat kapal pinisi bersandar, salah satu titik awal kota Jakarta.','08:00–17:00',5000,'Toilet, Warung makan'),
(4,'Pasar Santa','pasar-santa','Jakarta Selatan','Jl. Cipaku I, Kebayoran Baru','Pasar tradisional yang kini jadi pusat kuliner dan kreator lokal anak muda.','10:00–22:00',0,'Toilet, Musala, Banyak pilihan kuliner');