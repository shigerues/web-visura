<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
if (current_user()['role'] === 'admin') { flash_set('error', 'Akun admin tidak dipakai untuk mengunggah. Admin hanya memantau kiriman pengunjung.'); header('Location: ' . BASE_URL . '/gallery.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . '/'); exit; }
csrf_check();

$st = $pdo->prepare('SELECT id, slug FROM destinations WHERE id = ?');
$st->execute([(int)($_POST['destination_id'] ?? 0)]);
$dest = $st->fetch();
if (!$dest) { flash_set('error', 'Tempat wisata tidak valid.'); header('Location: ' . BASE_URL . '/gallery.php'); exit; }
$back = BASE_URL . '/detail.php?slug=' . urlencode($dest['slug']);

try {
    $r = save_image($_FILES['photo'] ?? [], !empty($_POST['clahe']));

    // Tolak duplikat berdasarkan hash SHA-256
    $dup = $pdo->prepare('SELECT 1 FROM media WHERE sha256 = ?'); $dup->execute([$r['sha']]);
    if ($dup->fetchColumn()) {
        unlink_media_files(['file_path' => $r['file'], 'thumb_path' => $r['thumb']]);
        throw new RuntimeException('Foto ini sudah pernah diunggah.');
    }

    $visited = $_POST['visited_at'] ?? '';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $visited) || $visited > date('Y-m-d')) $visited = $r['taken'] ?? date('Y-m-d');

    $pdo->prepare('INSERT INTO media (destination_id, user_id, file_path, thumb_path, caption, width, height, original_size, file_size, sha256, visited_at, clahe, contrast_before, contrast_after)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$dest['id'], current_user()['id'], $r['file'], $r['thumb'], mb_substr(trim($_POST['caption'] ?? ''), 0, 200),
                   $r['w'], $r['h'], $r['original_size'], $r['file_size'], $r['sha'], $visited,
                   $r['clahe'] ? 1 : 0, $r['clahe']['before'] ?? null, $r['clahe']['after'] ?? null]);

    $saved = max(0, round((1 - $r['file_size'] / $r['original_size']) * 100));
    $note = $r['clahe'] ? ' Kontras diperbaiki (CLAHE): ' . number_format($r['clahe']['before'], 1, ',', '.') . ' → ' . number_format($r['clahe']['after'], 1, ',', '.') . '.' : '';
    flash_set('success', "Foto berhasil diunggah. Ukuran berkurang {$saved}% setelah dikompresi.$note");
} catch (RuntimeException $ex) {
    flash_set('error', $ex->getMessage());
}
header('Location: ' . $back); exit;