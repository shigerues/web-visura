<?php
// GET /api/destinations.php?q=&category=&region=&page=1&per_page=9
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=60');

$page = max(1, (int)($_GET['page'] ?? 1));
$per  = min(50, max(1, (int)($_GET['per_page'] ?? 9)));
[$rows, $total] = fetch_destinations($pdo, [
    'q' => trim($_GET['q'] ?? ''), 'category' => (int)($_GET['category'] ?? 0), 'region' => $_GET['region'] ?? '',
], $page, $per);

echo json_encode([
    'data' => array_map(fn($d) => [
        'id' => (int)$d['id'], 'name' => $d['name'], 'slug' => $d['slug'], 'category' => $d['category'],
        'region' => $d['region'], 'address' => $d['address'], 'open_hours' => $d['open_hours'],
        'ticket_price' => (int)$d['ticket_price'], 'rating' => $d['rating'] !== null ? (float)$d['rating'] : null,
        'thumbnail' => $d['thumb'] ? BASE_URL . '/uploads/' . $d['thumb'] : null,
    ], $rows),
    'meta' => ['page' => $page, 'per_page' => $per, 'total' => $total, 'total_pages' => (int)ceil($total / $per)],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
