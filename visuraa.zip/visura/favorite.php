<?php
ini_set('display_errors', '0');   
header('Content-Type: application/json; charset=utf-8');

function fav_fail(int $code, string $error, string $message = '') {
    http_response_code($code);
    echo json_encode(['error' => $error, 'message' => $message]);
    exit;
}

try {
    require_once __DIR__ . '/includes/functions.php';

    if (!current_user()) fav_fail(401, 'login', 'Sesi login habis. Silakan masuk lagi.');
    if (current_user()['role'] === 'admin') fav_fail(403, 'admin', 'Akun admin tidak memakai fitur favorit.');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') fav_fail(405, 'method', 'Metode tidak diizinkan.');

    $tok = $_SESSION['csrf'] ?? '';
    if ($tok === '' || !hash_equals($tok, $_POST['csrf'] ?? '')) fav_fail(419, 'csrf', 'Token halaman kedaluwarsa. Muat ulang halaman.');

    $uid = (int)current_user()['id'];
    $did = (int)($_POST['destination_id'] ?? 0);
    $ex = $pdo->prepare('SELECT 1 FROM destinations WHERE id = ?'); $ex->execute([$did]);
    if (!$ex->fetchColumn()) fav_fail(404, 'notfound', 'Tempat wisata tidak ditemukan.');

    // Toggle: kalau sudah ada -> hapus, kalau belum -> tambah
    $del = $pdo->prepare('DELETE FROM favorites WHERE user_id = ? AND destination_id = ?');
    $del->execute([$uid, $did]);
    if ($del->rowCount() > 0) {
        $fav = false;
    } else {
        $pdo->prepare('INSERT INTO favorites (user_id, destination_id) VALUES (?, ?)')->execute([$uid, $did]);
        $fav = true;
    }
    echo json_encode(['fav' => $fav]);
} catch (Throwable $e) {
    fav_fail(500, 'server', $e->getMessage());   // pesan asli ditampilkan agar penyebabnya jelas
}