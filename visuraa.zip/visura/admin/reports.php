<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $mid = (int)($_POST['media_id'] ?? 0);
    if (($_POST['action'] ?? '') === 'delete') {
        $st = $pdo->prepare('SELECT id, file_path, thumb_path FROM media WHERE id = ?'); $st->execute([$mid]);
        if ($m = $st->fetch()) { remove_media($pdo, $m); flash_set('success', 'Foto dihapus.'); }   // laporan ikut terhapus (CASCADE)
    } else {
        $pdo->prepare("UPDATE reports SET status = 'done' WHERE media_id = ?")->execute([$mid]);
        flash_set('success', 'Laporan diabaikan.');
    }
    header('Location: ' . BASE_URL . '/admin/reports.php'); exit;
}

$rows = $pdo->query("SELECT m.id, m.thumb_path, m.caption, d.name AS dest, d.slug, up.name AS uploader,
                            COUNT(r.id) AS total, GROUP_CONCAT(DISTINCT r.reason SEPARATOR ' • ') AS reasons
                     FROM reports r
                     JOIN media m ON m.id = r.media_id
                     JOIN destinations d ON d.id = m.destination_id
                     JOIN users up ON up.id = m.user_id
                     WHERE r.status = 'open'
                     GROUP BY m.id, m.thumb_path, m.caption, d.name, d.slug, up.name
                     ORDER BY total DESC, m.id DESC")->fetchAll();

$pageTitle = 'Laporan Foto';
include __DIR__ . '/../includes/header.php';
?>
<h1>Kelola</h1>
<?php admin_tabs($pdo, 'reports'); ?>
<?php if (!$rows): ?>
    <p class="empty">Tidak ada laporan baru. Semua foto aman.</p>
<?php else: ?>
<div class="rep-list">
    <?php foreach ($rows as $r): ?>
    <article class="rep">
        <a href="<?= BASE_URL ?>/detail.php?slug=<?= e($r['slug']) ?>"><img src="<?= BASE_URL ?>/uploads/<?= e($r['thumb_path']) ?>" alt=""></a>
        <div>
            <h3><?= e($r['dest']) ?></h3>
            <p class="muted">Diunggah oleh <?= e($r['uploader']) ?><?= $r['caption'] ? ' · “' . e($r['caption']) . '”' : '' ?></p>
            <p><strong><?= (int)$r['total'] ?> laporan</strong> — <?= e($r['reasons']) ?></p>
            <div class="rep-actions">
                <form method="post" onsubmit="return confirm('Hapus foto ini?')">
                    <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="media_id" value="<?= (int)$r['id'] ?>">
                    <button class="btn danger" type="submit">Hapus foto</button>
                </form>
                <form method="post">
                    <?= csrf_field() ?><input type="hidden" name="action" value="ignore"><input type="hidden" name="media_id" value="<?= (int)$r['id'] ?>">
                    <button class="btn ghost" type="submit">Abaikan laporan</button>
                </form>
            </div>
        </div>
    </article>
    <?php endforeach; ?>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
