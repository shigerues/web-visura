<?php
// ALUR 2: daftar permintaan bantuan di panel admin.
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $rid = (int)($_POST['id'] ?? 0);
    $st = $pdo->prepare("SELECT r.id, r.user_id, u.username FROM help_requests r LEFT JOIN users u ON u.id = r.user_id
                         WHERE r.id = ? AND r.status = 'open'");
    $st->execute([$rid]);
    $req = $st->fetch();
    if (!$req) {
        flash_set('error', 'Permintaan tidak ditemukan atau sudah diproses.');
    } elseif (($_POST['action'] ?? '') === 'dismiss') {
        $pdo->prepare("UPDATE help_requests SET status = 'done', handled_at = NOW() WHERE id = ?")->execute([$rid]);
        flash_set('success', 'Permintaan diabaikan.');
    } elseif (!$req['user_id']) {
        flash_set('error', 'Akun sudah tidak ada.');
    } elseif ((int)$req['user_id'] === (int)current_user()['id']) {
        flash_set('error', 'Ganti kata sandimu sendiri lewat halaman Profil.');
    } else {
        $tmp = make_temp_password();
        $pdo->prepare('UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?')
            ->execute([password_hash($tmp, PASSWORD_BCRYPT), $req['user_id']]);
        $pdo->prepare("UPDATE help_requests SET status = 'done', handled_at = NOW() WHERE user_id = ? AND status = 'open'")
            ->execute([$req['user_id']]);
        throttle_clear($pdo, 'login', $req['username']);
        flash_set('success', 'Kata sandi sementara untuk @' . $req['username'] . ': ' . $tmp
            . ' — sampaikan ke pengguna. Saat masuk ia wajib menggantinya dan otomatis mendapat kode pemulihan baru.');
    }
    header('Location: ' . BASE_URL . '/admin/requests.php'); exit;
}

$rows = $pdo->query("SELECT r.id, r.username, r.user_id, r.note, r.created_at, u.name
                     FROM help_requests r LEFT JOIN users u ON u.id = r.user_id
                     WHERE r.status = 'open' ORDER BY r.id")->fetchAll();
$pageTitle = 'Permintaan bantuan';
include __DIR__ . '/../includes/header.php';
?>
<h1>Kelola</h1>
<?php admin_tabs($pdo, 'requests'); ?>
<p class="muted">Pengguna yang lupa kata sandi dan minta bantuan. Kata sandi sementara hanya tampil sekali; pengguna wajib menggantinya saat masuk.</p>
<?php if (!$rows): ?>
    <p class="muted">Tidak ada permintaan yang menunggu.</p>
<?php else: ?>
<table class="table">
    <tr><th>Pengguna</th><th>Catatan</th><th>Dikirim</th><th></th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
        <td><?= e($r['name'] ?? '(akun dihapus)') ?><br><span class="muted">@<?= e($r['username']) ?></span></td>
        <td><?= $r['note'] !== '' ? e($r['note']) : '<span class="muted">—</span>' ?></td>
        <td><?= date('d M Y H:i', strtotime($r['created_at'])) ?></td>
        <td class="row-actions">
            <?php if ($r['user_id']): ?>
            <form method="post" onsubmit="return confirm('Buat kata sandi sementara untuk @<?= e($r['username']) ?>?')">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="link-act" type="submit" name="action" value="reset">Reset kata sandi</button>
            </form>
            <?php endif; ?>
            <form method="post">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="link-danger" type="submit" name="action" value="dismiss">Abaikan</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
