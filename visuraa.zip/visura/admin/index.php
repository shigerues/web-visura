<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$cats = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$v = ['name' => '', 'category_id' => 0, 'region' => '', 'address' => '', 'description' => '',
      'open_hours' => '', 'ticket_price' => 0, 'facilities' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (($_POST['action'] ?? '') === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        // [UBAH] hapus file foto di disk dulu; barisnya ikut terhapus lewat CASCADE
        $ms = $pdo->prepare('SELECT file_path, thumb_path FROM media WHERE destination_id = ?');
        $ms->execute([$id]);
        foreach ($ms->fetchAll() as $m) { @unlink(UPLOAD_DIR . '/' . $m['file_path']); @unlink(UPLOAD_DIR . '/' . $m['thumb_path']); }
        $pdo->prepare('DELETE FROM destinations WHERE id = ?')->execute([$id]);
        flash_set('success', 'Tempat wisata beserta fotonya dihapus.');
        header('Location: ' . BASE_URL . '/admin/'); exit;
    }

    [$v, $err] = destination_input($pdo);
    if ($err) {
        flash_set('error', $err);   // form tetap terisi agar tidak mengetik ulang
    } else {
        $slug = slugify($v['name']) ?: 'tempat'; $base = $slug; $i = 1;
        $chk = $pdo->prepare('SELECT 1 FROM destinations WHERE slug = ?');
        while (true) { $chk->execute([$slug]); if (!$chk->fetchColumn()) break; $slug = $base . '-' . (++$i); }
        $pdo->prepare('INSERT INTO destinations (category_id, name, slug, region, address, description, open_hours, ticket_price, facilities)
                       VALUES (?,?,?,?,?,?,?,?,?)')
            ->execute([$v['category_id'], $v['name'], $slug, $v['region'], $v['address'], $v['description'],
                       $v['open_hours'], $v['ticket_price'], $v['facilities']]);
        flash_set('success', 'Tempat wisata ditambahkan.');
        header('Location: ' . BASE_URL . '/admin/'); exit;
    }
}

$list = $pdo->query('SELECT d.id, d.name, d.slug, d.region, c.name AS cat,
                            (SELECT COUNT(*) FROM media m WHERE m.destination_id = d.id) AS photos
                     FROM destinations d JOIN categories c ON c.id = d.category_id ORDER BY d.id DESC')->fetchAll();
$pageTitle = 'Kelola Wisata';
include __DIR__ . '/../includes/header.php';
?>
<h1>Kelola</h1>
<?php admin_tabs($pdo, 'places');
$title = 'Tambah tempat wisata'; $submit = 'Simpan';
include __DIR__ . '/../includes/destination_form.php'; ?>

<table class="table">
    <tr><th>Nama</th><th>Kategori</th><th>Wilayah</th><th>Foto</th><th></th></tr>
    <?php foreach ($list as $r): ?>
    <tr>
        <td><a href="<?= BASE_URL ?>/detail.php?slug=<?= e($r['slug']) ?>"><?= e($r['name']) ?></a></td>
        <td><?= e($r['cat']) ?></td><td><?= e($r['region']) ?></td><td><?= (int)$r['photos'] ?></td>
        <td class="row-actions">
            <a href="<?= BASE_URL ?>/admin/edit.php?id=<?= (int)$r['id'] ?>">Ubah</a>   <!-- [BARU] -->
            <form method="post" onsubmit="return confirm('Hapus tempat ini beserta semua fotonya?')">
                <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="link-danger" type="submit">Hapus</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
