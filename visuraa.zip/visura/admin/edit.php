<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$st = $pdo->prepare('SELECT * FROM destinations WHERE id = ?');
$st->execute([(int)($_GET['id'] ?? 0)]);
$d = $st->fetch();
if (!$d) show_404();

$v = $d;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    [$v, $err] = destination_input($pdo);
    if ($err) {
        flash_set('error', $err);
    } else {
        // slug tidak diubah agar tautan lama tetap berfungsi
        $pdo->prepare('UPDATE destinations SET category_id = ?, name = ?, region = ?, address = ?, description = ?,
                       open_hours = ?, ticket_price = ?, facilities = ? WHERE id = ?')
            ->execute([$v['category_id'], $v['name'], $v['region'], $v['address'], $v['description'],
                       $v['open_hours'], $v['ticket_price'], $v['facilities'], $d['id']]);
        flash_set('success', 'Perubahan disimpan.');
        header('Location: ' . BASE_URL . '/admin/'); exit;
    }
}

$cats = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$pageTitle = 'Ubah ' . $d['name'];
include __DIR__ . '/../includes/header.php';
?>
<h1>Kelola</h1>
<?php admin_tabs($pdo, 'places'); ?>
<a class="back" href="<?= BASE_URL ?>/admin/">← Kembali ke daftar</a>
<?php $title = 'Ubah: ' . $d['name']; $submit = 'Simpan perubahan';
include __DIR__ . '/../includes/destination_form.php'; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
