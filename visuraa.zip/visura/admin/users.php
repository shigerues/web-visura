<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? 'reset';          // reset | approve | reject
    $reqId  = (int)($_POST['request_id'] ?? 0);
    $meId   = (int)current_user()['id'];

    if ($action === 'reject') {
        $pdo->prepare("UPDATE reset_requests SET status = 'rejected', handled_by = ?, handled_at = NOW() WHERE id = ? AND status = 'pending'")
            ->execute([$meId, $reqId]);
        flash_set('success', 'Permintaan ditolak.');
    } else {
        $uid = (int)($_POST['user_id'] ?? 0);
        $st = $pdo->prepare('SELECT id, username FROM users WHERE id = ?'); $st->execute([$uid]);
        $target = $st->fetch();
        if (!$target) {
            flash_set('error', 'Pengguna tidak ditemukan.');
        } elseif ($uid === $meId) {
            flash_set('error', 'Ganti kata sandimu sendiri lewat halaman Profil.');
        } else {
            // Kata sandi sementara (tampil sekali). Pengguna WAJIB menggantinya saat masuk, dan kode pemulihan lama dinonaktifkan.
            $alpha = 'abcdefghjkmnpqrstuvwxyz23456789'; $tmp = '';
            for ($i = 0; $i < 10; $i++) $tmp .= $alpha[random_int(0, strlen($alpha) - 1)];
            $pdo->prepare('UPDATE users SET password_hash = ?, must_change_password = 1, recovery_hash = NULL, recovery_enc = NULL WHERE id = ?')
                ->execute([password_hash($tmp, PASSWORD_BCRYPT), $uid]);
            $pdo->prepare("DELETE FROM login_attempts WHERE kind = 'login' AND username = ?")->execute([$target['username']]);   // buka blokir percobaan gagal
            $pdo->prepare("UPDATE reset_requests SET status = 'approved', handled_by = ?, handled_at = NOW() WHERE user_id = ? AND status = 'pending'")
                ->execute([$meId, $uid]);
            flash_set('success', 'Kata sandi sementara untuk @' . $target['username'] . ': ' . $tmp
                . ' — sampaikan lewat jalur lain (mis. WhatsApp). Pengguna wajib menggantinya saat masuk, dan kode pemulihan lamanya sudah dinonaktifkan.');
        }
    }
    header('Location: ' . BASE_URL . '/admin/users.php'); exit;
}

// Permintaan bantuan reset yang menunggu keputusan admin
$pending = []; $pstats = [];
try {
    $pending = $pdo->query("SELECT q.id, q.user_id, q.username, q.note, q.created_at, u.name, u.created_at AS joined, (u.recovery_hash IS NOT NULL) AS has_code
                            FROM reset_requests q JOIN users u ON u.id = q.user_id
                            WHERE q.status = 'pending' ORDER BY q.id ASC")->fetchAll();
    $pstats = user_stats_map($pdo, array_column($pending, 'user_id'));
} catch (PDOException $e) { /* migration5.sql belum dijalankan */ }

$rows = $pdo->query('SELECT id, name, username, role, created_at, (recovery_hash IS NOT NULL) AS has_code
                     FROM users ORDER BY id DESC')->fetchAll();
$pageTitle = 'Pengguna';
include __DIR__ . '/../includes/header.php';
?>
<h1>Kelola</h1>
<?php admin_tabs($pdo, 'users'); ?>

<h2 style="margin-top:1rem">Permintaan bantuan reset <?= $pending ? '(' . count($pending) . ')' : '' ?></h2>
<?php if (!$pending): ?>
    <p class="muted">Tidak ada permintaan baru.</p>
<?php else: ?>
    <p class="muted">Pengguna ini kehilangan kata sandi dan kode pemulihan. Cocokkan keterangan mereka dengan aktivitas akun sebelum menyetujui.</p>
    <table class="table">
        <tr><th>Pengguna</th><th>Aktivitas akun</th><th>Keterangan dari pengguna</th><th></th></tr>
        <?php foreach ($pending as $q): $s = $pstats[(int)$q['user_id']] ?? ['photos'=>0,'videos'=>0,'reviews'=>0,'places'=>0]; ?>
        <tr>
            <td><strong><?= e($q['name']) ?></strong><br>@<?= e($q['username']) ?><br>
                <small class="muted">Bergabung <?= date('d M Y', strtotime($q['joined'])) ?></small></td>
            <td><?= (int)$s['photos'] ?> foto · <?= (int)$s['videos'] ?> video<br><?= (int)$s['reviews'] ?> ulasan · <?= (int)$s['places'] ?> tempat<br>
                <small class="muted">Kode pemulihan: <?= $q['has_code'] ? 'ada' : 'belum' ?></small></td>
            <td style="max-width:360px"><?= nl2br(e($q['note'])) ?><br>
                <small class="muted">Diminta <?= date('d M Y H:i', strtotime($q['created_at'])) ?></small></td>
            <td style="white-space:nowrap">
                <form method="post" style="display:inline" onsubmit="return confirm('Setujui dan buat kata sandi sementara untuk @<?= e($q['username']) ?>? Kode pemulihan lamanya akan dinonaktifkan.')">
                    <?= csrf_field() ?><input type="hidden" name="action" value="approve">
                    <input type="hidden" name="request_id" value="<?= (int)$q['id'] ?>"><input type="hidden" name="user_id" value="<?= (int)$q['user_id'] ?>">
                    <button class="btn small-btn" type="submit">Setujui</button>
                </form>
                <form method="post" style="display:inline" onsubmit="return confirm('Tolak permintaan ini?')">
                    <?= csrf_field() ?><input type="hidden" name="action" value="reject">
                    <input type="hidden" name="request_id" value="<?= (int)$q['id'] ?>">
                    <button class="btn small-btn ghost" type="submit">Tolak</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
<?php endif; ?>

<h2 style="margin-top:2rem">Semua pengguna</h2>
<p class="muted">Reset manual untuk pengguna yang lupa kata sandi dan tidak punya kode pemulihan. Kata sandi sementara hanya tampil sekali, dan pengguna wajib menggantinya saat masuk.</p>
<table class="table">
    <tr><th>Nama</th><th>Username</th><th>Peran</th><th>Kode pemulihan</th><th>Bergabung</th><th></th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
        <td><?= e($r['name']) ?></td>
        <td>@<?= e($r['username']) ?></td>
        <td><?= $r['role'] === 'admin' ? 'Admin' : 'Anggota' ?></td>
        <td><?= $r['has_code'] ? 'Ada' : 'Belum' ?></td>
        <td><?= date('d M Y', strtotime($r['created_at'])) ?></td>
        <td>
            <?php if ((int)$r['id'] !== (int)current_user()['id']): ?>
            <form method="post" onsubmit="return confirm('Buat kata sandi sementara untuk @<?= e($r['username']) ?>?')">
                <?= csrf_field() ?><input type="hidden" name="user_id" value="<?= (int)$r['id'] ?>">
                <button class="link-act" type="submit">Reset kata sandi</button>
            </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
