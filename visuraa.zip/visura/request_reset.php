<?php
// Permintaan bantuan reset kata sandi untuk pengguna yang kehilangan kata sandi DAN kode pemulihan.
require_once __DIR__ . '/includes/functions.php';
if (current_user()) { header('Location: ' . BASE_URL . '/profile.php'); exit; }

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = substr(strtolower(trim($_POST['username'] ?? '')), 0, 30);
    $note = mb_substr(trim($_POST['note'] ?? ''), 0, 300);

    if ($username === '' || mb_strlen($note) < 10) {
        $err = 'Isi username dan keterangan (minimal 10 karakter).';
    } else {
        // Batas: 5 permintaan per jam per IP (permintaan untuk username tak dikenal tetap dihitung)
        $c = $pdo->prepare('SELECT COUNT(*) FROM reset_requests WHERE ip = ? AND created_at > (NOW() - INTERVAL 1 HOUR)');
        $c->execute([client_ip()]);
        if ((int)$c->fetchColumn() >= 5) {
            $err = 'Terlalu banyak permintaan dari perangkat ini. Coba lagi satu jam lagi.';
        } else {
            $st = $pdo->prepare("SELECT id FROM users WHERE username = ? AND role = 'user'");
            $st->execute([$username]);
            $uid = $st->fetchColumn();

            if ($uid) {
                $dup = $pdo->prepare("SELECT 1 FROM reset_requests WHERE user_id = ? AND status = 'pending'");
                $dup->execute([$uid]);
                if (!$dup->fetchColumn()) {   // satu permintaan menunggu per pengguna
                    $pdo->prepare("INSERT INTO reset_requests (user_id, username, note, ip, status) VALUES (?, ?, ?, ?, 'pending')")
                        ->execute([$uid, $username, $note, client_ip()]);
                }
            } else {
                // username tidak dikenal: dicatat sebagai 'invalid' (tidak tampil ke admin) agar batas IP tetap berlaku
                $pdo->prepare("INSERT INTO reset_requests (user_id, username, note, ip, status) VALUES (NULL, ?, ?, ?, 'invalid')")
                    ->execute([$username, $note, client_ip()]);
            }
            // Pesan sama untuk semua kasus, supaya orang lain tidak bisa menebak username yang terdaftar
            flash_set('success', 'Permintaan diterima. Jika username terdaftar, admin akan memeriksanya dan menghubungimu lewat jalur lain.');
            header('Location: ' . BASE_URL . '/login.php'); exit;
        }
    }
}

$pageTitle = 'Minta bantuan admin';
include __DIR__ . '/includes/header.php';
?>
<section class="auth">
    <div class="auth-side">
        <h2>Butuh bantuan masuk?</h2>
        <p>Kalau kata sandi dan kode pemulihanmu sama-sama hilang, admin bisa membantu setelah memastikan akun itu milikmu.</p>
        <ul class="auth-points">
            <li>Isi username dan bukti singkat kepemilikan akun</li>
            <li>Admin mencocokkannya dengan data akunmu</li>
            <li>Kamu menerima kata sandi sementara dari admin</li>
            <li>Setelah masuk, buat kata sandi baru dan kode pemulihan baru</li>
        </ul>
    </div>
    <form class="auth-form" method="post">
        <h1>Minta bantuan admin</h1>
        <p class="sub">Admin akan menghubungimu lewat jalur lain, misalnya langsung atau WhatsApp.</p>
        <?php if ($err): ?><div class="alert error"><?= e($err) ?></div><?php endif; ?>
        <?= csrf_field() ?>
        <label>Username <input name="username" required maxlength="30" autocomplete="username" value="<?= e($_POST['username'] ?? '') ?>"></label>
        <label>Bukti kepemilikan akun
            <textarea name="note" required minlength="10" maxlength="300" rows="4"
                      placeholder="Contoh: Nama lengkap saya ..., saya pernah mengunggah foto di Dufan dan menulis ulasan di Blok M, bergabung sekitar awal November."
                      style="width:100%;margin-top:.25rem;padding:.55rem .7rem;border:1px solid var(--line);border-radius:8px;font:inherit;resize:vertical"><?= e($_POST['note'] ?? '') ?></textarea>
        </label>
        <p class="muted" style="font-size:.85rem;margin:.2rem 0 .8rem">Tulis hal yang hanya diketahui pemilik akun: tempat yang pernah kamu foto atau ulas, kira-kira kapan bergabung, dan cara admin bisa menghubungimu.</p>
        <button class="btn" type="submit">Kirim permintaan</button>
        <p class="alt"><a href="<?= BASE_URL ?>/forgot_password.php">← Kembali ke atur ulang kata sandi</a></p>
    </form>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>