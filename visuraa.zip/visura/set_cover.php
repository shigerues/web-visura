<?php
// POST (admin): jadikan foto sebagai sampul tempat wisata / lepas sampul
require_once __DIR__ . '/includes/functions.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . '/'); exit; }
csrf_check();

$st = $pdo->prepare('SELECT m.id, m.destination_id, d.slug, d.cover_media_id
                     FROM media m JOIN destinations d ON d.id = m.destination_id WHERE m.id = ?');
$st->execute([(int)($_POST['media_id'] ?? 0)]);
$m = $st->fetch();
if (!$m) { flash_set('error', 'Foto tidak ditemukan.'); header('Location: ' . BASE_URL . '/'); exit; }

// Toggle: kalau sudah jadi sampul -> lepas
$isCover = (int)$m['cover_media_id'] === (int)$m['id'];
$pdo->prepare('UPDATE destinations SET cover_media_id = ? WHERE id = ?')
    ->execute([$isCover ? null : $m['id'], $m['destination_id']]);

flash_set('success', $isCover ? 'Sampul dilepas. Katalog memakai foto terbaru.' : 'Foto dijadikan sampul tempat wisata.');
header('Location: ' . BASE_URL . '/detail.php?slug=' . urlencode($m['slug'])); exit;
