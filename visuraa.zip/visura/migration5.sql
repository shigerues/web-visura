USE visura;

DELETE FROM login_attempts WHERE kind = 'help';
ALTER TABLE login_attempts MODIFY kind ENUM('login','recover') NOT NULL;
DROP TABLE help_requests;
ALTER TABLE users DROP COLUMN must_change_password;

-- LANGKAH B: pasang migration 5 versi baru (reset_requests)
ALTER TABLE users ADD must_change_password TINYINT(1) NOT NULL DEFAULT 0;

CREATE TABLE reset_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  username VARCHAR(30) NOT NULL,
  note VARCHAR(300) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  status ENUM('pending','approved','rejected','invalid') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  handled_by INT NULL,
  handled_at TIMESTAMP NULL,
  INDEX idx_status (status, created_at),
  INDEX idx_ip (ip, created_at),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);