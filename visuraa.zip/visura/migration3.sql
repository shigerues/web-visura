USE visura;

-- Dukungan video: media sekarang bisa berupa foto atau video.
-- Untuk video: file_path = file MP4 hasil kompresi, thumb_path = poster (gambar).
ALTER TABLE media
  ADD kind ENUM('photo','video') NOT NULL DEFAULT 'photo' AFTER user_id,
  ADD duration DECIMAL(7,2) NULL AFTER height;
