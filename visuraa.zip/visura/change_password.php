<?php
// Halaman wajib: pengguna yang masuk dengan kata sandi sementara dari admin harus membuat kata sandi baru.
define('ALLOW_PENDING_PW_CHANGE', true);   // jangan dialihkan ke halaman ini lagi
require_once __DIR__ . '/includes/functions.php';
require_login();
$id = (int)current_user()['id'];

if (!must_change_password($pdo)) { header('Location: ' . BASE_URL . '/profile.php'); exit; }

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $new = $_POST['new'] ?? ''; $confirm = $_POST['confirm'] ?? '';
    $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?'); $st->execute([$id]);
    $hash = (string)$st->fetchColumn();

    if (strlen($new) < 8) {
        $err = 'Kata sandi baru minimal 8 karakter.';
    } elseif ($new !== $confirm) {
        $err = 'Konfirmasi kata sandi tidak sama.';
    } elseif (password_verify($new, $hash)) {
        $err = 'Kata sandi baru tidak boleh sama dengan kata sandi sementara.';
    } else {
        $pdo->prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?')
            ->execute([password_hash($new, PASSWORD_BCRYPT), $id]);
        session_regenerate_id(true);
        $_SESSION['popup_code'] = set_recovery_code($pdo, $id);   // kode pemulihan baru, tampil sebagai pop up di Profil
        flash_set('success', 'Kata sandi berhasil diganti. Simpan kode pemulihan barumu.');
        header('Location: ' . BASE_URL . '/profile.php'); exit;
    }
}

$pageTitle = 'Buat kata sandi baru';
include __DIR__ . '/includes/header.php';
?>
<section class="auth">
    <div class="auth-side">
        <h2>Satu langkah lagi</h2>
        <p>Kamu masuk dengan kata sandi sementara dari admin. Buat kata sandi barumu sendiri supaya akunmu aman.</p>
        <ul class="auth-points">
            <li>Gunakan minimal 8 karakter</li>
            <li>Setelah ini kamu mendapat kode pemulihan baru</li>
            <li>Simpan kode itu di tempat yang aman</li>
        </ul>
    </div>
    <form class="auth-form" method="post">
        <h1>Buat kata sandi baru</h1>
        <p class="sub">Kata sandi sementara tidak berlaku lagi setelah ini.</p>
        <?php if ($err): ?><div class="alert error"><?= e($err) ?></div><?php endif; ?>
        <?= csrf_field() ?>
        <label>Kata sandi baru (min. 8 karakter) <input class="pw" type="password" name="new" required minlength="8" autocomplete="new-password" autofocus></label>
        <label>Ulangi kata sandi baru <input class="pw" type="password" name="confirm" required minlength="8" autocomplete="new-password"></label>
        <label class="check">
            <input type="checkbox" onchange="this.form.querySelectorAll('.pw').forEach(i => i.type = this.checked ? 'text' : 'password')">
            Tampilkan kata sandi
        </label>
        <button class="btn" type="submit">Simpan kata sandi baru</button>
        <p class="alt"><a href="<?= BASE_URL ?>/logout.php">Keluar</a></p>
    </form>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>