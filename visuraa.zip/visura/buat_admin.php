<?php
// Membuat atau mereset akun ADMIN lewat terminal (bukan lewat browser).
//
//   Laragon : buka Terminal Laragon di folder proyek, lalu jalankan:   php buat_admin.php
//   Lainnya : cd ke folder proyek, lalu:                                php buat_admin.php
//
// Kata sandi diketik sendiri, tidak ada kata sandi bawaan. Skrip ini menolak dijalankan lewat web.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/includes/functions.php';

function tanya(string $label, string $default = ''): string {
    echo $label . ($default !== '' ? " [$default]" : '') . ': ';
    $v = trim((string)fgets(STDIN));
    return $v === '' ? $default : $v;
}

echo "== Buat / reset akun admin Visura ==\n";
$username = strtolower(tanya('Username admin', 'admin'));
if (!preg_match('/^[a-z0-9_]{3,30}$/', $username)) exit("Username 3–30 karakter: huruf kecil, angka, atau garis bawah (_).\n");

$st = $pdo->prepare('SELECT id, role FROM users WHERE username = ?'); $st->execute([$username]);
$ada = $st->fetch();
if ($ada && $ada['role'] !== 'admin') exit("Username \"$username\" sudah dipakai akun wisatawan. Pilih username lain.\n");

echo "(Kata sandi terlihat saat diketik. Pastikan tidak ada orang lain yang melihat layar.)\n";
$pw  = tanya('Kata sandi baru (minimal 12 karakter)');
$pw2 = tanya('Ulangi kata sandi');
if (strlen($pw) < 12)  exit("Kata sandi minimal 12 karakter.\n");
if ($pw !== $pw2)      exit("Kedua kata sandi tidak sama.\n");
$hash = password_hash($pw, PASSWORD_BCRYPT);

if ($ada) {
    $pdo->prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?')->execute([$hash, $ada['id']]);
    $pdo->prepare("DELETE FROM login_attempts WHERE kind = 'login' AND username = ?")->execute([$username]);
    echo "Kata sandi admin \"$username\" diperbarui.\n";
} else {
    $nama = tanya('Nama tampilan', 'Admin Visura');
    $pdo->prepare("INSERT INTO users (name, username, password_hash, role) VALUES (?, ?, ?, 'admin')")
        ->execute([mb_substr($nama, 0, 80), $username, $hash]);
    echo "Akun admin \"$username\" dibuat.\n";
}
