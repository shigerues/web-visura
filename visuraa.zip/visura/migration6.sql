USE visura;

-- Catatan perbaikan kontras (CLAHE) per foto: apakah dipakai, serta simpangan baku luminans sebelum & sesudah
-- (angka ini bahan evaluasi untuk laporan).
ALTER TABLE media
  ADD clahe TINYINT(1) NOT NULL DEFAULT 0,
  ADD contrast_before DECIMAL(5,2) NULL,
  ADD contrast_after DECIMAL(5,2) NULL;
