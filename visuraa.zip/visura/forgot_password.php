<?php
require_once __DIR__ . '/includes/functions.php';
if (current_user()) { header('Location: ' . BASE_URL . '/profile.php'); exit; }   // yang sudah masuk ganti sandi lewat Profil

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = substr(strtolower(trim($_POST['username'] ?? '')), 0, 30);
    $code = (string)($_POST['code'] ?? '');
    $new = $_POST['new'] ?? ''; $confirm = $_POST['confirm'] ?? '';

    $wait = throttle_wait($pdo, 'recover', $username);
    if ($wait > 0) {
        $err = 'Terlalu banyak percobaan gagal. Coba lagi dalam ' . (int)ceil($wait / 60) . ' menit.';
    } elseif (strlen($new) < 8) {
        $err = 'Kata sandi baru minimal 8 karakter.';
    } elseif ($new !== $confirm) {
        $err = 'Konfirmasi kata sandi tidak sama.';
    } else {
        $st = $pdo->prepare('SELECT id, recovery_hash FROM users WHERE username = ?');
        $st->execute([$username]);
        $row = $st->fetch();
        if ($row && $row['recovery_hash'] && password_verify(norm_code($code), $row['recovery_hash'])) {
            $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($new, PASSWORD_BCRYPT), $row['id']]);
            throttle_clear($pdo, 'recover', $username);
            throttle_clear($pdo, 'login', $username);
            // kode sekali pakai -> buat kode baru
            $_SESSION['popup_code'] = set_recovery_code($pdo, (int)$row['id']);   // tampil sekali sebagai pop up
            flash_set('success', 'Kata sandi berhasil diatur ulang. Simpan kode pemulihan barumu.');
            header('Location: ' . BASE_URL . '/forgot_password.php'); exit;
        }
        $left = throttle_fail($pdo, 'recover', $username);
        $err = $left === 0
            ? 'Terlalu banyak percobaan gagal. Coba lagi dalam ' . (int)(THROTTLE_WINDOW / 60) . ' menit.'
            : 'Username atau kode pemulihan salah.' . ($left <= 3 ? " Sisa percobaan: $left." : '');
    }
}
$popupCode = $_SESSION['popup_code'] ?? null;
unset($_SESSION['popup_code']);   // hanya tampil sekali

$pageTitle = 'Lupa kata sandi';
include __DIR__ . '/includes/header.php';
?>
<section class="auth">
    <div class="auth-side">
        <h2>Lupa kata sandi? Tenang.</h2>
        <p>Atur ulang kata sandimu dengan kode pemulihan, tanpa perlu membuat akun baru. Foto dan ulasanmu tetap aman.</p>
        <ul class="auth-points">
            <li>Kode pemulihan didapat saat mendaftar</li>
            <li>Belum punya kode? Minta bantuan admin</li>
            <li>Setelah dipakai, kamu mendapat kode baru</li>
        </ul>
    </div>
    <form class="auth-form" method="post">
        <h1>Atur ulang kata sandi</h1>
        <p class="sub">Masukkan username dan kode pemulihanmu.</p>
        <?php if ($err): ?><div class="alert error"><?= e($err) ?></div><?php endif; ?>
        <?= csrf_field() ?>
        <label>Username <input name="username" required maxlength="30" autocomplete="username" value="<?= e($_POST['username'] ?? '') ?>"></label>
        <label>Kode pemulihan <input name="code" required placeholder="XXXX-XXXX-XXXX" autocomplete="off" value="<?= e($_POST['code'] ?? '') ?>"></label>
        <label>Kata sandi baru (min. 8 karakter) <input class="pw" type="password" name="new" required minlength="8" autocomplete="new-password"></label>
        <label>Ulangi kata sandi baru <input class="pw" type="password" name="confirm" required minlength="8" autocomplete="new-password"></label>
        <label class="check">
            <input type="checkbox" onchange="this.form.querySelectorAll('.pw').forEach(i => i.type = this.checked ? 'text' : 'password')">
            Tampilkan kata sandi
        </label>
        <button class="btn" type="submit">Atur ulang kata sandi</button>
        <p class="alt">Tidak punya kode pemulihan? <a href="<?= BASE_URL ?>/request_reset.php">Minta bantuan admin</a></p>
        <p class="alt"><a href="<?= BASE_URL ?>/login.php">← Kembali ke halaman masuk</a></p>
    </form>
</section>
<?php if ($popupCode): ?>
<style>
    .rc-overlay { position: fixed; inset: 0; background: rgba(15, 30, 40, .6); display: flex; align-items: center; justify-content: center; padding: 16px; z-index: 1000; }
    .rc-modal { background: #fff; border-radius: 14px; max-width: 440px; width: 100%; padding: 28px; box-shadow: 0 20px 50px rgba(0,0,0,.3); text-align: center; }
    .rc-modal h2 { margin: 0 0 8px; }
    .rc-modal p { margin: 8px 0; color: #555; font-size: .95rem; }
    .rc-code { font-family: monospace; font-size: 1.5rem; font-weight: 700; letter-spacing: 2px; background: #f3f6f8; border: 2px dashed #0f6b82; border-radius: 10px; padding: 16px 8px; margin: 16px 0; user-select: all; word-break: break-all; }
    .rc-actions { display: flex; gap: 8px; justify-content: center; flex-wrap: wrap; margin-top: 16px; }
</style>
<div class="rc-overlay" role="dialog" aria-modal="true" aria-labelledby="rcTitle">
    <div class="rc-modal">
        <h2 id="rcTitle">Simpan kode pemulihan barumu</h2>
        <p>Kata sandimu sudah diatur ulang. Kode lama sudah tidak berlaku, ini kode penggantinya.</p>
        <div class="rc-code" id="rcCode"><?= e($popupCode) ?></div>
        <p><strong>Kode hanya tampil sekali.</strong> Catat di tempat aman. Kode berlaku satu kali pakai.</p>
        <div class="rc-actions">
            <button class="btn ghost" type="button" id="rcCopy">Salin kode</button>
            <a class="btn" href="<?= BASE_URL ?>/login.php">Saya sudah menyimpannya</a>
        </div>
    </div>
</div>
<script>
    document.getElementById('rcCopy').addEventListener('click', function () {
        var t = document.getElementById('rcCode').textContent.trim(), b = this;
        (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () {
            b.textContent = 'Tersalin ✓';
        }).catch(function () {
            var r = document.createRange(); r.selectNodeContents(document.getElementById('rcCode'));
            var sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
            b.textContent = 'Tekan Ctrl+C';
        });
    });
</script>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>