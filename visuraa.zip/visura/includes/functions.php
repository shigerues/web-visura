<?php
require_once __DIR__ . '/../config.php';

const REPORT_REASONS = ['Tidak pantas', 'Bukan foto tempat ini', 'Spam atau iklan', 'Melanggar hak cipta'];

// ---------- Helper umum ----------
function e(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function rupiah(int $n): string { return $n === 0 ? 'Gratis' : 'Rp ' . number_format($n, 0, ',', '.'); }
function slugify(string $s): string { return trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($s)), '-'); }

// ---------- Level & title wisatawan ----------
// Title dihitung langsung dari aktivitas (tanpa tabel tambahan). Level tertinggi: Legenda Jakarta.
const TITLE_LEVELS = [
    1 => ['min' => 0,   'name' => 'Tunas Ibu Kota',     'icon' => '🌱', 'color' => '#4f8a4b'],
    2 => ['min' => 20,  'name' => 'Pelancong Busway',   'icon' => '🚌', 'color' => '#d1630f'],
    3 => ['min' => 50,  'name' => 'Jagoan KRL',         'icon' => '🚆', 'color' => '#d03a2a'],
    4 => ['min' => 100, 'name' => 'Penjaga Kota Tua',   'icon' => '🏛️', 'color' => '#9a6b2f'],
    5 => ['min' => 170, 'name' => 'Pendekar Monas',     'icon' => '🏙️', 'color' => '#1d4ed8'],
    6 => ['min' => 260, 'name' => 'Duta Abang None',    'icon' => '🎭', 'color' => '#7c3aed'],
    7 => ['min' => 400, 'name' => 'Legenda Betawi',     'icon' => '👑', 'color' => '#b8964f'],
];
const TITLE_POINTS = ['photos' => 10, 'videos' => 15, 'reviews' => 8, 'places' => 5, 'favs' => 2];

// Statistik aktivitas untuk beberapa pengguna sekaligus (id => angka)
function user_stats_map(PDO $pdo, array $ids): array {
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
    if (!$ids) return [];
    $in = implode(',', $ids);
    $map = [];
    foreach ($ids as $i) $map[$i] = ['photos' => 0, 'videos' => 0, 'reviews' => 0, 'places' => 0, 'favs' => 0];
    foreach ($pdo->query("SELECT user_id, SUM(kind = 'photo') AS p, SUM(kind = 'video') AS v FROM media WHERE user_id IN ($in) GROUP BY user_id") as $r) {
        $map[(int)$r['user_id']]['photos'] = (int)$r['p']; $map[(int)$r['user_id']]['videos'] = (int)$r['v'];
    }
    foreach ($pdo->query("SELECT user_id, COUNT(*) AS n FROM reviews WHERE user_id IN ($in) GROUP BY user_id") as $r) $map[(int)$r['user_id']]['reviews'] = (int)$r['n'];
    foreach ($pdo->query("SELECT user_id, COUNT(*) AS n FROM favorites WHERE user_id IN ($in) GROUP BY user_id") as $r) $map[(int)$r['user_id']]['favs'] = (int)$r['n'];
    foreach ($pdo->query("SELECT user_id, COUNT(DISTINCT destination_id) AS n FROM
                            (SELECT user_id, destination_id FROM media UNION ALL SELECT user_id, destination_id FROM reviews) x
                          WHERE user_id IN ($in) GROUP BY user_id") as $r) $map[(int)$r['user_id']]['places'] = (int)$r['n'];
    return $map;
}

// Ubah statistik menjadi poin, level, title, dan progres menuju level berikutnya
function title_for(array $s): array {
    $pts = 0;
    foreach (TITLE_POINTS as $k => $w) $pts += (int)($s[$k] ?? 0) * $w;
    $lvl = 1;
    foreach (TITLE_LEVELS as $n => $t) if ($pts >= $t['min']) $lvl = $n;
    $cur = TITLE_LEVELS[$lvl];
    $max = $lvl === count(TITLE_LEVELS);
    $next = $max ? null : TITLE_LEVELS[$lvl + 1];
    return [
        'points' => $pts, 'level' => $lvl, 'levels' => count(TITLE_LEVELS),
        'name' => $cur['name'], 'icon' => $cur['icon'], 'color' => $cur['color'],
        'max' => $max, 'next' => $next, 'need' => $max ? 0 : $next['min'] - $pts,
        'pct' => $max ? 100 : (int)floor(($pts - $cur['min']) / ($next['min'] - $cur['min']) * 100),
        'stats' => $s,
    ];
}

// id pengguna => title (untuk banyak pengguna dengan sedikit query)
function user_titles(PDO $pdo, array $ids): array {
    $out = [];
    foreach (user_stats_map($pdo, $ids) as $id => $s) $out[$id] = title_for($s);
    return $out;
}

function render_title_badge(?array $t): string {
    if (!$t) return '';
    return '<span class="tbadge" style="--tc:' . e($t['color']) . '" title="Level ' . (int)$t['level'] . ' · ' . (int)$t['points'] . ' poin">'
         . e($t['icon']) . ' ' . e($t['name']) . ' <b>Lv ' . (int)$t['level'] . '</b></span>';
}

// Sapaan sesuai jam (WIB)
function greeting(): string {
    $h = (int)(new DateTime('now', new DateTimeZone('Asia/Jakarta')))->format('G');
    return $h < 11 ? 'Selamat pagi' : ($h < 15 ? 'Selamat siang' : ($h < 18 ? 'Selamat sore' : 'Selamat malam'));
}

// ---------- Sesi, login, CSRF ----------
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void {
    if (!current_user()) { header('Location: ' . BASE_URL . '/login.php?next=' . urlencode($_SERVER['REQUEST_URI'])); exit; }
    enforce_password_change();
}

// Pengguna yang masuk dengan kata sandi sementara dari admin wajib menggantinya dulu
function must_change_password(PDO $pdo): bool {
    $u = current_user(); if (!$u) return false;
    try {
        $st = $pdo->prepare('SELECT must_change_password FROM users WHERE id = ?'); $st->execute([(int)$u['id']]);
        return (bool)$st->fetchColumn();
    } catch (PDOException $e) { return false; }   // kolom belum ada: migrasi belum dijalankan
}
function enforce_password_change(): void {
    if (defined('ALLOW_PENDING_PW_CHANGE')) return;
    if (in_array(basename($_SERVER['SCRIPT_NAME'] ?? ''), ['logout.php', 'change_password.php'], true)) return;
    global $pdo;
    if (current_user() && must_change_password($pdo)) { header('Location: ' . BASE_URL . '/change_password.php'); exit; }
}
function require_admin(): void {
    require_login();
    if (current_user()['role'] !== 'admin') { http_response_code(403); exit('Akses ditolak.'); }
}
function csrf_token(): string {   // [BARU] dipakai juga oleh JS lewat <meta>
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . csrf_token() . '">'; }
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Token tidak valid. Muat ulang halaman.'); }
}
function flash_set(string $type, string $msg): void { $_SESSION['flash'] = [$type, $msg]; }
function flash_show(): string {
    if (empty($_SESSION['flash'])) return '';
    [$t, $m] = $_SESSION['flash']; unset($_SESSION['flash']);
    return '<div class="alert ' . e($t) . '">' . e($m) . '</div>';
}

// ---------- Query katalog (dipakai halaman & API) ----------
// $f: q, category, region, sort (nama|rating|termurah|termahal|terbaru), fav (bool)
function fetch_destinations(PDO $pdo, array $f, int $page, int $perPage): array {
    $uid = (int)(current_user()['id'] ?? 0);
    $rating = '(SELECT ROUND(AVG(r.rating),1) FROM reviews r WHERE r.destination_id = d.id)';

    $where = []; $p = [];
    if (($f['q'] ?? '') !== '') {
        $where[] = '(d.name LIKE :q1 OR d.address LIKE :q2 OR d.description LIKE :q3)';
        $p[':q1'] = $p[':q2'] = $p[':q3'] = '%' . $f['q'] . '%';
    }
    if (!empty($f['category'])) { $where[] = 'd.category_id = :cat'; $p[':cat'] = (int)$f['category']; }
    if (($f['region'] ?? '') !== '') { $where[] = 'd.region = :reg'; $p[':reg'] = $f['region']; }
    if (!empty($f['fav']) && $uid) {   // [BARU] hanya favorit saya
        $where[] = "EXISTS (SELECT 1 FROM favorites fv WHERE fv.destination_id = d.id AND fv.user_id = $uid)";
    }
    $from = 'FROM destinations d JOIN categories c ON c.id = d.category_id' . ($where ? ' WHERE ' . implode(' AND ', $where) : '');

    // [BARU] urutan
    $orders = [
        'nama'     => 'd.name ASC',
        'rating'   => "($rating) IS NULL, ($rating) DESC, d.name ASC",
        'termurah' => 'd.ticket_price ASC, d.name ASC',
        'termahal' => 'd.ticket_price DESC, d.name ASC',
        'terbaru'  => 'd.id DESC',
    ];
    $order = $orders[$f['sort'] ?? 'nama'] ?? $orders['nama'];

    $st = $pdo->prepare("SELECT COUNT(*) $from"); $st->execute($p);
    $total = (int)$st->fetchColumn();

    $offset = ($page - 1) * $perPage;
    // [UBAH] thumb: pakai foto sampul bila ada, kalau tidak pakai foto terbaru
    $st = $pdo->prepare("SELECT d.*, c.name AS category,
        $rating AS rating,
        COALESCE(
            (SELECT m.thumb_path FROM media m WHERE m.id = d.cover_media_id),
            (SELECT m.thumb_path FROM media m WHERE m.destination_id = d.id ORDER BY m.id DESC LIMIT 1)
        ) AS thumb,
        COALESCE(
            (SELECT m.file_path FROM media m WHERE m.id = d.cover_media_id),
            (SELECT m.file_path FROM media m WHERE m.destination_id = d.id ORDER BY m.id DESC LIMIT 1)
        ) AS thumb_file,
        COALESCE(
            (SELECT m.width FROM media m WHERE m.id = d.cover_media_id),
            (SELECT m.width FROM media m WHERE m.destination_id = d.id ORDER BY m.id DESC LIMIT 1)
        ) AS thumb_w,
        (SELECT COUNT(*) FROM favorites fv WHERE fv.destination_id = d.id AND fv.user_id = $uid) AS is_fav
        $from ORDER BY $order LIMIT $perPage OFFSET $offset");
    $st->execute($p);
    return [$st->fetchAll(), $total];
}

function render_card(array $d): void {
    $u = current_user(); ?>
    <article class="card">
        <?php if ($u && $u['role'] === 'admin'): ?>   <!-- admin tidak punya favorit: tombol ♥ tidak ditampilkan -->
        <?php elseif ($u): ?>   <!-- [BARU] tombol favorit -->
            <button type="button" class="fav-btn<?= $d['is_fav'] ? ' on' : '' ?>" data-id="<?= (int)$d['id'] ?>"
                    aria-label="Simpan ke favorit" aria-pressed="<?= $d['is_fav'] ? 'true' : 'false' ?>">♥</button>
        <?php else: ?>
            <a class="fav-btn" href="<?= BASE_URL ?>/login.php" title="Masuk untuk menyimpan favorit" aria-label="Masuk untuk menyimpan favorit">♥</a>
        <?php endif; ?>
        <a class="card-media" href="<?= BASE_URL ?>/detail.php?slug=<?= e($d['slug']) ?>">
            <?php if ($d['thumb']): ?>
                <img <?= img_attrs($d['thumb'], $d['thumb_file'] ?? null, isset($d['thumb_w']) ? (int)$d['thumb_w'] : null) ?> alt="<?= e($d['name']) ?>" loading="lazy">
            <?php else: ?>
                <div class="ph">Belum ada foto</div>
            <?php endif; ?>
            <span class="badge"><?= e($d['category']) ?></span>
        </a>
        <div class="card-body">
            <h3><?= e($d['name']) ?></h3>
            <p class="muted"><?= $d['rating'] ? '★ ' . e($d['rating']) : 'Belum ada rating' ?> · <?= e($d['region']) ?></p>
            <p class="small"><?= e($d['open_hours']) ?></p>
            <p class="small"><?= e($d['facilities']) ?></p>
            <div class="card-foot">
                <span><small>Mulai dari</small><br><strong><?= rupiah((int)$d['ticket_price']) ?></strong></span>
                <a class="btn" href="<?= BASE_URL ?>/detail.php?slug=<?= e($d['slug']) ?>">Lihat Detail</a>
            </div>
        </div>
    </article>
<?php }

function render_pager(int $total, int $page, int $perPage): void {
    $pages = (int)ceil($total / $perPage);
    if ($pages <= 1) return;
    echo '<nav class="pager">';
    for ($i = 1; $i <= $pages; $i++) {
        $q = array_merge($_GET, ['page' => $i]); unset($q['partial']);
        echo '<a href="?' . e(http_build_query($q)) . '" class="' . ($i === $page ? 'on' : '') . '">' . $i . '</a>';
    }
    echo '</nav>';
}

// ---------- Avatar inisial & tanggal Indonesia (dipakai galeri & favorit) ----------
function render_avatar(int $id, string $name, string $cls = ''): string {
    $n = trim($name);
    $ch = $n === '' ? '?' : mb_strtoupper(mb_substr($n, 0, 1));
    $hue = ($id * 47) % 360;   // warna konsisten per pengguna
    return '<span class="avt ' . e($cls) . '" style="background:hsl(' . $hue . ',52%,40%)" aria-hidden="true">' . e($ch) . '</span>';
}
function tgl_id(?string $date): string {
    if (!$date) return '';
    $bln = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
    $t = strtotime($date);
    return date('j', $t) . ' ' . $bln[(int)date('n', $t) - 1] . ' ' . date('Y', $t);
}

// ---------- Pengolahan gambar: validasi, resize, watermark, kompresi WebP, hash ----------
function shrink(GdImage $im, int $maxW): GdImage {
    // Interpolasi bikubik; selalu menghasilkan salinan baru
    return imagescale($im, min($maxW, imagesx($im)), -1, IMG_BICUBIC);
}
function watermark(GdImage $im, string $text = 'VISURA'): void {
    $font = 4;
    $w = imagefontwidth($font) * strlen($text); $h = imagefontheight($font);
    $x = imagesx($im) - $w - 12; $y = imagesy($im) - $h - 10;
    imagestring($im, $font, $x + 1, $y + 1, $text, imagecolorallocatealpha($im, 0, 0, 0, 90));
    imagestring($im, $font, $x, $y, $text, imagecolorallocatealpha($im, 255, 255, 255, 50));
}

// ---------- [BARU] Gambar responsif: tiga ukuran (480 / 800 / 1280 px) untuk srcset ----------
const IMG_SIZES = '(max-width: 600px) 100vw, (max-width: 900px) 50vw, 340px';   // lebar tampil kartu & galeri

function media_mid_path(string $filePath): string { return preg_replace('#^media/#', 'mid/', $filePath); }

// Hapus semua varian file sebuah foto (penuh, thumbnail, menengah)
function unlink_media_files(array $m): void {
    @unlink(UPLOAD_DIR . '/' . $m['file_path']);
    @unlink(UPLOAD_DIR . '/' . $m['thumb_path']);
    if (str_starts_with($m['file_path'], 'media/')) @unlink(UPLOAD_DIR . '/' . media_mid_path($m['file_path']));
}

// Atribut <img>: src + srcset + sizes. Hanya varian yang benar-benar ada di disk yang dimasukkan,
// jadi foto lama (tanpa varian 800 px) tetap tampil normal.
function img_attrs(string $thumb, ?string $file, ?int $fullW, string $sizes = IMG_SIZES, bool $srcFull = false): string {
    $u = BASE_URL . '/uploads/';
    $src = ($srcFull && $file) ? $file : $thumb;
    $attrs = 'src="' . $u . e($src) . '"';
    if (!$file || !$fullW || !str_starts_with($file, 'media/') || !str_ends_with($file, '.webp')) return $attrs;   // video/poster: tanpa srcset

    $tw = min(480, $fullW);
    $set = [$u . e($thumb) . ' ' . $tw . 'w']; $last = $tw;
    $mw = min(800, $fullW); $mid = media_mid_path($file);
    if ($mw > $last && is_file(UPLOAD_DIR . '/' . $mid)) { $set[] = $u . e($mid) . ' ' . $mw . 'w'; $last = $mw; }
    if ($fullW > $last) $set[] = $u . e($file) . ' ' . $fullW . 'w';
    if (count($set) < 2) return $attrs;
    return $attrs . ' srcset="' . implode(', ', $set) . '" sizes="' . e($sizes) . '"';
}

// ---------- [BARU] CLAHE: Contrast Limited Adaptive Histogram Equalization (murni PHP + GD) ----------
// Gambar dibagi menjadi $tilesX x $tilesY petak. Tiap petak diratakan histogramnya pada kanal luminans (Y),
// dengan batas $clip agar noise tidak ikut menguat. Hasil antar-petak diinterpolasi bilinear supaya tanpa garis batas.
// Warna (Cb/Cr) tidak berubah karena selisih luminans ditambahkan merata ke R, G, B.
// Mengembalikan simpangan baku luminans sebelum & sesudah (ukuran kontras global).
function clahe_enhance(GdImage $im, int $tilesX = 8, int $tilesY = 8, float $clip = 3.0): array {
    $w = imagesx($im); $h = imagesy($im);
    $tw = (int)ceil($w / $tilesX); $th = (int)ceil($h / $tilesY);
    $nt = $tilesX * $tilesY;
    $hist = array_fill(0, $nt, array_fill(0, 256, 0));
    $Y = new SplFixedArray($w * $h);

    // Lintasan 1: luminans tiap piksel + histogram per petak
    $sum = 0.0; $sumSq = 0.0; $i = 0;
    for ($y = 0; $y < $h; $y++) {
        $row = intdiv($y, $th) * $tilesX;
        for ($x = 0; $x < $w; $x++) {
            $c = imagecolorat($im, $x, $y);
            $l = (int)((($c >> 16) & 255) * 0.299 + (($c >> 8) & 255) * 0.587 + ($c & 255) * 0.114 + 0.5);
            $Y[$i++] = $l;
            $hist[$row + intdiv($x, $tw)][$l]++;
            $sum += $l; $sumSq += $l * $l;
        }
    }
    $n = $w * $h;
    $mean = $sum / $n;
    $sdBefore = sqrt(max(0.0, $sumSq / $n - $mean * $mean));

    // Batasi histogram (clip), bagi rata kelebihannya, lalu bentuk tabel pemetaan (CDF) tiap petak
    $lut = [];
    for ($t = 0; $t < $nt; $t++) {
        $hh = $hist[$t];
        $limit = max(1, (int)($clip * array_sum($hh) / 256));
        $excess = 0;
        for ($v = 0; $v < 256; $v++) {
            if ($hh[$v] > $limit) { $excess += $hh[$v] - $limit; $hh[$v] = $limit; }
        }
        $add = intdiv($excess, 256); $tot = 0;
        for ($v = 0; $v < 256; $v++) { $hh[$v] += $add; $tot += $hh[$v]; }
        $cdf = 0; $L = [];
        for ($v = 0; $v < 256; $v++) { $cdf += $hh[$v]; $L[$v] = min(255, (int)round($cdf * 255 / $tot)); }
        $lut[$t] = $L;
    }

    // Petak terdekat & bobot interpolasi untuk tiap kolom dan baris (dihitung sekali)
    $axis = function (int $len, int $size, int $tn): array {
        $a0 = []; $a1 = []; $wt = [];
        for ($p = 0; $p < $len; $p++) {
            $f = ($p + 0.5) / $size - 0.5; $f0 = (int)floor($f);
            $a0[$p] = max(0, min($tn - 1, $f0));
            $a1[$p] = max(0, min($tn - 1, $f0 + 1));
            $wt[$p] = $f - $f0;
        }
        return [$a0, $a1, $wt];
    };
    [$cx0, $cx1, $ax] = $axis($w, $tw, $tilesX);
    [$cy0, $cy1, $ay] = $axis($h, $th, $tilesY);

    // Lintasan 2: pemetaan bilinear dari 4 petak sekitar, lalu terapkan selisih luminans ke RGB
    imagealphablending($im, false);
    $i = 0; $sum2 = 0.0; $sumSq2 = 0.0;
    for ($y = 0; $y < $h; $y++) {
        $r0 = $cy0[$y] * $tilesX; $r1 = $cy1[$y] * $tilesX; $wy = $ay[$y];
        for ($x = 0; $x < $w; $x++) {
            $l = $Y[$i++];
            $x0 = $cx0[$x]; $x1 = $cx1[$x]; $wx = $ax[$x];
            $a = $lut[$r0 + $x0][$l]; $b = $lut[$r0 + $x1][$l];
            $c2 = $lut[$r1 + $x0][$l]; $d = $lut[$r1 + $x1][$l];
            $top = $a + ($b - $a) * $wx; $bot = $c2 + ($d - $c2) * $wx;
            $new = (int)round($top + ($bot - $top) * $wy);
            if ($new < 0) $new = 0; elseif ($new > 255) $new = 255;
            $sum2 += $new; $sumSq2 += $new * $new;
            $dl = $new - $l;
            if ($dl !== 0) {
                $c = imagecolorat($im, $x, $y);
                $r = (($c >> 16) & 255) + $dl; $g = (($c >> 8) & 255) + $dl; $bl = ($c & 255) + $dl;
                if ($r < 0) $r = 0; elseif ($r > 255) $r = 255;
                if ($g < 0) $g = 0; elseif ($g > 255) $g = 255;
                if ($bl < 0) $bl = 0; elseif ($bl > 255) $bl = 255;
                imagesetpixel($im, $x, $y, ($c & 0x7F000000) | ($r << 16) | ($g << 8) | $bl);
            }
        }
    }
    imagealphablending($im, true);
    $mean2 = $sum2 / $n;
    $sdAfter = sqrt(max(0.0, $sumSq2 / $n - $mean2 * $mean2));
    return ['before' => round($sdBefore, 2), 'after' => round($sdAfter, 2)];
}

function save_image(array $file, bool $clahe = false): array {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('Unggahan gagal. Pilih file lalu coba lagi.');
    if ($file['size'] > MAX_UPLOAD) throw new RuntimeException('Ukuran file maksimal 5 MB.');

    // Validasi tipe: MIME + magic bytes
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $head = file_get_contents($file['tmp_name'], false, null, 0, 12);
    $magicOk = match ($mime) {
        'image/jpeg' => str_starts_with($head, "\xFF\xD8\xFF"),
        'image/png'  => str_starts_with($head, "\x89PNG"),
        'image/webp' => substr($head, 0, 4) === 'RIFF' && substr($head, 8, 4) === 'WEBP',
        default      => false,
    };
    if (!$magicOk) throw new RuntimeException('Hanya file JPG, PNG, atau WebP yang valid.');

    $sha = hash_file('sha256', $file['tmp_name']); // integritas & deteksi duplikat
    $img = match ($mime) {
        'image/jpeg' => imagecreatefromjpeg($file['tmp_name']),
        'image/png'  => imagecreatefrompng($file['tmp_name']),
        'image/webp' => imagecreatefromwebp($file['tmp_name']),
    };
    if (!$img) throw new RuntimeException('File gambar rusak.');

    // Baca EXIF (tanggal ambil foto, orientasi) khusus JPEG
    $taken = null;
    if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
        $ex = @exif_read_data($file['tmp_name']);
        if (!empty($ex['DateTimeOriginal'])) {
            $dt = DateTime::createFromFormat('Y:m:d H:i:s', $ex['DateTimeOriginal']);
            if ($dt) $taken = $dt->format('Y-m-d');
        }
        $deg = [3 => 180, 6 => -90, 8 => 90][$ex['Orientation'] ?? 1] ?? 0;
        if ($deg) $img = imagerotate($img, $deg, 0);
    }
    imagepalettetotruecolor($img);

    $name = bin2hex(random_bytes(10));
    foreach (['media', 'thumb', 'mid'] as $dir) {
        if (!is_dir(UPLOAD_DIR . "/$dir")) mkdir(UPLOAD_DIR . "/$dir", 0775, true);
    }
    $base = shrink($img, 1280);
    $stats = null;
    if ($clahe) { set_time_limit(120); $stats = clahe_enhance($base); }   // perbaikan kontras sebelum watermark & penurunan ukuran
    $src   = $clahe ? $base : $img;                                       // thumbnail & varian menengah ikut gambar yang sudah diperbaiki
    $thumb = shrink($src, 480);
    $mid   = shrink($src, 800);
    watermark($base); $full = $base;                                      // watermark hanya pada versi penuh
    imagewebp($full,  UPLOAD_DIR . "/media/$name.webp", 80);
    imagewebp($thumb, UPLOAD_DIR . "/thumb/$name.webp", 75);
    if (imagesx($full) > 800) imagewebp($mid, UPLOAD_DIR . "/mid/$name.webp", 78);   // varian 800 px hanya bila perlu

    return [
        'file' => "media/$name.webp", 'thumb' => "thumb/$name.webp", 'sha' => $sha,
        'w' => imagesx($full), 'h' => imagesy($full),
        'original_size' => (int)$file['size'], 'file_size' => filesize(UPLOAD_DIR . "/media/$name.webp"),
        'taken' => $taken, 'clahe' => $stats,
    ];
}

// Formulir unggah foto kunjungan (dipakai di detail & galeri)
function render_upload_form(PDO $pdo, ?int $fixedDest = null): void {
    if (!current_user()) { echo '<p class="muted"><a href="' . BASE_URL . '/login.php">Masuk</a> untuk membagikan foto kunjunganmu.</p>'; return; }
    if (current_user()['role'] === 'admin') return;   // admin hanya memantau kiriman pengunjung, tidak mengunggah ?>
    <form class="form box" action="<?= BASE_URL ?>/upload.php" method="post" enctype="multipart/form-data" id="upload-form">
        <?= csrf_field() ?>
        <h3>Bagikan foto kunjunganmu</h3>
        <?php if ($fixedDest): ?>
            <input type="hidden" name="destination_id" value="<?= $fixedDest ?>">
        <?php else: ?>
            <label>Tempat wisata
                <select name="destination_id" required>
                    <?php foreach ($pdo->query('SELECT id, name FROM destinations ORDER BY name') as $o): ?>
                        <option value="<?= $o['id'] ?>"><?= e($o['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        <?php endif; ?>
        <label>Foto (JPG/PNG/WebP, maks. 5 MB)
            <input type="file" name="photo" accept="image/jpeg,image/png,image/webp" required id="photo-input">
        </label>
        <img id="photo-preview" class="preview" alt="" hidden>
        <label class="check"><input type="checkbox" name="clahe" value="1"> Perbaiki kontras otomatis (CLAHE)</label>
        <p class="muted" style="font-size:.85rem;margin:-.2rem 0 .6rem">Cocok untuk foto yang terlihat pucat atau terlalu gelap. Prosesnya sedikit lebih lama.</p>
        <label>Tanggal kunjungan <input type="date" name="visited_at" max="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>"></label>
        <label>Keterangan <input type="text" name="caption" maxlength="200" placeholder="Ceritakan singkat kunjunganmu"></label>
        <button class="btn" type="submit">Unggah foto</button>
    </form>
<?php }

// ---------- [BARU] Video: validasi, kompresi H.264 (FFmpeg), poster ----------
if (!defined('FFMPEG_PATH'))        define('FFMPEG_PATH', 'ffmpeg');     // atau path lengkap, mis. C:/ffmpeg/bin/ffmpeg.exe
if (!defined('FFPROBE_PATH'))       define('FFPROBE_PATH', 'ffprobe');
if (!defined('MAX_VIDEO'))          define('MAX_VIDEO', 100 * 1024 * 1024);   // batas unggah 100 MB
if (!defined('MAX_VIDEO_SECONDS'))  define('MAX_VIDEO_SECONDS', 180);         // durasi maksimal 3 menit

function run_cmd(string $cmd): array {
    exec($cmd . ' 2>&1', $out, $rc);
    return [$rc, implode("\n", $out)];
}

function ffmpeg_ready(): bool {
    if (!function_exists('exec')) return false;
    [$rc] = run_cmd(escapeshellarg(FFMPEG_PATH) . ' -version');
    return $rc === 0;
}

// Baca lebar, tinggi, durasi dengan ffprobe. Mengembalikan null jika bukan video yang valid.
function probe_video(string $path): ?array {
    [$rc, $out] = run_cmd(escapeshellarg(FFPROBE_PATH) . ' -v error -select_streams v:0 -show_entries stream=width,height -show_entries format=duration -of json ' . escapeshellarg($path));
    if ($rc !== 0) return null;
    $j = json_decode($out, true);
    $w = (int)($j['streams'][0]['width'] ?? 0); $h = (int)($j['streams'][0]['height'] ?? 0);
    $d = (float)($j['format']['duration'] ?? 0);
    return ($w > 0 && $h > 0 && $d > 0) ? ['w' => $w, 'h' => $h, 'duration' => $d] : null;
}

function save_video(array $file): array {
    $err = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE)
        throw new RuntimeException('File melebihi batas server. Naikkan upload_max_filesize dan post_max_size di php.ini.');
    if ($err !== UPLOAD_ERR_OK) throw new RuntimeException('Unggahan gagal. Pilih file lalu coba lagi.');
    if ($file['size'] > MAX_VIDEO) throw new RuntimeException('Ukuran video maksimal ' . (int)(MAX_VIDEO / 1048576) . ' MB.');
    if (!ffmpeg_ready()) throw new RuntimeException('FFmpeg belum terpasang atau FFMPEG_PATH di config.php salah.');

    // Validasi tipe: MIME + magic bytes
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $head = (string)file_get_contents($file['tmp_name'], false, null, 0, 12);
    $isoOk  = in_array($mime, ['video/mp4', 'video/quicktime'], true) && substr($head, 4, 4) === 'ftyp';
    $webmOk = $mime === 'video/webm' && str_starts_with($head, "\x1A\x45\xDF\xA3");
    if (!$isoOk && !$webmOk) throw new RuntimeException('Hanya video MP4, MOV, atau WebM yang valid.');

    $src = probe_video($file['tmp_name']);
    if (!$src) throw new RuntimeException('File video rusak atau tidak bisa dibaca.');
    if ($src['duration'] > MAX_VIDEO_SECONDS) throw new RuntimeException('Durasi video maksimal ' . (int)(MAX_VIDEO_SECONDS / 60) . ' menit.');

    $sha = hash_file('sha256', $file['tmp_name']);   // integritas & deteksi duplikat
    $name = bin2hex(random_bytes(10));
    foreach (['video', 'thumb'] as $dir) {
        if (!is_dir(UPLOAD_DIR . "/$dir")) mkdir(UPLOAD_DIR . "/$dir", 0775, true);
    }
    $outFile = UPLOAD_DIR . "/video/$name.mp4";

    // Kompresi H.264 + AAC, maksimal lebar 1280 px, moov di depan (faststart) agar bisa diputar progresif
    $cmd = escapeshellarg(FFMPEG_PATH) . ' -y -i ' . escapeshellarg($file['tmp_name'])
         . ' -map 0:v:0 -map ' . escapeshellarg('0:a:0?')
         . ' -vf ' . escapeshellarg("scale='min(1280,iw)':-2,format=yuv420p")
         . ' -c:v libx264 -preset fast -crf 28 -c:a aac -b:a 96k -movflags +faststart -map_metadata -1 '
         . escapeshellarg($outFile);
    [$rc] = run_cmd($cmd);
    if ($rc !== 0 || !is_file($outFile) || filesize($outFile) === 0) {
        @unlink($outFile);
        throw new RuntimeException('Kompresi video gagal. Coba file video lain.');
    }

    // Poster: satu frame dari video, dijadikan WebP 480 px
    $tmpJpg = UPLOAD_DIR . "/thumb/$name.jpg";
    $at = number_format(min(1.0, $src['duration'] / 2), 2, '.', '');
    run_cmd(escapeshellarg(FFMPEG_PATH) . " -y -ss $at -i " . escapeshellarg($outFile) . ' -frames:v 1 -vf scale=480:-2 ' . escapeshellarg($tmpJpg));
    $thumbRel = "thumb/$name.webp";
    $im = is_file($tmpJpg) ? @imagecreatefromjpeg($tmpJpg) : false;
    if ($im) { imagewebp($im, UPLOAD_DIR . "/$thumbRel", 75); }
    @unlink($tmpJpg);
    if (!is_file(UPLOAD_DIR . "/$thumbRel")) { @unlink($outFile); throw new RuntimeException('Gagal membuat poster video.'); }

    $res = probe_video($outFile) ?? $src;
    return [
        'file' => "video/$name.mp4", 'thumb' => $thumbRel, 'sha' => $sha,
        'w' => $res['w'], 'h' => $res['h'], 'duration' => round($res['duration'], 2),
        'original_size' => (int)$file['size'], 'file_size' => filesize($outFile),
    ];
}

// Tampilkan satu media di galeri: <video> untuk video, <img> untuk foto
function render_media(array $m, string $alt): void {
    $u = BASE_URL . '/uploads/';
    if (($m['kind'] ?? 'photo') === 'video') { ?>
        <video controls preload="metadata" playsinline poster="<?= $u . e($m['thumb_path']) ?>" aria-label="<?= e($alt) ?>"
               style="width:100%;aspect-ratio:3/2;object-fit:contain;border-radius:10px;background:#000">
            <source src="<?= $u . e($m['file_path']) ?>" type="video/mp4">
            Browser tidak mendukung pemutar video.
        </video>
    <?php } else { ?>
        <img <?= img_attrs($m['thumb_path'], $m['file_path'], (int)($m['width'] ?? 0)) ?> data-full="<?= $u . e($m['file_path']) ?>" alt="<?= e($alt) ?>" loading="lazy" class="zoom">
    <?php }
}

// Formulir unggah video (dipakai di detail & galeri)
function render_video_form(PDO $pdo, ?int $fixedDest = null): void {
    if (!current_user() || current_user()['role'] === 'admin') return; ?>
    <form class="form box" action="<?= BASE_URL ?>/upload_video.php" method="post" enctype="multipart/form-data"
          onsubmit="var b=this.querySelector('button[type=submit]');b.disabled=true;b.textContent='Mengompres video… jangan tutup halaman'">
        <?= csrf_field() ?>
        <h3>Bagikan video kunjunganmu</h3>
        <?php if ($fixedDest): ?>
            <input type="hidden" name="destination_id" value="<?= $fixedDest ?>">
        <?php else: ?>
            <label>Tempat wisata
                <select name="destination_id" required>
                    <?php foreach ($pdo->query('SELECT id, name FROM destinations ORDER BY name') as $o): ?>
                        <option value="<?= $o['id'] ?>"><?= e($o['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        <?php endif; ?>
        <label>Video (MP4/MOV/WebM, maks. <?= (int)(MAX_VIDEO / 1048576) ?> MB, <?= (int)(MAX_VIDEO_SECONDS / 60) ?> menit)
            <input type="file" name="video" accept="video/mp4,video/quicktime,video/webm" required>
        </label>
        <label>Tanggal kunjungan <input type="date" name="visited_at" max="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>"></label>
        <label>Keterangan <input type="text" name="caption" maxlength="200" placeholder="Ceritakan singkat kunjunganmu"></label>
        <button class="btn" type="submit">Unggah video</button>
    </form>
<?php }

// ---------- [BARU] Moderasi & admin ----------
function remove_media(PDO $pdo, array $m): void {   // hapus file di disk + barisnya
    unlink_media_files($m);
    $pdo->prepare('DELETE FROM media WHERE id = ?')->execute([$m['id']]);
}

function admin_tabs(PDO $pdo, string $active): void {
    $n = (int)$pdo->query("SELECT COUNT(DISTINCT media_id) FROM reports WHERE status = 'open'")->fetchColumn();
    $pr = 0;
    try { $pr = (int)$pdo->query("SELECT COUNT(*) FROM reset_requests WHERE status = 'pending'")->fetchColumn(); } catch (PDOException $e) { /* migrasi belum dijalankan */ }
    echo '<div class="tabs">'
       . '<a href="' . BASE_URL . '/admin/" class="' . ($active === 'places' ? 'on' : '') . '">Tempat wisata</a>'
       . '<a href="' . BASE_URL . '/admin/reports.php" class="' . ($active === 'reports' ? 'on' : '') . '">Laporan foto'
       . ($n ? ' <span class="count">' . $n . '</span>' : '') . '</a>'
       . '<a href="' . BASE_URL . '/admin/users.php" class="' . ($active === 'users' ? 'on' : '') . '">Pengguna'
       . ($pr ? ' <span class="count">' . $pr . '</span>' : '') . '</a></div>';
}

// Baca & validasi form tempat wisata (dipakai tambah & ubah)
function destination_input(PDO $pdo): array {
    $d = [
        'name'         => mb_substr(trim($_POST['name'] ?? ''), 0, 150),
        'category_id'  => (int)($_POST['category_id'] ?? 0),
        'region'       => $_POST['region'] ?? '',
        'address'      => mb_substr(trim($_POST['address'] ?? ''), 0, 255),
        'description'  => trim($_POST['description'] ?? ''),
        'open_hours'   => mb_substr(trim($_POST['open_hours'] ?? ''), 0, 100),
        'ticket_price' => max(0, (int)($_POST['ticket_price'] ?? 0)),
        'facilities'   => mb_substr(trim($_POST['facilities'] ?? ''), 0, 255),
    ];
    $c = $pdo->prepare('SELECT 1 FROM categories WHERE id = ?'); $c->execute([$d['category_id']]);
    $err = '';
    if ($d['name'] === '' || $d['address'] === '') $err = 'Nama dan alamat wajib diisi.';
    elseif (!in_array($d['region'], REGIONS, true)) $err = 'Pilih wilayah yang valid.';
    elseif (!$c->fetchColumn()) $err = 'Pilih kategori yang valid.';
    return [$d, $err];
}

// ---------- [BARU] Pembatasan percobaan login ----------
const THROTTLE_MAX    = 5;     // maks. gagal per username + IP
const THROTTLE_MAX_IP = 20;    // maks. gagal per IP (semua username)
const THROTTLE_WINDOW = 900;   // jendela waktu: 15 menit (detik)

function client_ip(): string { return substr($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', 0, 45); }

// Detik yang harus ditunggu jika diblokir; 0 jika boleh mencoba.
function throttle_wait(PDO $pdo, string $kind, string $username): int {
    $w = THROTTLE_WINDOW;
    $sql = "SELECT COUNT(*) AS n, GREATEST(0, $w - TIMESTAMPDIFF(SECOND, MIN(created_at), NOW())) AS wait
            FROM login_attempts WHERE kind = ? AND ip = ? AND created_at > (NOW() - INTERVAL $w SECOND)";
    $byUser = $pdo->prepare($sql . ' AND username = ?');
    $byUser->execute([$kind, client_ip(), $username]);
    $a = $byUser->fetch();
    $byIp = $pdo->prepare($sql);
    $byIp->execute([$kind, client_ip()]);
    $b = $byIp->fetch();

    $wait = 0;
    if ((int)$a['n'] >= THROTTLE_MAX)    $wait = max($wait, (int)$a['wait']);
    if ((int)$b['n'] >= THROTTLE_MAX_IP) $wait = max($wait, (int)$b['wait']);
    return $wait;
}

// Catat satu kegagalan; mengembalikan sisa percobaan untuk username + IP ini.
function throttle_fail(PDO $pdo, string $kind, string $username): int {
    $pdo->prepare('INSERT INTO login_attempts (kind, username, ip) VALUES (?, ?, ?)')->execute([$kind, $username, client_ip()]);
    $pdo->exec('DELETE FROM login_attempts WHERE created_at < (NOW() - INTERVAL 1 DAY)');   // bersih-bersih
    $w = THROTTLE_WINDOW;
    $c = $pdo->prepare("SELECT COUNT(*) FROM login_attempts WHERE kind = ? AND username = ? AND ip = ? AND created_at > (NOW() - INTERVAL $w SECOND)");
    $c->execute([$kind, $username, client_ip()]);
    return max(0, THROTTLE_MAX - (int)$c->fetchColumn());
}

function throttle_clear(PDO $pdo, string $kind, string $username): void {
    $pdo->prepare('DELETE FROM login_attempts WHERE kind = ? AND username = ? AND ip = ?')->execute([$kind, $username, client_ip()]);
}

// ---------- [BARU] Kode pemulihan (untuk lupa kata sandi) ----------
function new_recovery_code(): string {
    $alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // tanpa I, O, 0, 1 agar tidak membingungkan
    $c = '';
    for ($i = 0; $i < 12; $i++) $c .= $alpha[random_int(0, strlen($alpha) - 1)];
    return implode('-', str_split($c, 4));
}
function norm_code(string $c): string { return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $c)); }

// ---- Enkripsi kode pemulihan (AES-256-GCM) agar bisa ditampilkan lagi di profil ----
// Kunci: APP_KEY di config.php (jika ada), atau dibuat otomatis di includes/app_key.php.
// Jangan hapus app_key.php: tanpa kunci yang sama, kode lama tidak bisa ditampilkan lagi.
function app_key(): string {
    if (defined('APP_KEY') && APP_KEY !== '') return hash('sha256', APP_KEY, true);
    $f = __DIR__ . '/app_key.php';
    if (!is_file($f) && @file_put_contents($f, "<?php\nreturn '" . bin2hex(random_bytes(32)) . "';\n", LOCK_EX) === false)
        throw new RuntimeException('Kunci enkripsi tidak bisa dibuat. Isi APP_KEY di config.php.');
    return hash('sha256', (string)require $f, true);
}
function encrypt_code(string $plain): string {
    $iv = random_bytes(12);
    $ct = openssl_encrypt($plain, 'aes-256-gcm', app_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($ct === false) throw new RuntimeException('Enkripsi gagal.');
    return base64_encode($iv . $tag . $ct);
}
function decrypt_code(?string $blob): ?string {
    if (!$blob) return null;
    $raw = base64_decode($blob, true);
    if ($raw === false || strlen($raw) < 29) return null;
    try {
        $pt = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', app_key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    } catch (Throwable $e) { return null; }
    return $pt === false ? null : $pt;
}

function set_recovery_code(PDO $pdo, int $userId): string {
    $code = new_recovery_code();
    try { $enc = encrypt_code($code); } catch (Throwable $e) { $enc = null; }
    $pdo->prepare('UPDATE users SET recovery_hash = ?, recovery_enc = ? WHERE id = ?')
        ->execute([password_hash(norm_code($code), PASSWORD_BCRYPT), $enc, $userId]);
    return $code;
}

// ---------- [BARU] Halaman 404 ----------
function show_404(): void {
    http_response_code(404);
    include __DIR__ . '/../404.php';
    exit;
}