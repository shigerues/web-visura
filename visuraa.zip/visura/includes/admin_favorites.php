<?php
// Tampilan Favorit untuk ADMIN: tempat wisata yang disukai wisatawan, lengkap dengan siapa saja yang menyukainya.
// Hanya akun wisatawan (role = 'user') yang dihitung; akun admin tidak ikut.
// Dipanggil dari index.php?fav=1 (variabel $pdo & fungsi dari functions.php sudah tersedia).

$q = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1)); $perPage = 9; $offset = ($page - 1) * $perPage;

$likedBy = "EXISTS (SELECT 1 FROM favorites f JOIN users u ON u.id = f.user_id
                    WHERE f.destination_id = d.id AND u.role = 'user')";
$w = $likedBy; $p = [];
if ($q !== '') { $w .= ' AND d.name LIKE :q'; $p[':q'] = '%' . $q . '%'; }

// Ringkasan
$sum = $pdo->query("SELECT COUNT(*) AS likes, COUNT(DISTINCT f.destination_id) AS places, COUNT(DISTINCT f.user_id) AS people
                    FROM favorites f JOIN users u ON u.id = f.user_id WHERE u.role = 'user'")->fetch();

$st = $pdo->prepare("SELECT COUNT(*) FROM destinations d WHERE $w"); $st->execute($p);
$total = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT d.id, d.name, d.slug, d.region, c.name AS category,
        (SELECT COUNT(*) FROM favorites f JOIN users u ON u.id = f.user_id
          WHERE f.destination_id = d.id AND u.role = 'user') AS likes,
        COALESCE(
            (SELECT m.thumb_path FROM media m WHERE m.id = d.cover_media_id),
            (SELECT m.thumb_path FROM media m WHERE m.destination_id = d.id ORDER BY m.id DESC LIMIT 1)
        ) AS thumb
    FROM destinations d JOIN categories c ON c.id = d.category_id
    WHERE $w ORDER BY likes DESC, d.name ASC LIMIT $perPage OFFSET $offset");
$st->execute($p);
$places = $st->fetchAll();

// Daftar wisatawan per tempat (satu query untuk semua kartu di halaman ini)
$people = [];
if ($places) {
    $ids = array_map('intval', array_column($places, 'id'));
    $in  = implode(',', $ids);
    foreach ($pdo->query("SELECT f.destination_id AS did, u.id, u.name, u.username
                          FROM favorites f JOIN users u ON u.id = f.user_id
                          WHERE u.role = 'user' AND f.destination_id IN ($in) ORDER BY u.name ASC") as $r) {
        $people[$r['did']][] = $r;
    }
}

$pageTitle = 'Favorit wisatawan';
include __DIR__ . '/header.php';
?>
<section class="gal-hero admin-hero">
    <p class="eyebrow">Ringkasan favorit</p>
    <h1>Tempat favorit wisatawan</h1>
    <p class="lead">Lihat tempat wisata mana yang paling disukai, dan siapa saja wisatawan yang menyimpannya.</p>
    <div class="gal-stats">
        <div><strong><?= (int)$sum['likes'] ?></strong><span>total ♥ dari wisatawan</span></div>
        <div><strong><?= (int)$sum['places'] ?></strong><span>tempat disukai</span></div>
        <div><strong><?= (int)$sum['people'] ?></strong><span>wisatawan aktif</span></div>
    </div>
</section>

<form class="fav-search" method="get">
    <input type="hidden" name="fav" value="1">
    <input type="search" name="q" placeholder="Cari tempat yang disukai…" value="<?= e($q) ?>" aria-label="Cari tempat">
    <button class="btn" type="submit">Cari</button>
    <?php if ($q !== ''): ?><a class="btn ghost" href="<?= BASE_URL ?>/?fav=1">Reset</a><?php endif; ?>
</form>

<?php if ($places): ?>
<div class="fav-grid">
    <?php foreach ($places as $i => $d):
        $list  = $people[$d['id']] ?? [];
        $n     = count($list);
        $names = array_map(fn($x) => $x['name'], array_slice($list, 0, 2));
        $text  = 'Disukai ' . e(implode(', ', $names)) . ($n > 2 ? ' dan ' . ($n - 2) . ' lainnya' : '');
        $rank  = ($page === 1 && $q === '' && $i < 3 && (int)$d['likes'] > 0) ? $i + 1 : 0; ?>
    <article class="fav-tile">
        <a class="fav-cover" href="<?= BASE_URL ?>/detail.php?slug=<?= e($d['slug']) ?>">
            <?php if ($d['thumb']): ?>
                <img src="<?= BASE_URL ?>/uploads/<?= e($d['thumb']) ?>" alt="<?= e($d['name']) ?>" loading="lazy">
            <?php else: ?><span class="fav-noimg">Belum ada foto</span><?php endif; ?>
            <?php if ($rank): ?><span class="fav-rank">#<?= $rank ?></span><?php endif; ?>
            <span class="fav-like">♥ <?= (int)$d['likes'] ?></span>
            <span class="fav-name"><?= e($d['name']) ?></span>
        </a>
        <div class="fav-body">
            <p class="fav-sub"><span class="badge static"><?= e($d['category']) ?></span> <?= e($d['region']) ?></p>
            <div class="fav-people">
                <div class="stack">
                    <?php foreach (array_slice($list, 0, 5) as $x) echo render_avatar((int)$x['id'], $x['name']); ?>
                    <?php if ($n > 5): ?><span class="avt more">+<?= $n - 5 ?></span><?php endif; ?>
                </div>
                <span class="fav-text"><?= $text ?></span>
            </div>
            <details class="fav-list">
                <summary>Lihat semua <?= $n ?> wisatawan</summary>
                <ul>
                    <?php foreach ($list as $x): ?>
                    <li><?= render_avatar((int)$x['id'], $x['name']) ?><span><strong><?= e($x['name']) ?></strong> <small>@<?= e($x['username']) ?></small></span></li>
                    <?php endforeach; ?>
                </ul>
            </details>
        </div>
    </article>
    <?php endforeach; ?>
</div>
<?php render_pager($total, $page, $perPage); else: ?>
<p class="empty"><?= $q !== ''
    ? 'Tidak ada tempat favorit yang cocok dengan pencarian ini.'
    : 'Belum ada wisatawan yang menyukai tempat wisata. Daftar ini akan terisi saat wisatawan menekan ♥ pada sebuah tempat.' ?></p>
<?php endif;
include __DIR__ . '/footer.php';