</main>
<footer class="foot">Visura — informasi wisata lokal Jakarta · Tugas Besar Sistem Multimedia, Kelompok 6</footer>
<div id="lightbox" class="lightbox" hidden><img alt=""><button aria-label="Tutup">✕</button></div>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>
</html>
