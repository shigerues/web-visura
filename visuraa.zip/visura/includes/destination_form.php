<?php /* Form tempat wisata (tambah & ubah). Butuh: $v (nilai), $cats, $title, $submit */ ?>
<form class="form box" method="post">
    <?= csrf_field() ?>
    <h3><?= e($title) ?></h3>
    <label>Nama <input name="name" required maxlength="150" value="<?= e($v['name']) ?>"></label>
    <label>Kategori
        <select name="category_id">
            <?php foreach ($cats as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= (int)$v['category_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Wilayah
        <select name="region">
            <?php foreach (REGIONS as $r): ?>
                <option <?= $v['region'] === $r ? 'selected' : '' ?>><?= e($r) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Alamat <input name="address" required maxlength="255" value="<?= e($v['address']) ?>"></label>
    <label>Jam buka <input name="open_hours" maxlength="100" placeholder="08:00–16:00 (Senin tutup)" value="<?= e($v['open_hours']) ?>"></label>
    <label>Harga tiket (Rp, 0 = gratis) <input type="number" name="ticket_price" min="0" value="<?= (int)$v['ticket_price'] ?>"></label>
    <label>Fasilitas <input name="facilities" maxlength="255" placeholder="Toilet, Musala, Parkir" value="<?= e($v['facilities']) ?>"></label>
    <label>Deskripsi <textarea name="description" rows="4"><?= e($v['description']) ?></textarea></label>
    <button class="btn" type="submit"><?= e($submit) ?></button>
</form>
