USE visura;

-- Kode pemulihan disimpan juga dalam bentuk TERENKRIPSI (AES-256-GCM) agar bisa ditampilkan di profil.
-- recovery_hash tetap dipakai untuk memeriksa kode saat atur ulang kata sandi.
ALTER TABLE users ADD recovery_enc VARCHAR(255) NULL AFTER recovery_hash;
