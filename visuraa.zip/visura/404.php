<?php
require_once __DIR__ . '/includes/functions.php';
http_response_code(404);
$pageTitle = 'Halaman tidak ditemukan';
include __DIR__ . '/includes/header.php';
?>
<section class="notfound">
    <div class="big">4<span>0</span>4</div>
    <h1>Halaman tidak ditemukan</h1>
    <p class="muted">Tempat atau halaman yang kamu cari mungkin sudah dipindahkan, dihapus, atau tautannya salah.</p>
    <form class="nf-search" action="<?= BASE_URL ?>/" method="get">
        <input type="search" name="q" placeholder="Cari tempat wisata…" aria-label="Cari tempat wisata">
        <button class="btn" type="submit">Cari</button>
    </form>
    <div class="nf-actions">
        <a class="btn" href="<?= BASE_URL ?>/">Kembali ke katalog</a>
        <a class="btn ghost" href="<?= BASE_URL ?>/gallery.php">Lihat galeri</a>
    </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
