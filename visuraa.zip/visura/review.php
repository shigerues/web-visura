<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . '/'); exit; }
csrf_check();

$id = (int)($_POST['destination_id'] ?? 0);
$rating = (int)($_POST['rating'] ?? 0);
$st = $pdo->prepare('SELECT slug FROM destinations WHERE id = ?'); $st->execute([$id]);
$slug = $st->fetchColumn();
if (!$slug || $rating < 1 || $rating > 5) { flash_set('error', 'Ulasan tidak valid.'); header('Location: ' . BASE_URL . '/'); exit; }

// Satu ulasan per pengguna per tempat; kirim ulang = perbarui
$pdo->prepare('INSERT INTO reviews (destination_id, user_id, rating, comment) VALUES (?,?,?,?)
               ON DUPLICATE KEY UPDATE rating = VALUES(rating), comment = VALUES(comment)')
    ->execute([$id, current_user()['id'], $rating, mb_substr(trim($_POST['comment'] ?? ''), 0, 500)]);
flash_set('success', 'Ulasan tersimpan.');
header('Location: ' . BASE_URL . '/detail.php?slug=' . urlencode($slug)); exit;
