# Visura — Panduan Instalasi & Setup Database

Dokumentasi ini ditujukan bagi pengguna atau developer lain yang ingin menjalankan aplikasi **Visura** dan menyiapkan struktur databasenya di lingkungan lokal maupun server produksi.

---

## 1. Prasyarat Sistem

Pastikan lingkungan server Anda memenuhi kebutuhan berikut:
- **PHP**: Versi `8.0` atau lebih baru
- **Ekstensi PHP**: `mysqli` / `pdo_mysql`, `gd` atau `imagick` (untuk konversi gambar `.webp` dan pembuatan *thumbnail*), `fileinfo`, `mbstring`
- **Database**: MySQL `5.7+` atau MariaDB `10.3+` (dengan dukungan charset `utf8mb4`)
- **Web Server**: Apache (dengan `mod_rewrite` aktif untuk membaca `.htaccess`) atau Nginx

---

## 2. Cara Setup Database

Tersedia **dua cara** untuk menyiapkan database. Pilih salah satu sesuai kebutuhan Anda:

### Opsi A: Import Langsung (Direkomendasikan)
Gunakan cara ini jika Anda ingin langsung mendapatkan struktur database terbaru tanpa menjalankan migrasi satu per satu.

1. Buat database baru di MySQL/MariaDB (misalnya bernama `visura`):
   ```sql
   CREATE DATABASE visura CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
2. Import file **`database.sql`** ke dalam database tersebut melalui phpMyAdmin, DBeaver, atau terminal:
   ```bash
   mysql -u root -p visura < database.sql
   ```

### Opsi B: Menggunakan File Migrasi Bertahap
Gunakan cara ini jika Anda ingin membangun atau melacak perubahan skema database secara bertahap dari awal.

Jalankan file SQL secara **berurutan** dari nomor terkecil hingga terbesar:
1. `migration1.sql` *(Skema awal / baseline tabel inti)*
2. `migration2.sql`
3. `migration3.sql`
4. `migration4.sql`
5. `migration5.sql`
6. `migration6.sql`

> **Catatan Penting:** File `migration1.sql` dibuat sebagai *baseline* awal karena pada pengembangan mula-mula tabel dibuat langsung di database. Jika terjadi perbedaan kecil pada nama kolom saat menjalankan `migration2.sql` – `migration6.sql`, silakan sesuaikan atau gunakan **Opsi A (`database.sql`)** sebagai acuan struktur final.

---

## 3. Konfigurasi Aplikasi

1. **Koneksi Database (`config.php`)**
   Buka file `config.php` dan sesuaikan kredensial database dengan konfigurasi server Anda:
   - Host database (contoh: `localhost`)
   - Nama database (contoh: `visura`)
   - Username & Password database
   - Base URL aplikasi (jika diperlukan)

2. **Kunci Aplikasi (`includes/app_key.php`)**
   Periksa file `includes/app_key.php` dan pastikan nilai *app key* sudah terisi (ganti dengan string acak yang unik jika aplikasi akan di-deploy ke server publik).

---

## 4. Membuat Akun Admin & Data Awal

1. **Buat Akun Admin**
   Jalankan skrip **`buat_admin.php`** melalui browser (`http://localhost/visura/buat_admin.php`) atau CLI untuk membuat akun administrator pertama.
   > ⚠️ **Peringatan Keamanan:** Setelah akun admin berhasil dibuat, segera **hapus atau pindahkan** file `buat_admin.php` agar tidak dapat diakses oleh publik.

2. **Sinkronisasi Gambar Medium (Opsional)**
   Jika Anda mengimpor data lama yang sudah memiliki gambar di `uploads/media/` tetapi belum memiliki salinan ukuran sedang di `uploads/mid/`, jalankan file **`backfill_mid.php`** untuk membuat ulang gambar versi *mid* secara otomatis.

---

## 5. Izin Akses Folder (`uploads/`)

Pastikan web server memiliki izin baca dan tulis (*read & write*) ke direktori penyimpanan media berikut:
- `uploads/media/`
- `uploads/mid/`
- `uploads/thumb/`
- `uploads/video/`

Jika menggunakan Linux/macOS, Anda dapat mengatur izinnya dengan perintah:
```bash
chmod -R 775 uploads/
```

---

## 6. Checklist Keamanan Sebelum Online

- [ ] Hapus atau batasi akses ke file `buat_admin.php` dan `backfill_mid.php`.
- [ ] Pastikan file `.sql` (`database.sql` dan `migration*.sql`) tidak disimpan di folder publik atau sudah diblokir melalui `.htaccess`.
- [ ] Pastikan `uploads/.htaccess` aktif untuk mencegah eksekusi skrip berbahaya di dalam folder unggahan.