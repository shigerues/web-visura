<?php
// Sekali jalan: buat varian 800 px untuk foto lama agar ikut dipakai srcset. Hanya admin. Hapus file ini setelah selesai.
require_once __DIR__ . '/includes/functions.php';
require_admin();
set_time_limit(300);
header('Content-Type: text/plain; charset=utf-8');

if (!is_dir(UPLOAD_DIR . '/mid')) mkdir(UPLOAD_DIR . '/mid', 0775, true);
$made = 0; $skip = 0; $fail = 0;
foreach ($pdo->query("SELECT id, file_path, width FROM media WHERE file_path LIKE 'media/%.webp'") as $m) {
    $mid = UPLOAD_DIR . '/' . media_mid_path($m['file_path']);
    if ((int)$m['width'] <= 800 || is_file($mid)) { $skip++; continue; }
    $im = @imagecreatefromwebp(UPLOAD_DIR . '/' . $m['file_path']);
    if (!$im) { $fail++; echo "Gagal membaca: {$m['file_path']}\n"; continue; }
    imagewebp(shrink($im, 800), $mid, 78);
    $made++;
}
echo "Selesai. Dibuat: $made, dilewati (sudah ada / tidak perlu): $skip, gagal: $fail\n";
echo "Hapus file backfill_mid.php setelah ini.\n";
