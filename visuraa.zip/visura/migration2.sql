USE visura;

-- Kode pemulihan (disimpan dalam bentuk hash, sama seperti kata sandi)
ALTER TABLE users ADD recovery_hash VARCHAR(255) NULL;

-- Catatan percobaan gagal (untuk membatasi tebak-tebakan kata sandi)
CREATE TABLE login_attempts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kind ENUM('login','recover') NOT NULL,
  username VARCHAR(30) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user (kind, username, ip, created_at),
  INDEX idx_ip (kind, ip, created_at)
);
