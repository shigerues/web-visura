const BASE = document.querySelector('meta[name="base-url"]')?.content ?? '';

// Menu mobile
const nav = document.getElementById('nav');
document.getElementById('nav-toggle')?.addEventListener('click', () => nav.classList.toggle('open'));

// Pencarian langsung: ambil grid HTML dari index.php?partial=1 (debounce 300 ms)
const filters = document.getElementById('filters');
const catalog = document.getElementById('catalog');
if (filters && catalog) {
  let timer;
  const load = async () => {
    const params = new URLSearchParams(new FormData(filters));
    catalog.classList.add('loading');
    try {
      const res = await fetch('?' + params.toString() + '&partial=1');
      catalog.innerHTML = await res.text();
      history.replaceState(null, '', '?' + params.toString());
    } catch (e) {
      catalog.innerHTML = '<p class="empty">Gagal memuat. Periksa koneksi lalu coba lagi.</p>';
    } finally {
      catalog.classList.remove('loading');
    }
  };
  filters.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(load, 300); });
  filters.addEventListener('submit', e => { e.preventDefault(); load(); });
}

// Lightbox untuk foto galeri (delegasi event)
const box = document.getElementById('lightbox');
document.addEventListener('click', e => {
  const img = e.target.closest('img.zoom');
  if (img) { box.querySelector('img').src = img.dataset.full || img.src; box.hidden = false; return; }
  if (e.target === box || e.target.closest('#lightbox button')) box.hidden = true;
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') box.hidden = true; });

// Favorit: tombol ♥ (kartu katalog & halaman detail) tanpa memuat ulang halaman
document.addEventListener('click', async e => {
  const btn = e.target.closest('button.fav-btn');
  if (!btn) return;
  e.preventDefault();
  const body = new FormData();
  body.append('csrf', document.querySelector('meta[name="csrf"]')?.content ?? '');
  body.append('destination_id', btn.dataset.id);
  btn.disabled = true;
  try {
    const res = await fetch(BASE + '/favorite.php', { method: 'POST', body });
    if (!res.ok) throw new Error('gagal');
    const data = await res.json();
    btn.classList.toggle('on', data.fav);
    btn.setAttribute('aria-pressed', data.fav ? 'true' : 'false');
    // di halaman Favorit, kartu yang dilepas langsung hilang
    if (!data.fav && new URLSearchParams(location.search).has('fav')) {
      btn.closest('.card')?.remove();
      if (!document.querySelector('.grid .card')) location.reload();   // daftar kosong -> tampilkan pesan kosong
    }
  } catch (err) {
    alert('Gagal menyimpan favorit. Coba lagi.');
  } finally {
    btn.disabled = false;
  }
});

// Pratinjau & cek ukuran foto sebelum diunggah
const input = document.getElementById('photo-input');
const preview = document.getElementById('photo-preview');
input?.addEventListener('change', () => {
  const f = input.files[0];
  if (!f) return;
  if (f.size > 5 * 1024 * 1024) { alert('Ukuran file maksimal 5 MB.'); input.value = ''; preview.hidden = true; return; }
  preview.src = URL.createObjectURL(f); preview.hidden = false;
});