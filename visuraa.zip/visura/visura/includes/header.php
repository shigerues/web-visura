<?php
require_once __DIR__ . '/functions.php'; $navUser = current_user();
// penanda halaman aktif
$cur   = basename($_SERVER['SCRIPT_NAME']);
$mine  = isset($_GET['mine']);
$onFavPage = isset($_GET['fav']);
$inAdmin = str_contains($_SERVER['SCRIPT_NAME'], '/admin/');
$act   = fn(bool $on) => $on ? ' class="active"' : '';
$roleClass = $navUser ? ($navUser['role'] === 'admin' ? 'is-admin' : 'is-user') : 'is-guest';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf" content="<?= e(csrf_token()) ?>">
<meta name="base-url" content="<?= e(BASE_URL) ?>">
<title><?= e($pageTitle ?? 'Visura') ?> — Visura</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css?v=<?= filemtime(__DIR__ . '/../assets/css/style.css') ?>">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/gallery.css?v=<?= filemtime(__DIR__ . '/../assets/css/gallery.css') ?>">
<link rel="icon" href="<?= BASE_URL ?>/assets/img/logo.png">
</head>
<body class="<?= $roleClass ?>">
<header class="top">
    <a class="logo" href="<?= BASE_URL ?>/">
        <img src="<?= BASE_URL ?>/assets/img/logo.png" alt="" class="logo-img">
        <span class="logo-text">Visura</span>
        <?php if ($roleClass === 'is-admin'): ?><span class="role-pill">Admin</span><?php endif; ?>
    </a>
    <button class="nav-toggle" aria-label="Menu" id="nav-toggle">Menu</button>
    <nav id="nav">
        <a href="<?= BASE_URL ?>/"<?= $act($cur === 'index.php' && !$onFavPage) ?>>Katalog</a>
        <a href="<?= BASE_URL ?>/gallery.php"<?= $act($cur === 'gallery.php' && !$mine) ?>>Galeri</a>
        <?php if ($navUser): ?>
            <a href="<?= BASE_URL ?>/?fav=1"<?= $act($cur === 'index.php' && $onFavPage) ?>>Favorit</a>
            <?php if ($navUser['role'] === 'admin'): ?>
                <a href="<?= BASE_URL ?>/admin/"<?= $act($inAdmin) ?>>Kelola</a>
            <?php endif; ?>
            <?php if ($navUser['role'] !== 'admin'): ?>
                <a href="<?= BASE_URL ?>/gallery.php?mine=1"<?= $act($cur === 'gallery.php' && $mine) ?>>Foto saya</a>
            <?php endif; ?>
            <a href="<?= BASE_URL ?>/profile.php"<?= $act($cur === 'profile.php') ?>>Profil</a>
            <a class="nav-out" href="<?= BASE_URL ?>/logout.php">Keluar (<?= e($navUser['name']) ?>)</a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/login.php"<?= $act($cur === 'login.php') ?>>Masuk</a>
            <a class="btn small-btn" href="<?= BASE_URL ?>/register.php">Daftar</a>
        <?php endif; ?>
    </nav>
</header>
<main class="wrap">
<?= flash_show() ?>