<?php
// Halaman sambutan (onboarding) untuk pengunjung yang belum login.
require_once __DIR__ . '/includes/functions.php';
if (current_user()) { header('Location: ' . BASE_URL . '/'); exit; }
$_SESSION['seen_welcome'] = 1;   // setelah ini, katalog & galeri bisa dibuka bebas sebagai tamu
$img = BASE_URL . '/assets/img/';

$slides = [
    ['Jelajahi Jakarta.<br>Temukan tempat favoritmu.', 'Telusuri destinasi wisata lokal lengkap dengan harga tiket, jam buka, fasilitas, dan ulasan wisatawan.'],
    ['Abadikan momen.<br>Bagikan ke semua orang.', 'Unggah foto dan video kunjunganmu, lalu lihat kiriman wisatawan lain di galeri pengunjung.'],
    ['Simpan favorit.<br>Rencanakan kunjunganmu.', 'Tekan ♥ pada tempat yang kamu suka dan temukan kembali kapan saja di daftar favoritmu.'],
];
$cards = [
    ['monas.jpeg', 'Monumen Nasional', 'Jakarta Pusat'],
    ['kota tua Jakarta.jpeg', 'Kota Tua', 'Jakarta Barat'],
    ['TMII.jpeg', 'Taman Mini Indonesia Indah', 'Jakarta Timur'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Selamat datang — Visura</title>
<link rel="icon" href="<?= $img ?>logo.png">
<style>
:root{--ink:#16212b;--muted:#5f6f7c;--line:#dde4ea;--accent:#0b6e8a;--accent-dark:#085469;--gold:#b8964f}
*{box-sizing:border-box}
html,body{min-height:100%}
body{margin:0;font:16px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--ink);background:#fff;overflow-x:hidden}
.wl{min-height:100vh;display:grid;grid-template-columns:1fr}

/* ===== Sisi visual: latar kota buram + tumpukan foto ===== */
.wl-left{position:relative;overflow:hidden;color:#fff;background:#0a1c27;display:flex;flex-direction:column;justify-content:space-between;
  padding:1.3rem 1.2rem 3.6rem;min-height:47vh;--cw:min(62vw,300px)}
.wl-left::before{content:"";position:absolute;inset:-30px;background:url('<?= $img ?>bundaran%20HI.jpeg') center/cover;filter:blur(9px) saturate(1.25);opacity:.6}
.wl-left::after{content:"";position:absolute;inset:0;
  background:radial-gradient(560px 380px at 75% 25%,rgba(27,154,184,.55),transparent 70%),
             radial-gradient(480px 340px at 15% 95%,rgba(184,150,79,.42),transparent 70%),
             linear-gradient(180deg,rgba(8,20,30,.5),rgba(8,20,30,.86))}
.wl-left>*{position:relative;z-index:1}
.wl-top{display:flex;align-items:center;gap:.7rem;justify-content:center}
.wl-top img{width:46px;height:46px;object-fit:contain;filter:drop-shadow(0 4px 10px rgba(0,0,0,.4))}
.wl-top strong{font-size:1.5rem;font-weight:800;letter-spacing:-.02em;line-height:1}
.wl-top span{display:none;font-size:.72rem;letter-spacing:.14em;text-transform:uppercase;color:var(--gold);font-weight:700;margin-top:.25rem}

.wl-stage{position:relative;width:calc(var(--cw) * 1.5);height:calc(var(--cw) * .95);margin:.6rem auto 0;max-width:100%}
.wl-card{position:absolute;left:50%;top:50%;width:var(--cw);margin:0;padding:7px;background:#fff;border-radius:20px;
  box-shadow:0 24px 50px rgba(0,0,0,.45);transition:transform .9s cubic-bezier(.22,.8,.25,1),opacity .9s,filter .9s}
.wl-card img{display:block;width:100%;aspect-ratio:3/2;object-fit:cover;border-radius:14px}
.wl-card figcaption{position:absolute;left:7px;right:7px;bottom:7px;padding:2.2rem .9rem .7rem;border-radius:0 0 14px 14px;
  background:linear-gradient(transparent,rgba(8,20,30,.85));font-weight:700;font-size:.95rem;line-height:1.25;transition:opacity .5s}
.wl-card figcaption small{display:block;font-weight:500;font-size:.78rem;opacity:.85}
.wl-card[data-pos="0"]{transform:translate(-50%,-50%) rotate(-2deg);z-index:3}
.wl-card[data-pos="1"]{transform:translate(-26%,-60%) rotate(6deg) scale(.9);z-index:2;filter:brightness(.8)}
.wl-card[data-pos="2"]{transform:translate(-74%,-66%) rotate(-8deg) scale(.82);z-index:1;filter:brightness(.62)}
.wl-card:not([data-pos="0"]) figcaption{opacity:0}
.wl-stage{animation:float 6s ease-in-out infinite}
@keyframes float{50%{transform:translateY(-10px)}}

.wl-feats{display:none;gap:.8rem}
.wl-feat{flex:1;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.22);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  border-radius:16px;padding:.95rem 1.1rem;transition:background .4s,border-color .4s,transform .4s,box-shadow .4s}
.wl-feat svg{width:26px;height:26px;fill:none;stroke:#fff;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round;margin-bottom:.55rem;opacity:.9;transition:stroke .4s}
.wl-feat strong{display:block;font-size:1rem;line-height:1.2}
.wl-feat span{display:block;font-size:.8rem;opacity:.8;margin-top:.15rem}
.wl-feat.on{background:rgba(184,150,79,.22);border-color:rgba(214,178,100,.85);transform:translateY(-4px);box-shadow:0 12px 26px rgba(0,0,0,.3)}
.wl-feat.on svg{stroke:#f0d493}

/* ===== Sisi onboarding ===== */
.wl-panel{position:relative;z-index:2;margin-top:-1.8rem;background:
    radial-gradient(380px 240px at 100% 0,rgba(11,110,138,.10),transparent 70%),
    radial-gradient(340px 240px at 0 100%,rgba(184,150,79,.14),transparent 70%),#fff;
  border-radius:28px 28px 0 0;box-shadow:0 -14px 34px rgba(8,20,30,.18);padding:1.9rem 1.5rem calc(2rem + env(safe-area-inset-bottom,0px));
  display:flex;flex-direction:column;justify-content:center}
.wl-in{width:100%;max-width:440px;margin:0 auto}
.wl-in>*{animation:up .75s cubic-bezier(.2,.7,.2,1) both}
.wl-in>*:nth-child(1){animation-delay:.05s}.wl-in>*:nth-child(2){animation-delay:.15s}.wl-in>*:nth-child(3){animation-delay:.25s}
.wl-in>*:nth-child(4){animation-delay:.35s}.wl-in>*:nth-child(5){animation-delay:.45s}.wl-in>*:nth-child(6){animation-delay:.55s}
@keyframes up{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}
.wl-hello{display:inline-flex;align-items:center;gap:.5rem;background:#eef6f9;color:var(--accent-dark);font-weight:700;font-size:.82rem;
  padding:.35rem .9rem;border-radius:999px;border:1px solid #cfe3ea}
.wl-hello i{width:8px;height:8px;border-radius:50%;background:var(--gold);box-shadow:0 0 0 4px rgba(184,150,79,.25)}
.wl-slides{display:grid;margin-top:1.1rem}
.wl-slide{grid-area:1/1;opacity:0;transform:translateX(22px);transition:opacity .5s,transform .5s;pointer-events:none}
.wl-slide.on{opacity:1;transform:none;pointer-events:auto}
.wl-slide h1{margin:0 0 .8rem;font-size:clamp(1.85rem,6.5vw,2.1rem);line-height:1.15;font-weight:800;letter-spacing:-.02em;
  background:linear-gradient(90deg,var(--accent-dark),var(--accent) 65%,#1b9ab8);-webkit-background-clip:text;background-clip:text;color:transparent}
.wl-slide p{margin:0;color:var(--muted);font-size:1rem;max-width:40ch}
.wl-dots{display:flex;gap:.45rem;margin:1.3rem 0 1.7rem}
.wl-dots button{position:relative;overflow:hidden;width:9px;height:9px;padding:0;border:0;border-radius:99px;background:#c5d2da;cursor:pointer;transition:width .35s}
.wl-dots button.on{width:44px}
.wl-dots button.on::after{content:"";position:absolute;inset:0;background:var(--accent);transform-origin:left;animation:fill 5s linear forwards}
@keyframes fill{from{transform:scaleX(0)}to{transform:scaleX(1)}}
.wl-btn{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;gap:.6rem;width:100%;text-align:center;text-decoration:none;
  font:inherit;font-weight:700;border-radius:18px;padding:1.05rem 1.2rem;transition:transform .18s,box-shadow .25s,border-color .2s,color .2s}
.wl-primary{background:linear-gradient(135deg,#0f86a8,var(--accent-dark));color:#fff;font-size:1.12rem;box-shadow:0 12px 26px rgba(11,110,138,.4)}
.wl-primary .arr{transition:transform .25s}
.wl-primary:hover{transform:translateY(-3px);box-shadow:0 18px 34px rgba(11,110,138,.5)}
.wl-primary:hover .arr{transform:translateX(5px)}
.wl-primary::after{content:"";position:absolute;top:0;bottom:0;width:60px;left:-90px;background:linear-gradient(100deg,transparent,rgba(255,255,255,.35),transparent);
  transform:skewX(-20deg);animation:shine 4.5s ease-in-out infinite 1.5s}
@keyframes shine{0%,60%{left:-90px}100%{left:120%}}
.wl-second{margin-top:.8rem;border:1.5px solid var(--line);background:#fff;color:var(--ink);font-weight:600;font-size:.98rem;padding:.9rem 1rem;border-radius:16px}
.wl-second:hover{border-color:var(--accent);color:var(--accent);transform:translateY(-2px)}
.wl-guest{display:block;text-align:center;margin-top:1.3rem;font-size:.92rem;color:var(--muted);text-decoration:none}
.wl-guest:hover{color:var(--accent);text-decoration:underline}

/* ===== Layar lebar ===== */
@media(min-width:900px){
  .wl{grid-template-columns:1.12fr 1fr}
  .wl-left{padding:2.4rem 3.2rem 2.6rem;min-height:100vh;--cw:min(31vw,470px)}
  .wl-top{justify-content:flex-start}
  .wl-top img{width:58px;height:58px}
  .wl-top strong{font-size:1.9rem}
  .wl-top div{display:flex;flex-direction:column}
  .wl-top span{display:block}
  .wl-stage{margin:0 auto}
  .wl-feats{display:flex}
  .wl-panel{margin:0;border-radius:0;box-shadow:none;padding:3rem 2.5rem}
  .wl-in{max-width:470px}
  .wl-slide h1{font-size:clamp(2.2rem,2.9vw,3.1rem)}
  .wl-slide p{font-size:1.08rem}
}
@media(max-height:700px) and (min-width:900px){.wl-feats{display:none}}
@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
</style>
</head>
<body>
<div class="wl">
    <aside class="wl-left" aria-hidden="true">
        <div class="wl-top">
            <img src="<?= $img ?>logo.png" alt="">
            <div><strong>Visura</strong><span>Informasi Wisata Lokal Jakarta</span></div>
        </div>
        <div class="wl-stage" id="stage">
            <?php foreach ($cards as $i => [$f, $name, $region]): ?>
            <figure class="wl-card" data-pos="<?= $i ?>">
                <img src="<?= $img . rawurlencode($f) ?>" alt="">
                <figcaption>📍 <?= e($name) ?><small><?= e($region) ?></small></figcaption>
            </figure>
            <?php endforeach; ?>
        </div>
        <div class="wl-feats">
            <div class="wl-feat on">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-6.2-7-11.2A7 7 0 0 1 19 9.8C19 14.8 12 21 12 21z"/><circle cx="12" cy="10" r="2.6"/></svg>
                <strong>Info lengkap</strong><span>Tiket, jam buka &amp; fasilitas</span>
            </div>
            <div class="wl-feat">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h3l1.6-2.4h6.8L17 8h3v11H4z"/><circle cx="12" cy="13.2" r="3.4"/></svg>
                <strong>Galeri pengunjung</strong><span>Foto &amp; video asli wisatawan</span>
            </div>
            <div class="wl-feat">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.5s-8-5-8-10.6A4.6 4.6 0 0 1 12 7a4.6 4.6 0 0 1 8 2.9c0 5.6-8 10.6-8 10.6z"/></svg>
                <strong>Favorit pribadi</strong><span>Simpan tempat pilihanmu</span>
            </div>
        </div>
    </aside>

    <main class="wl-panel">
        <div class="wl-in">
            <span class="wl-hello"><i></i> Selamat datang di Visura</span>
            <div class="wl-slides" id="slides">
                <?php foreach ($slides as $i => [$title, $text]): ?>
                <section class="wl-slide<?= $i === 0 ? ' on' : '' ?>">
                    <h1><?= $title ?></h1>
                    <p><?= e($text) ?></p>
                </section>
                <?php endforeach; ?>
            </div>
            <div class="wl-dots" id="dots">
                <?php foreach ($slides as $i => $s): ?><button type="button" class="<?= $i === 0 ? 'on' : '' ?>" aria-label="Slide <?= $i + 1 ?>"></button><?php endforeach; ?>
            </div>
            <a class="wl-btn wl-primary" href="<?= BASE_URL ?>/register.php">Mulai Sekarang <span class="arr">→</span></a>
            <a class="wl-btn wl-second" href="<?= BASE_URL ?>/login.php">Saya sudah punya akun</a>
            <a class="wl-guest" href="<?= BASE_URL ?>/?lihat=1">Lihat katalog dulu →</a>
        </div>
    </main>
</div>
<script>
(function(){
  var s=[].slice.call(document.querySelectorAll('.wl-slide')),
      d=[].slice.call(document.querySelectorAll('#dots button')),
      c=[].slice.call(document.querySelectorAll('.wl-card')),
      f=[].slice.call(document.querySelectorAll('.wl-feat')), n=s.length, i=0, t;
  function go(k){
    i=(k+n)%n;
    s.forEach(function(el,x){el.classList.toggle('on',x===i)});
    d.forEach(function(el,x){el.classList.toggle('on',x===i)});
    c.forEach(function(el,x){el.setAttribute('data-pos',(x-i+n)%n)});
    f.forEach(function(el,x){el.classList.toggle('on',x===i)});
  }
  function auto(){clearInterval(t);t=setInterval(function(){go(i+1)},5000)}
  d.forEach(function(b,k){b.addEventListener('click',function(){go(k);auto()})});
  c.forEach(function(el,x){el.addEventListener('click',function(){go(x);auto()})});
  var x0=null,box=document.querySelector('.wl-panel');
  box.addEventListener('touchstart',function(e){x0=e.touches[0].clientX},{passive:true});
  box.addEventListener('touchend',function(e){if(x0===null)return;var dx=e.changedTouches[0].clientX-x0;if(Math.abs(dx)>50){go(i+(dx<0?1:-1));auto()}x0=null});
  auto();
})();
</script>
</body>
</html>