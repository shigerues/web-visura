<?php
require_once __DIR__ . '/includes/functions.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = substr(strtolower(trim($_POST['username'] ?? '')), 0, 30);

    // [BARU] cek apakah sedang diblokir karena terlalu banyak percobaan gagal
    $wait = throttle_wait($pdo, 'login', $username);
    if ($wait > 0) {
        $err = 'Terlalu banyak percobaan gagal. Coba lagi dalam ' . (int)ceil($wait / 60) . ' menit.';
    } else {
        $st = $pdo->prepare('SELECT * FROM users WHERE username = ?');
        $st->execute([$username]);
        $u = $st->fetch();
        if ($u && password_verify($_POST['password'] ?? '', $u['password_hash'])) {
            throttle_clear($pdo, 'login', $username);   // [BARU] berhasil -> catatan gagal dihapus
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => (int)$u['id'], 'name' => $u['name'], 'role' => $u['role']];
            flash_set('success', greeting() . ', ' . $u['name'] . '! Senang melihatmu kembali.');
            $next = $_GET['next'] ?? '';
            header('Location: ' . (preg_match('#^/(?!/)#', $next) ? $next : BASE_URL . '/')); exit;
        }
        $left = throttle_fail($pdo, 'login', $username);   // [BARU] catat kegagalan
        $err = $left === 0
            ? 'Terlalu banyak percobaan gagal. Coba lagi dalam ' . (int)(THROTTLE_WINDOW / 60) . ' menit.'
            : 'Username atau kata sandi salah.' . ($left <= 3 ? " Sisa percobaan: $left." : '');
    }
}
$pageTitle = 'Masuk';
include __DIR__ . '/includes/header.php';
?>
<section class="auth">
    <div class="auth-side">
        <h2>Jelajahi Jakarta bersama Visura</h2>
        <p>Temukan tempat wisata, lihat foto dari pengunjung, dan bagikan ceritamu.</p>
        <ul class="auth-points">
            <li>Katalog wisata lengkap dengan harga dan jam buka</li>
            <li>Galeri foto dari pengunjung asli</li>
            <li>Ulasan dan rating setiap tempat</li>
        </ul>
    </div>
    <form class="auth-form" method="post">
        <p class="hello"><?= greeting() ?>, Sobat Visura</p>
        <h1>Masuk ke akunmu</h1>
        <p class="sub">Lanjutkan petualanganmu menjelajahi Jakarta.</p>
        <?php if ($err): ?><div class="alert error"><?= e($err) ?></div><?php endif; ?>
        <?= csrf_field() ?>
        <label>Username <input name="username" required autocomplete="username" autofocus></label>
        <label>Kata sandi <input type="password" name="password" required autocomplete="current-password"></label>
        <p class="forgot"><a href="<?= BASE_URL ?>/forgot_password.php">Lupa kata sandi?</a></p>   <!-- [BARU] -->
        <label class="check">
            <input type="checkbox" onchange="this.form.password.type = this.checked ? 'text' : 'password'">
            Tampilkan kata sandi
        </label>
        <button class="btn" type="submit">Masuk</button>
        <p class="alt">Belum punya akun? <a href="<?= BASE_URL ?>/register.php">Daftar sekarang</a></p>
    </form>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
