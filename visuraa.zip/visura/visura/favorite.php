<?php
// POST: tambah/hapus favorit (dipanggil via JS, mengembalikan JSON)
require_once __DIR__ . '/includes/functions.php';
header('Content-Type: application/json; charset=utf-8');

if (!current_user()) { http_response_code(401); echo json_encode(['error' => 'login']); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error' => 'method']); exit; }
csrf_check();

$uid = (int)current_user()['id'];
$did = (int)($_POST['destination_id'] ?? 0);
$ex = $pdo->prepare('SELECT 1 FROM destinations WHERE id = ?'); $ex->execute([$did]);
if (!$ex->fetchColumn()) { http_response_code(404); echo json_encode(['error' => 'notfound']); exit; }

// Toggle: kalau sudah ada -> hapus, kalau belum -> tambah
$del = $pdo->prepare('DELETE FROM favorites WHERE user_id = ? AND destination_id = ?');
$del->execute([$uid, $did]);
if ($del->rowCount() > 0) {
    $fav = false;
} else {
    $pdo->prepare('INSERT INTO favorites (user_id, destination_id) VALUES (?, ?)')->execute([$uid, $did]);
    $fav = true;
}
echo json_encode(['fav' => $fav]);
