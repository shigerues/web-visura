<?php
require_once __DIR__ . '/includes/functions.php';

$st = $pdo->prepare('SELECT d.*, c.name AS category FROM destinations d JOIN categories c ON c.id = d.category_id WHERE d.slug = ?');
$st->execute([$_GET['slug'] ?? '']);
$d = $st->fetch();
if (!$d) show_404();

$me = current_user();
$isAdmin = $me && $me['role'] === 'admin';

$photos = $pdo->prepare('SELECT m.*, u.name AS uploader FROM media m JOIN users u ON u.id = m.user_id WHERE m.destination_id = ? ORDER BY m.id DESC');
$photos->execute([$d['id']]); $photos = $photos->fetchAll();

$rev = $pdo->prepare('SELECT r.*, u.name FROM reviews r JOIN users u ON u.id = r.user_id WHERE r.destination_id = ? ORDER BY r.id DESC');
$rev->execute([$d['id']]); $reviews = $rev->fetchAll();
$avg = $reviews ? round(array_sum(array_column($reviews, 'rating')) / count($reviews), 1) : null;

// [BARU] foto utama = foto sampul (jika ada), kalau tidak foto terbaru
$hero = $photos[0] ?? null;
foreach ($photos as $p) { if ((int)$p['id'] === (int)$d['cover_media_id']) { $hero = $p; break; } }

// [BARU] status favorit
$isFav = false;
if ($me) {
    $f = $pdo->prepare('SELECT 1 FROM favorites WHERE user_id = ? AND destination_id = ?');
    $f->execute([$me['id'], $d['id']]);
    $isFav = (bool)$f->fetchColumn();
}

$pageTitle = $d['name'];
include __DIR__ . '/includes/header.php';
?>
<a class="back" href="<?= BASE_URL ?>/">← Kembali ke katalog</a>
<section class="detail">
    <div class="detail-media">
        <?php if ($hero && ($hero['kind'] ?? 'photo') === 'video'): render_media($hero, $d['name']); ?>
        <?php elseif ($hero): ?>
            <img src="<?= BASE_URL ?>/uploads/<?= e($hero['file_path']) ?>" alt="<?= e($d['name']) ?>" data-full="<?= BASE_URL ?>/uploads/<?= e($hero['file_path']) ?>" class="zoom">
        <?php else: ?><div class="ph big">Belum ada foto. Jadilah yang pertama mengunggah.</div><?php endif; ?>
    </div>
    <div class="detail-info">
        <span class="badge static"><?= e($d['category']) ?></span>
        <h1><?= e($d['name']) ?></h1>
        <p class="muted"><?= $avg ? '★ ' . $avg . ' (' . count($reviews) . ' ulasan)' : 'Belum ada ulasan' ?> · <?= e($d['region']) ?></p>
        <?php if ($me): ?>   <!-- [BARU] tombol favorit -->
            <button type="button" class="fav-btn inline<?= $isFav ? ' on' : '' ?>" data-id="<?= (int)$d['id'] ?>" aria-pressed="<?= $isFav ? 'true' : 'false' ?>">♥ Favorit</button>
        <?php else: ?>
            <a class="fav-btn inline" href="<?= BASE_URL ?>/login.php?next=<?= urlencode($_SERVER['REQUEST_URI']) ?>">♥ Favorit</a>
        <?php endif; ?>
        <dl class="facts">
            <dt>Alamat</dt><dd><?= e($d['address']) ?> — <a target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=<?= urlencode($d['name'] . ' ' . $d['address']) ?>">Buka di peta</a></dd>
            <dt>Jam buka</dt><dd><?= e($d['open_hours']) ?></dd>
            <dt>Harga tiket</dt><dd><?= rupiah((int)$d['ticket_price']) ?></dd>
            <dt>Fasilitas</dt><dd><?= e($d['facilities']) ?: '-' ?></dd>
        </dl>
        <p><?= nl2br(e($d['description'])) ?></p>
    </div>
</section>

<!-- [BARU] peta lokasi -->
<section>
    <h2 class="sec-title">Lokasi</h2>
    <iframe class="map" loading="lazy" title="Peta lokasi <?= e($d['name']) ?>"
            src="https://maps.google.com/maps?q=<?= urlencode($d['name'] . ' ' . $d['address']) ?>&amp;hl=id&amp;output=embed"></iframe>
</section>

<section>
    <h2 class="sec-title">Galeri pengunjung <span class="muted">(<?= count($photos) ?>)</span></h2>
    <?php if ($photos): ?>
    <div class="masonry">
        <?php foreach ($photos as $m):
            $owner   = $me && (int)$me['id'] === (int)$m['user_id'];
            $isCover = (int)$m['id'] === (int)$d['cover_media_id']; ?>
        <figure>
            <?php render_media($m, $m['caption'] ?: $d['name']); ?>
            <?php if ($isCover): ?><span class="cover-tag">Sampul</span><?php endif; ?>
            <figcaption><?= e($m['caption']) ?><small><?= e($m['uploader']) ?> · <?= date('d M Y', strtotime($m['visited_at'])) ?></small>
                <?php if ($me): ?>
                <div class="photo-actions">
                    <?php if ($isAdmin): ?>   <!-- [BARU] admin: pilih sampul -->
                        <form method="post" action="<?= BASE_URL ?>/set_cover.php">
                            <?= csrf_field() ?>
                            <input type="hidden" name="media_id" value="<?= (int)$m['id'] ?>">
                            <button class="link-act" type="submit"><?= $isCover ? 'Lepas sampul' : 'Jadikan sampul' ?></button>
                        </form>
                    <?php endif; ?>
                    <?php if ($owner || $isAdmin): ?>
                        <form method="post" action="<?= BASE_URL ?>/delete_photo.php" onsubmit="return confirm('Hapus media ini?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                            <button class="link-danger" type="submit">Hapus</button>
                        </form>
                    <?php else: ?>   <!-- [BARU] pengguna lain: laporkan -->
                        <details class="report">
                            <summary>Laporkan</summary>
                            <form method="post" action="<?= BASE_URL ?>/report.php">
                                <?= csrf_field() ?>
                                <input type="hidden" name="media_id" value="<?= (int)$m['id'] ?>">
                                <select name="reason" aria-label="Alasan laporan">
                                    <?php foreach (REPORT_REASONS as $r): ?><option><?= e($r) ?></option><?php endforeach; ?>
                                </select>
                                <button class="link-danger" type="submit">Kirim laporan</button>
                            </form>
                        </details>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </figcaption>
        </figure>
        <?php endforeach; ?>
    </div>
    <?php else: ?><p class="empty">Belum ada foto dari pengunjung.</p><?php endif; ?>
    <?php render_upload_form($pdo, (int)$d['id']); render_video_form($pdo, (int)$d['id']); ?>
</section>

<section>
    <h2 class="sec-title">Ulasan</h2>
    <?php if ($me): ?>
    <form class="form box" action="<?= BASE_URL ?>/review.php" method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="destination_id" value="<?= $d['id'] ?>">
        <label>Rating
            <select name="rating"><?php for ($i = 5; $i >= 1; $i--) echo "<option value=\"$i\">$i bintang</option>"; ?></select>
        </label>
        <label>Komentar <input type="text" name="comment" maxlength="500"></label>
        <button class="btn" type="submit">Kirim ulasan</button>
    </form>
    <?php endif; ?>
    <?php foreach ($reviews as $r): ?>
        <div class="review"><strong><?= e($r['name']) ?></strong> · ★ <?= (int)$r['rating'] ?><p><?= e($r['comment']) ?></p></div>
    <?php endforeach; ?>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>