<?php
require_once __DIR__ . '/includes/functions.php';
$mine = isset($_GET['mine']);
if ($mine) require_login();
$me      = current_user();
$isAdmin = $me && $me['role'] === 'admin';

$page = max(1, (int)($_GET['page'] ?? 1)); $perPage = 24;

// Ruang lingkup: "Foto saya" = milik sendiri; galeri publik hanya berisi kiriman wisatawan (akun admin tidak ikut)
$scope = $mine ? 'm.user_id = ' . (int)$me['id'] : "u.role = 'user'";
$base  = 'FROM media m JOIN users u ON u.id = m.user_id JOIN destinations d ON d.id = m.destination_id';

// Ringkasan untuk hero
$stat = $pdo->query("SELECT COUNT(*) AS total, COALESCE(SUM(m.kind = 'video'), 0) AS videos,
                            COUNT(DISTINCT m.user_id) AS people, COUNT(DISTINCT m.destination_id) AS places
                     $base WHERE $scope")->fetch();

// Chip filter per tempat wisata
$dests = $pdo->query("SELECT d.slug, d.name, COUNT(*) AS n $base WHERE $scope
                      GROUP BY d.id, d.slug, d.name ORDER BY n DESC, d.name ASC")->fetchAll();

// Filter dari URL (divalidasi)
$slug = $_GET['dest'] ?? '';
if (!in_array($slug, array_column($dests, 'slug'), true)) $slug = '';
$kind = in_array($_GET['kind'] ?? '', ['photo', 'video'], true) ? $_GET['kind'] : '';

$where = $scope; $p = [];
if ($slug !== '') { $where .= ' AND d.slug = :slug'; $p[':slug'] = $slug; }
if ($kind !== '') { $where .= ' AND m.kind = :kind'; $p[':kind'] = $kind; }

$st = $pdo->prepare("SELECT COUNT(*) $base WHERE $where"); $st->execute($p);
$total  = (int)$st->fetchColumn();
$offset = ($page - 1) * $perPage;
$st = $pdo->prepare("SELECT m.*, u.name AS uploader, u.username, d.name AS dest, d.slug $base
                     WHERE $where ORDER BY m.id DESC LIMIT $perPage OFFSET $offset");
$st->execute($p);
$rows = $st->fetchAll();

// Admin: jumlah laporan terbuka + penanda foto yang dilaporkan
$isMod = $isAdmin && !$mine;
$flags = []; $openReports = 0;
if ($isMod) {
    try {
        $openReports = (int)$pdo->query("SELECT COUNT(DISTINCT media_id) FROM reports WHERE status = 'open'")->fetchColumn();
        if ($rows) {
            $ids = implode(',', array_map('intval', array_column($rows, 'id')));
            foreach ($pdo->query("SELECT media_id, COUNT(*) AS n FROM reports WHERE status = 'open' AND media_id IN ($ids) GROUP BY media_id") as $r) $flags[(int)$r['media_id']] = (int)$r['n'];
        }
    } catch (PDOException $e) { /* tabel laporan belum ada: abaikan */ }
}

// Pembuat tautan filter (mempertahankan mode "Foto saya")
$url = function (array $over) use ($mine, $slug, $kind): string {
    $q = array_filter(array_merge(['mine' => $mine ? 1 : null, 'dest' => $slug, 'kind' => $kind], $over),
                      fn($v) => $v !== null && $v !== '');
    return BASE_URL . '/gallery.php' . ($q ? '?' . http_build_query($q) : '');
};

$pageTitle = $mine ? 'Foto saya' : 'Galeri Pengunjung';
include __DIR__ . '/includes/header.php';
?>
<?php if ($isMod): ?>
<section class="gal-hero admin-hero ah-split">
    <div class="ah-main">
        <p class="eyebrow">Panel moderasi</p>
        <h1>Moderasi galeri</h1>
        <p class="lead">Tinjau kiriman wisatawan dan hapus konten yang tidak pantas. Foto admin tidak ditampilkan di sini.</p>
        <div class="hero-actions">
            <a class="btn gold" href="<?= BASE_URL ?>/admin/reports.php">Tinjau laporan<?= $openReports ? ' (' . $openReports . ')' : '' ?></a>
            <a class="btn light" href="<?= BASE_URL ?>/admin/">Kelola tempat wisata</a>
        </div>
    </div>
    <div class="ah-stats">
        <div><strong><?= (int)$stat['total'] - (int)$stat['videos'] ?></strong><span>foto</span></div>
        <div><strong><?= (int)$stat['videos'] ?></strong><span>video</span></div>
        <div><strong><?= (int)$stat['people'] ?></strong><span>kontributor</span></div>
        <div class="<?= $openReports ? 'warn' : '' ?>"><strong><?= $openReports ?></strong><span>laporan terbuka</span></div>
    </div>
</section>
<?php else: ?>
<section class="gal-hero">
    <p class="eyebrow"><?= $mine ? 'Koleksi pribadi' : 'Dari mata para wisatawan' ?></p>
    <h1><?= $mine ? 'Foto & video kunjungan saya' : 'Galeri pengunjung' ?></h1>
    <p class="lead"><?= $mine
        ? 'Semua momen yang sudah kamu bagikan dari tempat-tempat wisata Jakarta.'
        : 'Potret dan video asli dari wisatawan yang sudah berkunjung ke tempat-tempat wisata Jakarta.' ?></p>
    <div class="gal-stats">
        <div><strong><?= (int)$stat['total'] - (int)$stat['videos'] ?></strong><span>foto</span></div>
        <div><strong><?= (int)$stat['videos'] ?></strong><span>video</span></div>
        <?php if (!$mine): ?><div><strong><?= (int)$stat['people'] ?></strong><span>kontributor</span></div><?php endif; ?>
        <div><strong><?= (int)$stat['places'] ?></strong><span>tempat wisata</span></div>
    </div>
    <div class="hero-actions">
        <?php if ($me): ?>
            <a class="btn gold" href="#unggah">＋ Bagikan fotomu</a>
            <?php if (!$mine): ?><a class="btn light" href="<?= BASE_URL ?>/gallery.php?mine=1">Foto saya</a>
            <?php else: ?><a class="btn light" href="<?= BASE_URL ?>/gallery.php">Lihat galeri semua</a><?php endif; ?>
        <?php else: ?>
            <a class="btn gold" href="<?= BASE_URL ?>/login.php?next=<?= urlencode('/gallery.php') ?>">Masuk untuk berbagi foto</a>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<?php if ($dests): ?>
<div class="gal-bar">
    <div class="chips" role="navigation" aria-label="Filter tempat wisata">
        <a class="chip<?= $slug === '' ? ' on' : '' ?>" href="<?= e($url(['dest' => null, 'page' => null])) ?>">Semua <small><?= (int)$stat['total'] ?></small></a>
        <?php foreach ($dests as $dd): ?>
            <a class="chip<?= $slug === $dd['slug'] ? ' on' : '' ?>" href="<?= e($url(['dest' => $dd['slug'], 'page' => null])) ?>"><?= e($dd['name']) ?> <small><?= (int)$dd['n'] ?></small></a>
        <?php endforeach; ?>
    </div>
    <div class="seg" role="navigation" aria-label="Jenis media">
        <a class="<?= $kind === '' ? 'on' : '' ?>" href="<?= e($url(['kind' => null, 'page' => null])) ?>">Semua</a>
        <a class="<?= $kind === 'photo' ? 'on' : '' ?>" href="<?= e($url(['kind' => 'photo', 'page' => null])) ?>">Foto</a>
        <a class="<?= $kind === 'video' ? 'on' : '' ?>" href="<?= e($url(['kind' => 'video', 'page' => null])) ?>">Video</a>
    </div>
</div>
<?php endif; ?>

<?php if ($rows): ?>
<div class="gal">
    <?php foreach ($rows as $m):
        $isVideo = ($m['kind'] ?? 'photo') === 'video';
        $isOwn   = $me && (int)$me['id'] === (int)$m['user_id'];
        $canDel  = $isOwn || $isAdmin;
        $nFlag   = $flags[(int)$m['id']] ?? 0; ?>
    <figure class="gal-item<?= $isMod ? ' admin' : '' ?><?= $nFlag ? ' flagged' : '' ?>">
        <div class="gal-media">
            <?php render_media($m, $m['caption'] ?: $m['dest']); ?>
            <?php if ($nFlag): ?><span class="gal-flag">⚠ Dilaporkan <?= $nFlag ?>×</span>
            <?php elseif ($isVideo): ?><span class="gal-badge">▶ Video</span>
            <?php elseif ($isOwn && !$mine): ?><span class="gal-badge mine">Fotomu</span><?php endif; ?>
            <?php if ($canDel && !$isMod): ?>
                <form class="gal-del" method="post" action="<?= BASE_URL ?>/delete_photo.php" onsubmit="return confirm('Hapus media ini?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                    <button type="submit" aria-label="Hapus media ini">🗑 Hapus</button>
                </form>
            <?php endif; ?>
        </div>
        <figcaption class="gal-cap">
            <a class="gal-dest" href="<?= BASE_URL ?>/detail.php?slug=<?= e($m['slug']) ?>">📍 <?= e($m['dest']) ?></a>
            <?php if ($m['caption']): ?><p class="gal-text"><?= e($m['caption']) ?></p><?php endif; ?>
            <div class="gal-meta">
                <?= render_avatar((int)$m['user_id'], $m['uploader']) ?>
                <span class="who"><?= e($m['uploader']) ?></span>
                <time datetime="<?= e($m['visited_at']) ?>"><?= e(tgl_id($m['visited_at'])) ?></time>
            </div>
            <?php if ($isMod): ?>
            <div class="gal-adm">
                <span class="info">@<?= e($m['username']) ?> · <?= $isVideo ? 'Video' : 'Foto' ?> · <?= max(1, (int)round(((int)$m['file_size']) / 1024)) ?> KB</span>
                <form method="post" action="<?= BASE_URL ?>/delete_photo.php" onsubmit="return confirm('Hapus media ini?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                    <button class="adm-del" type="submit">Hapus</button>
                </form>
            </div>
            <?php endif; ?>
        </figcaption>
    </figure>
    <?php endforeach; ?>
</div>
<?php render_pager($total, $page, $perPage); else: ?>
<p class="empty"><?= ($slug !== '' || $kind !== '')
    ? 'Tidak ada media untuk filter ini. <a href="' . e($url(['dest' => null, 'kind' => null, 'page' => null])) . '">Tampilkan semua</a>.'
    : ($mine ? 'Belum ada foto. Unggah foto pertamamu di bawah.' : 'Belum ada foto dari pengunjung. Jadilah yang pertama membagikan kunjunganmu di bawah.') ?></p>
<?php endif;
echo '<div id="unggah">';
render_upload_form($pdo);
render_video_form($pdo);
echo '</div>';
include __DIR__ . '/includes/footer.php'; ?>