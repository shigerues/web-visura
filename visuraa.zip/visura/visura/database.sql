CREATE DATABASE IF NOT EXISTS visura CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE visura;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE destinations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT NOT NULL,
  name VARCHAR(150) NOT NULL,
  slug VARCHAR(160) NOT NULL UNIQUE,
  region VARCHAR(40) NOT NULL,
  address VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  open_hours VARCHAR(100) NOT NULL,
  ticket_price INT NOT NULL DEFAULT 0,         -- 0 = gratis
  facilities VARCHAR(255) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id),
  INDEX (region)
);

CREATE TABLE media (                              -- galeri foto kunjungan pengguna
  id INT AUTO_INCREMENT PRIMARY KEY,
  destination_id INT NOT NULL,
  user_id INT NOT NULL,
  file_path VARCHAR(120) NOT NULL,
  thumb_path VARCHAR(120) NOT NULL,
  caption VARCHAR(200) DEFAULT '',
  width INT, height INT,
  original_size INT NOT NULL,                    -- ukuran sebelum kompresi (byte)
  file_size INT NOT NULL,                        -- ukuran sesudah kompresi (byte)
  sha256 CHAR(64) NOT NULL UNIQUE,               -- integritas + deteksi duplikat
  visited_at DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  destination_id INT NOT NULL,
  user_id INT NOT NULL,
  rating TINYINT NOT NULL,
  comment VARCHAR(500) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (destination_id, user_id),
  FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Akun admin awal: admin@visura.test / admin123 (WAJIB diganti)
INSERT INTO users (name, email, password_hash, role) VALUES
('Admin Visura', 'admin@visura.test', '$2y$10$nW8mF7F/lsS2EQhB4/HVKOx/w6QWtOZmY0hI4O5HLWFxj5AVjbglu', 'admin');

INSERT INTO categories (name) VALUES
('Museum'), ('Taman & Alam'), ('Sejarah & Budaya'), ('Kuliner'), ('Seni');

-- Data contoh. Harga & jam buka PERLU diverifikasi ulang sebelum dipakai.
INSERT INTO destinations (category_id, name, slug, region, address, description, open_hours, ticket_price, facilities) VALUES
(1,'Museum Nasional Indonesia','museum-nasional','Jakarta Pusat','Jl. Medan Merdeka Barat No.12, Gambir','Museum terbesar di Indonesia dengan koleksi arkeologi, etnografi, dan keramik dari seluruh nusantara.','08:00–16:00 (Senin tutup)',10000,'Toilet, Musala, Kafe, Aksesibel kursi roda'),
(3,'Museum Fatahillah (Kota Tua)','museum-fatahillah','Jakarta Barat','Jl. Taman Fatahillah No.2, Pinangsia','Bekas balai kota Batavia yang kini menyimpan sejarah Jakarta, berhadapan dengan lapangan Kota Tua.','09:00–15:00 (Senin tutup)',5000,'Toilet, Musala, Penyewaan sepeda'),
(3,'Monumen Nasional (Monas)','monas','Jakarta Pusat','Jl. Medan Merdeka, Gambir','Tugu setinggi 132 meter dengan museum sejarah di dasar dan pelataran puncak untuk melihat kota.','08:00–16:00',15000,'Toilet, Musala, Taman, Area piknik'),
(2,'Taman Mini Indonesia Indah','tmii','Jakarta Timur','Jl. Raya Taman Mini, Ceger, Cipayung','Taman budaya dengan anjungan rumah adat 34 provinsi, museum, dan taman bermain keluarga.','08:00–17:00',20000,'Parkir luas, Toilet, Musala, Kuliner'),
(2,'Taman Margasatwa Ragunan','ragunan','Jakarta Selatan','Jl. Harsono RM No.1, Ragunan, Pasar Minggu','Kebun binatang dengan area hijau luas, cocok untuk wisata keluarga akhir pekan.','07:00–16:00',4000,'Parkir, Toilet, Musala, Penyewaan sepeda'),
(2,'Taman Impian Jaya Ancol','ancol','Jakarta Utara','Jl. Lodan Timur No.7, Pademangan','Kawasan wisata tepi pantai dengan taman rekreasi, pantai, dan area kuliner.','06:00–22:00',25000,'Parkir, Toilet, Musala, Restoran'),
(5,'Museum MACAN','museum-macan','Jakarta Barat','AKR Tower, Jl. Perjuangan No.1, Kebon Jeruk','Museum seni modern dan kontemporer dengan pameran bergilir dari seniman Indonesia dan internasional.','10:00–18:00 (Senin tutup)',100000,'Toilet, Kafe, Toko suvenir'),
(3,'Pelabuhan Sunda Kelapa','sunda-kelapa','Jakarta Utara','Jl. Maritim Raya, Penjaringan','Pelabuhan tua tempat kapal pinisi bersandar, salah satu titik awal kota Jakarta.','08:00–17:00',5000,'Toilet, Warung makan'),
(4,'Pasar Santa','pasar-santa','Jakarta Selatan','Jl. Cipaku I, Kebayoran Baru','Pasar tradisional yang kini jadi pusat kuliner dan kreator lokal anak muda.','10:00–22:00',0,'Toilet, Musala, Banyak pilihan kuliner');
