<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . '/'); exit; }
csrf_check();

$st = $pdo->prepare('SELECT m.*, d.slug FROM media m JOIN destinations d ON d.id = m.destination_id WHERE m.id = ?');
$st->execute([(int)($_POST['id'] ?? 0)]);
$m = $st->fetch();
$u = current_user();

if (!$m || ($m['user_id'] != $u['id'] && $u['role'] !== 'admin')) {
    flash_set('error', 'Foto tidak ditemukan atau bukan milik Anda.');
    header('Location: ' . BASE_URL . '/gallery.php'); exit;
}

// Hapus file di disk, lalu barisnya di database
@unlink(UPLOAD_DIR . '/' . $m['file_path']);
@unlink(UPLOAD_DIR . '/' . $m['thumb_path']);
$pdo->prepare('DELETE FROM media WHERE id = ?')->execute([$m['id']]);

flash_set('success', 'Foto dihapus.');
header('Location: ' . BASE_URL . '/detail.php?slug=' . urlencode($m['slug'])); exit;