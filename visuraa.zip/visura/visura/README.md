# Visura — Katalog Wisata Jakarta

Stack: PHP 8+ (ekstensi GD, fileinfo, pdo_mysql; exif disarankan), MySQL/MariaDB, HTML/CSS/JS.

## Cara menjalankan (XAMPP / Laragon)
1. Salin folder `visura` ke `htdocs` (XAMPP) atau `www` (Laragon).
2. Buka phpMyAdmin → Import `database.sql` (membuat database `visura` + data contoh).
3. Sesuaikan `config.php` (DB_USER, DB_PASS, BASE_URL).
4. Buka http://localhost/visura/
5. Admin: `admin@visura.test` / `admin123` → **ganti segera**.

## Fitur
- Katalog + pencarian langsung, filter kategori & wilayah, pagination
- Detail: alamat (tautan peta), jam buka, harga, fasilitas, ulasan & rating
- Galeri pengunjung + "Foto saya"
- Unggah foto: validasi MIME + magic bytes, maks 5 MB, resize bikubik, watermark,
  kompresi WebP, thumbnail, SHA-256 (tolak duplikat), baca EXIF
- Login/daftar (bcrypt, CSRF, session aman), panel admin
- REST API: `/api/destinations.php?q=&category=&region=&page=&per_page=`
