<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$id = (int)current_user()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $do = $_POST['do'] ?? '';

    if ($do === 'name') {
        $name = trim($_POST['name'] ?? '');
        if ($name === '' || mb_strlen($name) > 80) {
            flash_set('error', 'Nama wajib diisi (maksimal 80 karakter).');
        } else {
            $pdo->prepare('UPDATE users SET name = ? WHERE id = ?')->execute([$name, $id]);
            $_SESSION['user']['name'] = $name;
            flash_set('success', 'Profil diperbarui.');
        }
    } elseif ($do === 'password') {
        $old = $_POST['old'] ?? ''; $new = $_POST['new'] ?? ''; $confirm = $_POST['confirm'] ?? '';
        $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?'); $st->execute([$id]);
        if (!password_verify($old, (string)$st->fetchColumn())) {
            flash_set('error', 'Kata sandi lama salah.');
        } elseif (strlen($new) < 8) {
            flash_set('error', 'Kata sandi baru minimal 8 karakter.');
        } elseif ($new !== $confirm) {
            flash_set('error', 'Konfirmasi kata sandi tidak sama.');
        } else {
            $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_BCRYPT), $id]);
            session_regenerate_id(true);
            flash_set('success', 'Kata sandi berhasil diganti.');
        }
    } elseif ($do === 'reveal') {   // tampilkan kode tersimpan setelah konfirmasi kata sandi
        $st = $pdo->prepare('SELECT password_hash, recovery_enc FROM users WHERE id = ?'); $st->execute([$id]);
        $row = $st->fetch();
        if (!password_verify($_POST['pw'] ?? '', (string)($row['password_hash'] ?? ''))) {
            flash_set('error', 'Kata sandi salah, kode pemulihan tidak ditampilkan.');
        } elseif (($code = decrypt_code($row['recovery_enc'] ?? null)) === null) {
            flash_set('error', 'Kode tersimpan tidak bisa dibaca. Buat kode baru.');
        } else {
            $_SESSION['reveal_code'] = $code;   // tampil sekali pada halaman berikutnya
        }
    } elseif ($do === 'recovery') {   // perbarui kode pemulihan
        $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?'); $st->execute([$id]);
        if (!password_verify($_POST['pw'] ?? '', (string)$st->fetchColumn())) {
            flash_set('error', 'Kata sandi salah, kode pemulihan tidak dibuat.');
        } else {
            $_SESSION['popup_code'] = set_recovery_code($pdo, $id);   // ditampilkan sekali sebagai pop up
            header('Location: ' . BASE_URL . '/profile.php'); exit;
        }
    }
    header('Location: ' . BASE_URL . '/profile.php'); exit;
}

$st = $pdo->prepare('SELECT name, username, role, created_at, (recovery_hash IS NOT NULL) AS has_code, (recovery_enc IS NOT NULL) AS can_reveal FROM users WHERE id = ?'); $st->execute([$id]);
$prof = $st->fetch();
$cnt = $pdo->prepare('SELECT (SELECT COUNT(*) FROM media WHERE user_id = :a) AS photos,
                             (SELECT COUNT(*) FROM reviews WHERE user_id = :b) AS reviews,
                             (SELECT COUNT(*) FROM favorites WHERE user_id = :c) AS favs');
$cnt->execute([':a' => $id, ':b' => $id, ':c' => $id]);
$n = $cnt->fetch();

$revealCode = $_SESSION['reveal_code'] ?? null;
unset($_SESSION['reveal_code']);   // hanya tampil sekali per permintaan
$popupCode = $_SESSION['popup_code'] ?? null;
unset($_SESSION['popup_code']);   // hanya tampil sekali

$pageTitle = 'Profil';
include __DIR__ . '/includes/header.php';
?>
<section class="profile-head">
    <div class="avatar"><?= e(mb_strtoupper(mb_substr($prof['name'], 0, 1))) ?></div>
    <div>
        <p class="hello"><?= greeting() ?>,</p>
        <h1><?= e($prof['name']) ?></h1>
        <p class="muted">@<?= e($prof['username']) ?> · <?= $prof['role'] === 'admin' ? 'Admin' : 'Anggota' ?> · bergabung <?= date('d M Y', strtotime($prof['created_at'])) ?></p>
    </div>
    <div class="pstats">
        <a href="<?= BASE_URL ?>/gallery.php?mine=1"><strong><?= (int)$n['photos'] ?></strong><span>foto</span></a>
        <a href="<?= BASE_URL ?>/?fav=1"><strong><?= (int)$n['favs'] ?></strong><span>favorit</span></a>
        <div><strong><?= (int)$n['reviews'] ?></strong><span>ulasan</span></div>
    </div>
</section>

<div class="profile-grid">
    <form class="form box" method="post">
        <?= csrf_field() ?><input type="hidden" name="do" value="name">
        <h3>Ubah profil</h3>
        <label>Username <input value="<?= e($prof['username']) ?>" disabled></label>
        <label>Nama <input name="name" required maxlength="80" value="<?= e($prof['name']) ?>"></label>
        <button class="btn" type="submit">Simpan perubahan</button>
    </form>

    <form class="form box" method="post">
        <?= csrf_field() ?><input type="hidden" name="do" value="password">
        <h3>Ganti kata sandi</h3>
        <label>Kata sandi lama <input class="pw" type="password" name="old" required autocomplete="current-password"></label>
        <label>Kata sandi baru (min. 8 karakter) <input class="pw" type="password" name="new" required minlength="8" autocomplete="new-password"></label>
        <label>Ulangi kata sandi baru <input class="pw" type="password" name="confirm" required minlength="8" autocomplete="new-password"></label>
        <label class="check">
            <input type="checkbox" onchange="this.form.querySelectorAll('.pw').forEach(i => i.type = this.checked ? 'text' : 'password')">
            Tampilkan kata sandi
        </label>
        <button class="btn" type="submit">Ganti kata sandi</button>
    </form>

    <form class="form box wide" method="post">   <!-- kode pemulihan -->
        <?= csrf_field() ?>
        <h3>Kode pemulihan</h3>
        <?php if ($revealCode): ?>
            <p class="muted">Kode pemulihanmu:</p>
            <div id="rcInline" style="font-family:monospace;font-size:1.4rem;font-weight:700;letter-spacing:2px;background:#f3f6f8;border:2px dashed #0f6b82;border-radius:10px;padding:14px;margin:10px 0;user-select:all;word-break:break-all"><?= e($revealCode) ?></div>
            <p><button class="btn" type="button" onclick="var b=this;navigator.clipboard.writeText(document.getElementById('rcInline').textContent.trim()).then(function(){b.textContent='Tersalin ✓'})">Salin kode</button></p>
            <p class="muted">Simpan di tempat aman. Kode akan disembunyikan lagi saat halaman ini dibuka ulang.</p>
        <?php elseif ($prof['can_reveal']): ?>
            <p class="muted">Kode pemulihanmu tersimpan terenkripsi di akun ini. Masukkan kata sandimu untuk melihatnya kapan saja.</p>
        <?php elseif ($prof['has_code']): ?>
            <p class="muted">Kodemu dibuat sebelum fitur penyimpanan ada, jadi tidak bisa ditampilkan. Buat kode baru agar tersimpan dan bisa dilihat di sini.</p>
        <?php else: ?>
            <p class="muted">Akunmu belum punya kode pemulihan. Buat sekarang agar bisa mengatur ulang kata sandi jika lupa.</p>
        <?php endif; ?>
        <label>Masukkan kata sandimu untuk konfirmasi <input class="pw2" type="password" name="pw" required autocomplete="new-password"></label>
        <label class="check">
            <input type="checkbox" onchange="this.form.querySelector('.pw2').type = this.checked ? 'text' : 'password'">
            Tampilkan kata sandi
        </label>
        <?php if ($prof['can_reveal']): ?>
            <button class="btn" type="submit" name="do" value="reveal">Lihat kode pemulihan</button>
        <?php endif; ?>
        <button class="btn<?= $prof['can_reveal'] ? ' ghost' : '' ?>" type="submit" name="do" value="recovery"
                <?= $prof['has_code'] ? "onclick=\"return confirm('Kode lama akan tidak berlaku. Lanjutkan?')\"" : '' ?>><?= $prof['has_code'] ? 'Buat kode baru' : 'Buat kode pemulihan' ?></button>
    </form>
</div>
<?php if ($popupCode): ?>
<style>
    .rc-overlay { position: fixed; inset: 0; background: rgba(15, 30, 40, .6); display: flex; align-items: center; justify-content: center; padding: 16px; z-index: 1000; }
    .rc-modal { background: #fff; border-radius: 14px; max-width: 440px; width: 100%; padding: 28px; box-shadow: 0 20px 50px rgba(0,0,0,.3); text-align: center; }
    .rc-modal h2 { margin: 0 0 8px; }
    .rc-modal p { margin: 8px 0; color: #555; font-size: .95rem; }
    .rc-code { font-family: monospace; font-size: 1.5rem; font-weight: 700; letter-spacing: 2px; background: #f3f6f8; border: 2px dashed #0f6b82; border-radius: 10px; padding: 16px 8px; margin: 16px 0; user-select: all; word-break: break-all; }
    .rc-actions { display: flex; gap: 8px; justify-content: center; flex-wrap: wrap; margin-top: 16px; }
</style>
<div class="rc-overlay" id="rcOverlay" role="dialog" aria-modal="true" aria-labelledby="rcTitle">
    <div class="rc-modal">
        <h2 id="rcTitle">Simpan kode pemulihanmu</h2>
        <p>Kode ini dipakai untuk mengatur ulang kata sandi jika kamu lupa.</p>
        <div class="rc-code" id="rcCode"><?= e($popupCode) ?></div>
        <p><strong>Kode hanya tampil sekali.</strong> Catat di tempat aman. Kode berlaku satu kali pakai.</p>
        <div class="rc-actions">
            <button class="btn ghost" type="button" id="rcCopy">Salin kode</button>
            <button class="btn" type="button" id="rcClose">Saya sudah menyimpannya</button>
        </div>
    </div>
</div>
<script>
    document.getElementById('rcCopy').addEventListener('click', function () {
        var t = document.getElementById('rcCode').textContent.trim(), b = this;
        (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () {
            b.textContent = 'Tersalin ✓';
        }).catch(function () {
            var r = document.createRange(); r.selectNodeContents(document.getElementById('rcCode'));
            var sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
            b.textContent = 'Tekan Ctrl+C';
        });
    });
    document.getElementById('rcClose').addEventListener('click', function () {
        document.getElementById('rcOverlay').remove();
    });
</script>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>