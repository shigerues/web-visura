<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $uid = (int)($_POST['user_id'] ?? 0);
    $st = $pdo->prepare('SELECT id, username FROM users WHERE id = ?'); $st->execute([$uid]);
    $target = $st->fetch();
    if (!$target) {
        flash_set('error', 'Pengguna tidak ditemukan.');
    } elseif ($uid === (int)current_user()['id']) {
        flash_set('error', 'Ganti kata sandimu sendiri lewat halaman Profil.');
    } else {
        // Kata sandi sementara, tampil sekali di pesan. Pengguna diminta menggantinya lewat Profil.
        $alpha = 'abcdefghjkmnpqrstuvwxyz23456789'; $tmp = '';
        for ($i = 0; $i < 10; $i++) $tmp .= $alpha[random_int(0, strlen($alpha) - 1)];
        $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($tmp, PASSWORD_BCRYPT), $uid]);
        throttle_clear($pdo, 'login', $target['username']);
        flash_set('success', 'Kata sandi sementara untuk @' . $target['username'] . ': ' . $tmp . ' — sampaikan ke pengguna dan minta menggantinya lewat Profil.');
    }
    header('Location: ' . BASE_URL . '/admin/users.php'); exit;
}

$rows = $pdo->query('SELECT id, name, username, role, created_at, (recovery_hash IS NOT NULL) AS has_code
                     FROM users ORDER BY id DESC')->fetchAll();
$pageTitle = 'Pengguna';
include __DIR__ . '/../includes/header.php';
?>
<h1>Kelola</h1>
<?php admin_tabs($pdo, 'users'); ?>
<p class="muted">Untuk pengguna yang lupa kata sandi dan belum punya kode pemulihan. Kata sandi sementara hanya tampil sekali.</p>
<table class="table">
    <tr><th>Nama</th><th>Username</th><th>Peran</th><th>Kode pemulihan</th><th>Bergabung</th><th></th></tr>
    <?php foreach ($rows as $r): ?>
    <tr>
        <td><?= e($r['name']) ?></td>
        <td>@<?= e($r['username']) ?></td>
        <td><?= $r['role'] === 'admin' ? 'Admin' : 'Anggota' ?></td>
        <td><?= $r['has_code'] ? 'Ada' : 'Belum' ?></td>
        <td><?= date('d M Y', strtotime($r['created_at'])) ?></td>
        <td>
            <?php if ((int)$r['id'] !== (int)current_user()['id']): ?>
            <form method="post" onsubmit="return confirm('Buat kata sandi sementara untuk @<?= e($r['username']) ?>?')">
                <?= csrf_field() ?><input type="hidden" name="user_id" value="<?= (int)$r['id'] ?>">
                <button class="link-act" type="submit">Reset kata sandi</button>
            </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
