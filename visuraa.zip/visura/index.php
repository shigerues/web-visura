<?php
require_once __DIR__ . '/includes/functions.php';

// Pengunjung yang belum login & belum melihat sambutan -> arahkan ke halaman sambutan
if (isset($_GET['lihat'])) $_SESSION['seen_welcome'] = 1;
if (!current_user() && empty($_SESSION['seen_welcome']) && !isset($_GET['partial'])) {
    header('Location: ' . BASE_URL . '/welcome.php'); exit;
}

$favMode = isset($_GET['fav']);          // halaman Favorit: hanya tempat yang di-♥ pengguna
if ($favMode) require_login();

// Admin: Favorit menampilkan tempat yang disukai WISATAWAN beserta siapa saja yang menyukainya
if ($favMode && current_user()['role'] === 'admin' && !isset($_GET['partial'])) {
    include __DIR__ . '/includes/admin_favorites.php';
    exit;
}

$filters = ['q' => trim($_GET['q'] ?? ''), 'category' => (int)($_GET['category'] ?? 0), 'region' => $_GET['region'] ?? '', 'fav' => $favMode];
if (!in_array($filters['region'], REGIONS, true)) $filters['region'] = '';
$page = max(1, (int)($_GET['page'] ?? 1)); $perPage = 9;
[$rows, $total] = fetch_destinations($pdo, $filters, $page, $perPage);

// Mode partial: hanya kirim grid (dipakai pencarian langsung via JS)
if (isset($_GET['partial'])) {
    echo $rows ? '<div class="grid">' : '<p class="empty">Tidak ada tempat yang cocok. Ubah kata kunci atau filter.</p>';
    foreach ($rows as $d) render_card($d);
    echo $rows ? '</div>' : '';
    render_pager($total, $page, $perPage);
    exit;
}

// Tampilan khusus Favorit: tanpa hero, tanpa pencarian, tanpa foto terbaru
if ($favMode) {
    $pageTitle = 'Favorit saya';
    include __DIR__ . '/includes/header.php';
    ?>
    <section class="gal-hero fav-user">
        <p class="eyebrow">Koleksi pribadi</p>
        <h1>Favorit saya</h1>
        <p class="lead">Tempat-tempat yang kamu simpan untuk dikunjungi nanti. Tekan ♥ untuk melepasnya.</p>
        <div class="gal-stats"><div><strong><?= (int)$total ?></strong><span>tempat disimpan</span></div></div>
    </section>
    <?php if ($rows): ?>
        <div class="grid"><?php foreach ($rows as $d) render_card($d); ?></div>
        <?php render_pager($total, $page, $perPage); ?>
    <?php else: ?>
        <p class="empty">Belum ada tempat favorit. Tekan ♥ pada tempat wisata di katalog untuk menyimpannya di sini.</p>
        <p><a class="btn" href="<?= BASE_URL ?>/">Jelajahi katalog</a></p>
    <?php endif;
    include __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = 'Katalog Wisata Jakarta';
$cats = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();

// [BARU] angka ringkasan untuk hero
$stat = $pdo->query("SELECT (SELECT COUNT(*) FROM destinations) AS places,
                            (SELECT COUNT(*) FROM media m JOIN users u ON u.id = m.user_id WHERE u.role = 'user') AS photos,
                            (SELECT COUNT(DISTINCT region) FROM destinations) AS regions")->fetch();

// [UBAH] foto terbaru dari pengunjung (wisatawan saja)
$recent = $pdo->query("SELECT m.thumb_path, m.caption, d.name AS dest, d.slug
                       FROM media m
                       JOIN destinations d ON d.id = m.destination_id
                       JOIN users u ON u.id = m.user_id
                       WHERE u.role = 'user'
                       ORDER BY m.id DESC LIMIT 10")->fetchAll();

include __DIR__ . '/includes/header.php';
?>
<section class="hero hero-photo">
    <h1>Temukan tempat wisata Jakarta, lengkap dengan foto dari pengunjung.</h1>
    <p class="muted">Alamat, jam buka, dan harga tiket dalam satu halaman.</p>
    <!-- [BARU] angka ringkasan -->
    <div class="stats">
        <div><strong><?= (int)$stat['places'] ?></strong><span>tempat wisata</span></div>
        <div><strong><?= (int)$stat['photos'] ?></strong><span>foto pengunjung</span></div>
        <div><strong><?= (int)$stat['regions'] ?></strong><span>wilayah Jakarta</span></div>
    </div>
</section>

<form class="filters" id="filters" method="get">
    <input type="search" name="q" placeholder="Cari museum, taman, kuliner…" value="<?= e($filters['q']) ?>">
    <select name="category">
        <option value="0">Semua kategori</option>
        <?php foreach ($cats as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $filters['category'] == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="region">
        <option value="">Semua wilayah</option>
        <?php foreach (REGIONS as $r): ?>
            <option <?= $filters['region'] === $r ? 'selected' : '' ?>><?= e($r) ?></option>
        <?php endforeach; ?>
    </select>
    <button class="btn" type="submit">Cari</button>
</form>

<h2 class="sec-title">Tempat wisata</h2>   <!-- [BARU] -->
<div id="catalog">
    <?php if ($rows): ?><div class="grid"><?php foreach ($rows as $d) render_card($d); ?></div>
    <?php else: ?><p class="empty">Tidak ada tempat yang cocok. Ubah kata kunci atau filter.</p><?php endif; ?>
    <?php render_pager($total, $page, $perPage); ?>
</div>

<?php if ($recent): ?>
<section class="strip">
    <h2 class="sec-title">Foto terbaru dari pengunjung <a class="sec-more" href="<?= BASE_URL ?>/gallery.php">Lihat semua →</a></h2>
    <div class="strip-row">
        <?php foreach ($recent as $r): ?>
        <a class="strip-item" href="<?= BASE_URL ?>/detail.php?slug=<?= e($r['slug']) ?>">
            <img src="<?= BASE_URL ?>/uploads/<?= e($r['thumb_path']) ?>" alt="<?= e($r['caption'] ?: $r['dest']) ?>" loading="lazy">
            <span><?= e($r['dest']) ?></span>
        </a>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>