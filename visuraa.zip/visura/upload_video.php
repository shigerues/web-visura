<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
if (current_user()['role'] === 'admin') { flash_set('error', 'Akun admin tidak dipakai untuk mengunggah. Admin hanya memantau kiriman pengunjung.'); header('Location: ' . BASE_URL . '/gallery.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ' . BASE_URL . '/'); exit; }
csrf_check();
set_time_limit(600);   // kompresi video bisa memakan waktu

$st = $pdo->prepare('SELECT id, slug FROM destinations WHERE id = ?');
$st->execute([(int)($_POST['destination_id'] ?? 0)]);
$dest = $st->fetch();
if (!$dest) { flash_set('error', 'Tempat wisata tidak valid.'); header('Location: ' . BASE_URL . '/gallery.php'); exit; }
$back = BASE_URL . '/detail.php?slug=' . urlencode($dest['slug']);

try {
    $r = save_video($_FILES['video'] ?? []);

    // Tolak duplikat berdasarkan hash SHA-256 file asli
    $dup = $pdo->prepare('SELECT 1 FROM media WHERE sha256 = ?'); $dup->execute([$r['sha']]);
    if ($dup->fetchColumn()) {
        @unlink(UPLOAD_DIR . '/' . $r['file']); @unlink(UPLOAD_DIR . '/' . $r['thumb']);
        throw new RuntimeException('Video ini sudah pernah diunggah.');
    }

    $visited = $_POST['visited_at'] ?? '';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $visited) || $visited > date('Y-m-d')) $visited = date('Y-m-d');

    $pdo->prepare('INSERT INTO media (destination_id, user_id, kind, file_path, thumb_path, caption, width, height, duration, original_size, file_size, sha256, visited_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$dest['id'], current_user()['id'], 'video', $r['file'], $r['thumb'], mb_substr(trim($_POST['caption'] ?? ''), 0, 200),
                   $r['w'], $r['h'], $r['duration'], $r['original_size'], $r['file_size'], $r['sha'], $visited]);

    $saved = max(0, round((1 - $r['file_size'] / $r['original_size']) * 100));
    $mb = fn(int $b) => number_format($b / 1048576, 1, ',', '.');
    flash_set('success', "Video berhasil diunggah. Ukuran berkurang {$saved}% ({$mb($r['original_size'])} MB → {$mb($r['file_size'])} MB).");
} catch (RuntimeException $ex) {
    flash_set('error', $ex->getMessage());
}
header('Location: ' . $back); exit;