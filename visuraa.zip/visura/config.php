<?php
// ====== Konfigurasi Visura ======
define('DB_HOST', 'localhost');
define('DB_NAME', 'visura');
define('DB_USER', 'root');      // ganti sesuai MySQL Anda
define('DB_PASS', '');
define('BASE_URL', '/visura');  // folder proyek di htdocs; kosongkan '' jika di root
define('UPLOAD_DIR', __DIR__ . '/uploads');
define('MAX_UPLOAD', 5 * 1024 * 1024); // batas 5 MB

// Video (FFmpeg). Hapus tanda // di bawah dan sesuaikan path jika FFmpeg tidak ada di PATH Windows.
// define('FFMPEG_PATH',  'C:/ffmpeg/bin/ffmpeg.exe');
// define('FFPROBE_PATH', 'C:/ffmpeg/bin/ffprobe.exe');

const REGIONS = ['Jakarta Pusat', 'Jakarta Utara', 'Jakarta Barat', 'Jakarta Selatan', 'Jakarta Timur'];

// Cookie sesi: flag "secure" otomatis aktif hanya kalau diakses lewat HTTPS
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? '') == 443;
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => $https]);
session_start();

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Koneksi database gagal. Periksa config.php.');
}