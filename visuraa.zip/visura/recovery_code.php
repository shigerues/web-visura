<?php
// Menampilkan kode pemulihan SATU KALI (setelah daftar, buat kode baru, atau reset kata sandi)
require_once __DIR__ . '/includes/functions.php';
$sc = $_SESSION['show_code'] ?? null;
unset($_SESSION['show_code']);
if (!$sc) { header('Location: ' . BASE_URL . '/'); exit; }

$next = ($sc['next'] ?? '') === 'profile' ? BASE_URL . '/profile.php' : BASE_URL . '/login.php';
$pageTitle = 'Kode pemulihan';
include __DIR__ . '/includes/header.php';
?>
<section class="box narrow code-card">
    <h1>Simpan kode pemulihanmu</h1>
    <p>Jika suatu saat lupa kata sandi, kode ini dipakai untuk mengatur ulang tanpa membuat akun baru.</p>
    <div class="code-box" id="code"><?= e($sc['code']) ?></div>
    <button class="btn ghost" type="button"
            onclick="navigator.clipboard.writeText(document.getElementById('code').textContent.trim()).then(() => this.textContent = 'Tersalin ✓')">Salin kode</button>
    <p class="muted">Kode ini <strong>hanya tampil sekali</strong>. Catat di tempat aman. Kode hanya berlaku satu kali pakai, setelah dipakai akan dibuatkan kode baru.</p>
    <a class="btn" href="<?= e($next) ?>">Saya sudah menyimpannya</a>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
