<?php
require_once __DIR__ . '/includes/functions.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $name = trim($_POST['name'] ?? '');
    $username = strtolower(trim($_POST['username'] ?? ''));
    $pw = $_POST['password'] ?? '';
    if ($name === '') $err = 'Nama wajib diisi.';
    elseif (!preg_match('/^[a-z0-9_]{3,30}$/', $username)) $err = 'Username 3–30 karakter: huruf kecil, angka, atau garis bawah (_).';
    elseif (strlen($pw) < 8) $err = 'Kata sandi minimal 8 karakter.';
    else {
        $ex = $pdo->prepare('SELECT 1 FROM users WHERE username = ?'); $ex->execute([$username]);
        if ($ex->fetchColumn()) $err = 'Username sudah dipakai.';
        else {
            $pdo->prepare('INSERT INTO users (name, username, password_hash) VALUES (?,?,?)')
                ->execute([mb_substr($name, 0, 80), $username, password_hash($pw, PASSWORD_BCRYPT)]);
            // [BARU] buat kode pemulihan & tampilkan sekali di halaman berikutnya
            $_SESSION['show_code'] = ['code' => set_recovery_code($pdo, (int)$pdo->lastInsertId()), 'next' => 'login'];
            flash_set('success', 'Akun berhasil dibuat. Selamat bergabung, ' . $name . '!');
            header('Location: ' . BASE_URL . '/recovery_code.php'); exit;
        }
    }
}
$pageTitle = 'Daftar';
include __DIR__ . '/includes/header.php';
?>
<section class="auth">
    <div class="auth-side">
        <h2>Gabung dengan komunitas Visura</h2>
        <p>Buat akun gratis dan mulai bagikan foto kunjunganmu.</p>
        <ul class="auth-points">
            <li>Unggah foto dari tempat yang kamu kunjungi</li>
            <li>Beri rating dan ulasan</li>
            <li>Foto otomatis dikompresi agar ringan</li>
        </ul>
    </div>
    <form class="auth-form" method="post">
        <p class="hello"><?= greeting() ?>, selamat datang</p>
        <h1>Buat akun baru</h1>
        <p class="sub">Hanya butuh satu menit.</p>
        <?php if ($err): ?><div class="alert error"><?= e($err) ?></div><?php endif; ?>
        <?= csrf_field() ?>
        <label>Nama <input name="name" required maxlength="80" autocomplete="name" value="<?= e($_POST['name'] ?? '') ?>"></label>
        <label>Username <input name="username" required maxlength="30" pattern="[a-z0-9_]{3,30}" autocomplete="username" value="<?= e($_POST['username'] ?? '') ?>"></label>
        <label>Kata sandi (min. 8 karakter) <input type="password" name="password" required minlength="8" autocomplete="new-password"></label>
        <label class="check">
            <input type="checkbox" onchange="this.form.password.type = this.checked ? 'text' : 'password'">
            Tampilkan kata sandi
        </label>
        <button class="btn" type="submit">Daftar</button>
        <p class="alt">Sudah punya akun? <a href="<?= BASE_URL ?>/login.php">Masuk</a></p>
    </form>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
